# Archived NASA DONKI records

Raw JSON returned by the live NASA CCMC DONKI API (`https://ccmc.gsfc.nasa.gov/DONKI-API/get/…`) on
**14 Nov 2026, 15:53 UTC**. `queries.json` lists the 19 exact request URLs (21 Sep 2025 – 14 Nov 2026).

| File | Records |
|---|---|
| `flares.json` | 33 solar flares (FLR) |
| `cmes.json`   | 42 coronal mass ejections (CME) |
| `seps.json`   | 59 solar energetic particle detections (SEP) → 12 storms after grouping |

`src/nasa/donki-archive.js` is generated from these files, with fields trimmed to what the game displays and
values unchanged. The SHA-256 of each array is noted in that file's header. The game uses the archive **only** when the
live API can't be reached, and always labels it **ARCHIVED**.
