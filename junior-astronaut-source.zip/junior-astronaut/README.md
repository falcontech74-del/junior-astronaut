# 👩‍🚀 Junior Astronaut — 3D Space Colony Simulator

**Run a real-science colony on Mars or the Moon, right in the browser.** You get a crew of four, 30–90 days and a small budget. Build power, oxygen, water and food systems, survive dust storms and equipment failures, and shelter the crew from solar storms taken from **real NASA DONKI space-weather records**.

Made for intermediate-level school students. It works on laptops and phones (mouse or touch), needs no install or account, and only uses the network for fonts and NASA data.

> **Live demo:** `https://<your-project>.vercel.app` ← paste your Vercel URL here after deploying (see [Deploy to Vercel](#-deploy-to-vercel))
> **Judges:** start with [docs/JUDGES.md](docs/JUDGES.md). It's a 5-minute guided tour that uses the built-in **Demo mode**.

![Mars base in demo mode](docs/screenshots/02-mars-base.png)

| | | |
|---|---|---|
| ![Main menu](docs/screenshots/01-main-menu.png) | ![Life-support science](docs/screenshots/03-life-support-science.png) | ![Radiation alert from real NASA data](docs/screenshots/05-radiation-nasa.png) |
| Main menu | Life-support science with live numbers | Radiation alert built from a real NASA SEP event |
| ![Moon base](docs/screenshots/07-moon-base.png) | ![NASA data sources](docs/screenshots/06-nasa-data-sources.png) | ![Final report](docs/screenshots/08-final-report.png) |
| Moon south-pole base | NASA Data Sources panel | Final mission report and rank |

<p align="center"><img src="docs/screenshots/09-phone-mars.png" width="230" alt="Phone: Mars mission"> &nbsp; <img src="docs/screenshots/10-phone-tutorial.png" width="230" alt="Phone: first-time tutorial"></p>

---

## ✨ Features

- **Two worlds that really play differently.**
  - **Mars (Arcadia Planitia):** thin CO₂ air, buried ice, dust storms that dim the solar panels.
  - **Moon (south pole):** no air, long dark spells behind the crater rim, stronger radiation.
- **Real 3D colony** (React Three Fiber + three.js) with 11 building types:
  - Solar Array, Battery Bank, Fission Reactor, Oxygen Generator, Ice Miner, Water Recycler, Greenhouse, Regolith Shield, ISRU Fabricator, Science Lab and Comms Dish.
  - The world has terrain, day/night lighting, shadows and particles, plus a cinematic landing camera.
- **Resource simulation** for oxygen, water, food, power, crew health and radiation dose, with storage caps.
  - Missions last **30, 60 or 90 days**. Difficulty rises through four threat levels (days 1 / 20 / 45 / 70).
- **5 interactive emergencies**, each with Mars and Moon variants: dust storm, O₂ generator failure, water leak, battery failure and radiation alert.
  - Each one offers 2–3 engineering choices with real trade-offs, followed by a debrief that explains the better option.
- **Real NASA data:** radiation alerts are built from actual DONKI solar energetic particle (SEP) storms, solar flares and coronal mass ejections (CMEs). The data is fetched live from NASA's API. If NASA can't be reached, the game falls back to a clearly labelled archive of real records. A **NASA DATA INSIDE** badge and a **Data Sources** panel link to every original record.
- **STEM learning system:**
  - Life-support science explainers using the base's live numbers, with every number tagged **REAL** or **GAME**.
  - 14 real facts per world, a Codex, quizzes and a Handbook.
  - Decision debriefs rated Best/Good/Risky/Poor.
  - A final report that scores survival, crew health, resources, engineering and learning, and awards a Gold/Silver/Bronze/Cadet rank.
- **Polish:**
  - Loading screen, main menu and a 9-step first-time tutorial.
  - **Hackathon demo mode** (a pre-built base plus a 7-step guided showcase).
  - Sound effects and procedural background music.
  - Quality presets (Auto/High/Low) with automatic resolution scaling on slow devices.
  - Respects the reduced-motion setting.

## 🚀 Quick start (local)

Requirements: **Node.js 22 or newer** (npm is included). Nothing else is needed to build or play.

```bash
npm ci            # install exact dependency versions from package-lock.json
npm run build     # production build -> dist/  (+ single-file version in dist-standalone/)
npm run preview   # serve dist/ at http://127.0.0.1:4173 with the same headers as Vercel
```

Open http://127.0.0.1:4173 in Chrome, Edge, Firefox or Safari. To test from a phone on the same Wi-Fi, run `HOST=0.0.0.0 npm run preview` and open `http://<your-computer-ip>:4173`.

**No server at all?** `dist-standalone/junior-astronaut.html` is the whole game in one file. Double-click it, or send it to anyone. It also fetches live NASA data when the computer is online.

| Command | What it does |
|---|---|
| `npm run build` | Bundles and minifies with esbuild. Fails on any error **or warning**, so a broken build can't deploy. Prints file sizes, including gzip/brotli. |
| `npm run preview` | Local static server that applies `vercel.json` headers, including the Content-Security-Policy. |
| `npm start` | Build, then preview. |
| `npm test` | NASA DONKI unit tests (Node only, no browser needed). |
| `npm run test:e2e` | Full browser regression, 1,011 checks (needs Python 3 + Playwright + Chrome; see [Testing](#-testing)). |

## ▲ Deploy to Vercel

The repo is ready for Vercel as-is. `vercel.json` sets the install command (`npm ci`), the build command (`npm run build`), the output folder (`dist`), security headers and caching.

### Option A: Vercel dashboard (recommended, works from a phone browser too)
1. Put this folder in a GitHub repository. Include `package.json`, `package-lock.json`, `vercel.json`, `src/`, `scripts/` and the rest. `node_modules/` and `dist/` are git-ignored on purpose.
2. Go to **https://vercel.com/new** and sign in with GitHub.
3. **Import** the repository. Vercel reads `vercel.json`, so leave **Framework Preset = Other** and don't change the build settings.
4. Click **Deploy**. About a minute later you get `https://<project>.vercel.app`.
5. Paste that URL at the top of this README. Every `git push` to the main branch redeploys automatically.

### Option B: Vercel CLI (from a computer)
```bash
npm i -g vercel
vercel          # first time: log in, link/create the project, deploys a preview URL
vercel --prod   # production URL
```

### After deploying: 1-minute check
- Open the URL. The loading screen appears, then the main menu.
- Start a **Mars** mission and a **Moon** mission.
- Tap the **NASA DATA INSIDE** badge. The status should say **LIVE** with today's date range. It shows **ARCHIVED** only if NASA's API is down. That's expected and labelled.
- Open the URL on a phone and play one in-game day.

**What `vercel.json` sets**

| Header | Value | Why |
|---|---|---|
| `Content-Security-Policy` | Scripts from the site only, Google Fonts, and `connect-src` limited to `https://ccmc.gsfc.nasa.gov` (NASA DONKI) | Strict policy. Tested to block nothing the game needs. |
| `Cache-Control` on `/assets/*` | `max-age=31536000, immutable` | File names contain a content hash, so repeat visits load instantly. |
| `Cache-Control` on `/` | `max-age=0, must-revalidate` | New deployments show up immediately. |
| `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` | Standard hardening | Turns off camera, microphone and geolocation. The game never asks for them. |

Vercel serves the files with brotli/gzip compression automatically. The game code is **~1.43 MB minified, ~328 KB with brotli**.

## 🧰 Technology stack

| Layer | Technology | Used for |
|---|---|---|
| UI | **React 19** (plain JavaScript/JSX) | HUD, menus, modals, tutorial, reports |
| 3D | **three.js 0.187**, **React Three Fiber 9**, **Drei 10** | Terrain, buildings, lighting/shadows, stars, particles, camera controls, adaptive resolution |
| Simulation | Custom engine (`src/engine.js`) | Resource flows, buildings, crew, events, scoring. Runs separately from the UI. |
| Data | **NASA CCMC DONKI API v2** via `fetch` | Real solar flares, CMEs and SEP events |
| Audio | Web Audio API | Procedural ambient music and sound effects (no audio files) |
| Build | **esbuild 0.28** | Bundles and minifies into hashed static files, plus a single-file build |
| Hosting | **Vercel** (static) | HTTPS, CDN, compression, headers from `vercel.json` |
| QA | Node test script + **Playwright** (Python) on Chrome | Unit, simulation and real-click UI tests on 7 screen sizes |

No backend, database, accounts, tracking or API keys. Settings and the chosen mission length are saved in the browser's `localStorage`.

## 🛰️ NASA data sources

The game uses **NASA's Space Weather Database Of Notifications, Knowledge, Information (DONKI)**, run by the Community Coordinated Modeling Center (CCMC) at NASA Goddard.

| Source | Link |
|---|---|
| DONKI tool page | https://ccmc.gsfc.nasa.gov/tools/DONKI/ |
| DONKI web app | https://ccmc.gsfc.nasa.gov/DONKI/ |
| API documentation | https://ccmc.gsfc.nasa.gov/DONKI/api/ |
| User guide | https://ccmc.gsfc.nasa.gov/DONKI/guide/ |
| Endpoints used | `https://ccmc.gsfc.nasa.gov/DONKI-API/get/FLR`, `/get/CME`, `/get/SEP` with `startDate`/`endDate` (no API key, at most a 60-day window per request) |

How the game uses it:
1. On start, it fetches the last 60 days of flares, CMEs and SEP events. SEP storms are rare, so if fewer than 3 are found it searches up to 5 earlier 60-day windows, still using live requests.
2. SEP detections are grouped into storms using DONKI's own links between events (flare → CME → SEP).
3. Each radiation emergency uses the next real storm and shows its date, its type and a link to the original NASA record.
4. If the API doesn't answer within 20 s, or returns an error, the game uses `src/nasa/donki-archive.js`. That's a snapshot of **real** DONKI records retrieved on 14 Nov 2026 (33 flares, 42 CMEs, 59 SEP detections → 12 storms). The original JSON files are in `tools/donki-archive/`. The game always says **ARCHIVED** in that case and never presents archived data as live.

**Honesty rules in the code:**
- NASA observations are never invented.
- Doses, costs and points are game values and are labelled **simulated**.
- Storm strength (GOES >100 MeV = strong, >10 MeV = moderate, otherwise minor) only scales the *simulated* dose.

Full details: [docs/NASA_DATA.md](docs/NASA_DATA.md). The game's whole science content was checked against NASA, ESA, CDC and peer-reviewed sources. What was verified, what was corrected, and how real and simulated values are separated is in [docs/SCIENCE_VALIDATION.md](docs/SCIENCE_VALIDATION.md), with a full reference list. Other science sources are credited in the in-game **Credits** tab and in [docs/NASA_DATA.md](docs/NASA_DATA.md#4-other-science-sources): MOXIE, ISS water recovery, KRUSTY, Veggie, Curiosity RAD and Chang'e 4 LND.

*This is a student project. It is not affiliated with or endorsed by NASA.*

## 🗂️ Project structure

```
junior-astronaut/
├── src/
│   ├── index.jsx            entry point
│   ├── App.jsx              screens, HUD, menus, modals, report
│   ├── Extras.jsx           settings, tutorial, demo mode, credits, landing curtain
│   ├── engine.js            simulation engine (no React)
│   ├── emergencies.js       5 emergencies × Mars/Moon
│   ├── learning.js          explainers, facts, debriefs, score, ranks
│   ├── data.js              planets, buildings, crew, threat levels
│   ├── settings.js          saved settings, graphics presets, procedural music
│   ├── bus.js               modal queue, toasts, sound effects
│   ├── nasa/donki.js        DONKI client (live → archive fallback)
│   ├── nasa/donki-archive.js  archived real DONKI records (generated, do not edit)
│   ├── scene/               3D world, building models, terrain
│   ├── boot/boot.js         loading-screen safety net
│   └── template.html        HTML shell, styles, loading screen
├── scripts/build.mjs        production build
├── scripts/serve.mjs        local preview server (applies vercel.json headers)
├── qa/                      automated tests (see below)
├── tools/donki-archive/     raw NASA DONKI JSON behind the archive
├── docs/                    summary, demo script, judges' guide, NASA data, science validation, screenshots
├── vercel.json              Vercel build + headers
└── package.json
```

## 🧪 Testing

```bash
npm test                                   # NASA DONKI unit tests (Node)
pip install playwright && python3 -m playwright install chromium   # once, for browser tests
CHROME_PATH=$(python3 -c "from playwright.sync_api import sync_playwright as s; p=s().start(); print(p.chromium.executable_path); p.stop()") \
  npm run test:e2e                         # full regression against the production build
JA_URL=https://<project>.vercel.app/ npm run test:e2e   # run the same suite against the deployed site
```

The suite starts the preview server and drives a real Chrome with clicks and taps. It covers:
- deployment headers and CSP
- Mars and Moon on desktop and phone
- 30/60/90-day missions
- all 5 emergencies
- STEM learning
- NASA live, blocked, HTTP 503 and timeout cases
- menu, settings, music, tutorial, credits and demo mode
- an overlap audit on 7 screen sizes, from 1920×1080 down to 360×740, plus a landscape phone

Latest results are in [docs/JUDGES.md](docs/JUDGES.md#test-results).

## ⚡ Performance

- The HTML page is **47 KB** and shows the loading screen right away. The game code loads as one hashed, cached file (`defer`).
- Graphics quality is set automatically:
  - **Low** on phones and low-power devices: lower resolution, no antialiasing, 1024 shadow maps, fewer stars, no particles.
  - **High** on capable laptops.
  - Players can override it in ⚙️ Settings.
- Drei `PerformanceMonitor` + `AdaptiveDpr` lower the resolution if the frame rate drops.
- Geometry is procedural and textures are generated, so there are no large image or model downloads.

## ⚠️ Known limitations

- Frame rates were tested with a software renderer in CI, not on real phone GPUs. Test on your own phone before presenting.
- NASA's API occasionally has outages. The game then shows archived real data, labelled as such.
- Fonts load from Google Fonts. If they're unavailable, system fonts are used.
- Sound needs one tap or click first (browser autoplay rules).

## 🙌 Credits

Game design, code and science content: the Junior Astronaut team.
Space-weather data: NASA CCMC DONKI. Libraries: React, three.js, React Three Fiber, Drei (pmndrs), esbuild.
