# Guide for judges

**Play:** open the deployed site on a laptop or phone: `https://<your-project>.vercel.app`.
- No install, account or sound card is needed. Sound starts after your first click.
- Works in current Chrome, Edge, Firefox and Safari. A WebGL-capable device is needed; any laptop or phone from about 2017 onwards should work.
- **Offline alternative:** open `dist-standalone/junior-astronaut.html`. The whole game is in that one file.

## The 5-minute tour (recommended)

1. On the main menu, click **🎬 Demo mode**, then **Start the demo ▸**.
   - A complete Mars base is already running and random events are turned off.
   - A **DEMO MODE** panel (top of the screen) shows 7 steps. Press its **Next ▸** button to go through them in order.

   | Step | What to look for |
   |---|---|
   | 🎥 Tour the base | 3D colony with all 11 building types, day/night light, dust motes, shadows. Drag to orbit, scroll or pinch to zoom. |
   | 🔬 Life-support science | Real chemistry and physics with the base's **live** numbers. Every value is tagged **REAL** (sourced) or **GAME** (simulated). |
   | 🌪️ Dust emergency | 2–3 engineering choices with costs. After choosing, a **debrief** rates the decision and explains the better option. |
   | ☢️ Radiation alert | Built from a **real NASA DONKI solar energetic particle storm**: real date, flare class, CME speed, detecting instruments, minutes of warning, and a link to the NASA record. |
   | 🛰️ NASA data & credits | All flares, CMEs and SEP storms loaded, the **LIVE / ARCHIVED** status, links to every original record, and science sources. |
   | 🌙 Switch to the Moon | Same game, different physics: no air, long dark spells, stronger radiation. |
   | 🏁 Final report | Scores (survival, crew health, resources, engineering, learning), crew survival, STEM learning results, rank. |

2. **Play a real mission (2–3 minutes).** Go back to the title screen (☰ → **⌂ Change destination**) and choose **🚀 Start a mission** → Mars or Moon → **30 days**.
   - First-timers get a 9-step tutorial. It pauses the clock and moves on when you actually do each thing.
   - Build an **Oxygen Generator** and a **Solar Array**, then press ▶ or ⏩.
   - Watch the gauges at the top: oxygen, water, food, power and crew.
3. **On a phone:** open the same URL. Tap a building in the bottom bar, tap the ground, then tap **✓ Build**. Everything is reachable by touch.

## What to check for each judging criterion

| Criterion | Where to see it |
|---|---|
| Use of NASA data | **NASA DATA INSIDE** badge on the title screen, or ☰ → 🛰️ NASA data sources in a mission → Data Sources panel; radiation alert NASA card; [NASA_DATA.md](NASA_DATA.md) |
| Scientific accuracy | REAL/GAME tags in the life-support explainers; Handbook "Real science vs game" table; Credits tab with NASA and peer-reviewed sources; [SCIENCE_VALIDATION.md](SCIENCE_VALIDATION.md) |
| STEM learning | Explainers, debriefs, Science Codex (📘), Mission Handbook (📖), quizzes, planet facts, final report learning section |
| Technical quality | 3D engine in the browser; this page's [test results](#test-results); `vercel.json` security headers |
| Accessibility / reach | Phone and touch support, automatic graphics quality, reduced-motion support, no install or account |
| Presentation | [DEMO_SCRIPT.md](DEMO_SCRIPT.md), [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) |

## Screenshots

| | |
|---|---|
| ![Main menu](screenshots/01-main-menu.png) **Main menu** | ![Mars base](screenshots/02-mars-base.png) **Mars base (demo mode)** |
| ![Science](screenshots/03-life-support-science.png) **Life-support science, REAL vs GAME values** | ![Dust](screenshots/04-dust-emergency.png) **Dust storm emergency with choices** |
| ![Radiation](screenshots/05-radiation-nasa.png) **Radiation alert from a real NASA SEP storm** | ![Sources](screenshots/06-nasa-data-sources.png) **NASA Data Sources panel** |
| ![Moon](screenshots/07-moon-base.png) **Moon south-pole base** | ![Report](screenshots/08-final-report.png) **Final report and rank** |
| ![Phone](screenshots/09-phone-mars.png) **Phone: Mars mission** | ![Tutorial](screenshots/10-phone-tutorial.png) **Phone: first-time tutorial** |

*The screenshots come from the automated test browser, which uses software rendering, so a real GPU shows smoother edges. The NASA panel in the screenshots shows ARCHIVED because the test machine has no internet access. A deployed site shows LIVE.*

## Test results

Automated regression on the **production build**, served with the real `vercel.json` headers. It ran in Chrome with real clicks and taps on 15 Nov 2026. Run it yourself with `npm run test:e2e` (see [qa/README.md](../qa/README.md)).

| Suite | Checks | Result |
|---|---:|---|
| Deployment: headers, Content-Security-Policy, cached assets, Mars + Moon on the served site and the standalone file | 35 | ✅ all pass |
| NASA DONKI unit tests (parsing, storm grouping, strength, fallback, timeout) | 19 | ✅ |
| Engine: resources, buildings, 30/60/90-day missions | 103 | ✅ |
| Engine: long-mission balance | 71 | ✅ |
| Engine: 5 emergencies × Mars/Moon | 87 | ✅ |
| Engine: STEM learning system | 44 | ✅ |
| UI: Mars & Moon on desktop and phone | 196 | ✅ |
| UI: emergencies on desktop and phone | 134 | ✅ |
| UI: STEM learning | 59 | ✅ |
| UI: NASA live / blocked / HTTP 503 / timeout | 125 | ✅ |
| UI: menu, settings, music, quality, tutorial, credits, report | 54 | ✅ |
| UI: hackathon demo mode (desktop + phone) | 28 | ✅ |
| UI: overlap audit on 7 screen sizes (1920×1080 → 360×740, landscape phone) | 56 | ✅ |
| **Total** | **1,011** | **0 failures** |

**Not covered by automated tests:**
- Real phone GPUs and real frame rates (the test browser renders in software).
- How the music sounds.
- The live NASA response on the deployed URL: the test machine has no internet, so live responses are simulated. A live fetch was checked manually in a real browser on 14 Nov 2026 (see [NASA_DATA.md](NASA_DATA.md#verified-live-retrieval)).

### Player testing (Phase 9, partial: stopped early to meet the deadline)
A scripted "student" played complete missions through real clicks and taps. It used only what is on screen: the ⭐ hint, the gauges, pop-ups and buttons. It played two styles: a **careful** student (reacts to warnings and repairs) and a **casual** student (follows the ⭐ hint only and always picks the first choice).

| Mission | Careful student | Casual student |
|---|---|---|
| Mars 30 days | ✅ Won, Gold (89) | ✅ Won, Silver (82) |
| Moon 30 days | ✅ Won, Gold (91) | ✅ Won, Gold (91) |
| Mars 60 days | ✅ Won, Gold (85) | ❌ Lost on day 29 (habitat leak with no materials left to repair it) |
| Moon 60 days | ✅ Won, Gold (93) | ✅ Won, Gold (90) |
| 90-day missions | not run on the final build | not run on the final build |

Fixes from player testing:
- **Ice on phones:** picking the Ice Miner now moves the camera to the blue ice tiles, which were off-screen on phones.
- **Smarter ⭐ hint:** it now puts urgent needs first (water, oxygen, food, reactor before the lunar dark, power, Fabricator) and the goals panel explains why.
- **Repair prompts:** the goals panel now prompts repairs for worn or broken machines and for a leaking habitat.
- **Better power advice:** it now tells students to add Solar Arrays when more batteries would not help.
- **Build tips:** placing a shield away from the habitat, or a second Water Recycler, now shows a tip.
- **Simpler wording:** the radiation alert was rewritten at a simpler reading level, and GOES, MeV and SEP are explained on the NASA card.

After the fixes, the final build passed the 35 deployment smoke checks, 117 engine checks and 19 NASA unit checks. **The full browser UI suites were not re-run on the final build** because of the deadline.
