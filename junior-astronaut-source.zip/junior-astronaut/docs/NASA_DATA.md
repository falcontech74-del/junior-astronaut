# NASA data in Junior Astronaut

## 1. Dataset: NASA DONKI (Space Weather Database Of Notifications, Knowledge, Information)

DONKI is NASA's space-weather event database. It is run by the **Community Coordinated Modeling Center (CCMC)** at NASA Goddard Space Flight Center. Space-weather analysts log solar flares, coronal mass ejections, solar energetic particle events and other activity there, and they link the events that are related. Since 2020, most entries have come from NASA's Moon to Mars Space Weather Analysis Office at Goddard.

| Resource | URL |
|---|---|
| DONKI tool page | https://ccmc.gsfc.nasa.gov/tools/DONKI/ |
| DONKI web application | https://ccmc.gsfc.nasa.gov/DONKI/ |
| API documentation (OpenAPI v2) | https://ccmc.gsfc.nasa.gov/DONKI/api/ |
| User guide | https://ccmc.gsfc.nasa.gov/DONKI/guide/ |
| API base used by the game | `https://ccmc.gsfc.nasa.gov/DONKI-API/get/` |

### Endpoints and fields used

| Endpoint | Event type | Fields the game keeps |
|---|---|---|
| `GET /get/FLR?startDate=YYYY-MM-DD&endDate=YYYY-MM-DD` | Solar flares | `flrID`, `beginTime`, `peakTime`, `classType` (e.g. M1.2, X1.0), `sourceLocation`, `activeRegionNum`, `instruments`, `link`, `linkedEvents` |
| `GET /get/CME?…` | Coronal mass ejections | `activityID`, `startTime`, most accurate `cmeAnalyses` entry (`speed` km/s, `halfAngle`, `type`), `sourceLocation`, `link`, `linkedEvents` |
| `GET /get/SEP?…` | Solar energetic particle events | `sepID`, `eventTime`, `instruments` (e.g. GOES-P: 10 MeV), `link`, `linkedEvents` |

- No API key is needed. The API allows cross-origin requests, so the browser calls NASA directly and there is no proxy server.
- One request may cover at most **60 days**.
- The site's Content-Security-Policy allows exactly one outside data origin: `connect-src https://ccmc.gsfc.nasa.gov`.

## 2. How the data flows into the game

```
start of session
   │  fetch last 60 days: FLR + CME + SEP          (src/nasa/donki.js → loadDonki)
   │  fewer than 3 SEP storms? look back up to 5 more 60-day windows (live requests)
   ▼
normalise → group SEP detections into storms via DONKI linkedEvents (flare → CME → SEP)
   ▼
NasaData store: status LIVE (fetched date range shown)  ─or─  ARCHIVED (reason shown)
   ▼
Radiation emergency  → uses the next real storm: date, event type, flare class, CME speed,
                       instruments, minutes of warning, link to the NASA record
Data Sources panel  → lists the flares, CMEs and SEP storms with links to every original record
NASA DATA INSIDE badge → opens the panel
```

**Storm strength** is a game rule based on which real detectors saw the event. It only scales the simulated dose:

| Strength | Real criterion (from DONKI `instruments`) | Simulated dose factor |
|---|---|---|
| Strong | GOES recorded protons > 100 MeV | × 1.25 |
| Moderate | GOES recorded protons > 10 MeV | × 1.0 |
| Minor | Seen by deep-space probes or models only, not by GOES at Earth | × 0.8 |

## 3. Live vs archived: the honesty rules

- **Live:** the badge and panel say **LIVE** and show the date range and the time of the fetch.
- **Archived:** used if the API doesn't answer within **20 seconds**, returns an HTTP error, or returns something unexpected. The game shows **ARCHIVED**, the reason (for example "HTTP 503" or "no answer within 20 s") and the date the archive was retrieved. Archived data is never shown as live.
- **No storms found:** if the live search finds no SEP storms at all, flares and CMEs stay live and radiation alerts use archived SEP storms. The game says so in a note.
- **Never invented:** every date, class, speed and instrument shown comes from a DONKI record.
- **Labelled as game values:** radiation **doses**, resource **costs**, repair times and **points** are game values. The UI labels them *simulated*.

### The archive (`src/nasa/donki-archive.js`)

| | |
|---|---|
| Retrieved | 14 Nov 2026, 15:53 UTC, from the live DONKI API |
| Coverage | 21 Sep 2025 – 14 Nov 2026 (19 API queries, listed in `tools/donki-archive/queries.json`) |
| Contents | 33 solar flares, 42 CMEs, 59 SEP detections grouped into 12 storms |
| Raw data | `tools/donki-archive/{flares,cmes,seps,queries}.json` |
| Integrity | SHA-256 of each JSON array recorded in the file header. Fields were trimmed to what the game displays. Values are unchanged. |

### Verified live retrieval
- On 14 Nov 2026, a real browser on a normal web origin fetched **28 flares and 179 CMEs** from the previous 60 days.
- There were no SEP events in that window. The look-back search found **17 SEP detections in 4 storms**. The strongest was on 5 Sep 2026: GOES > 100 MeV, with 41 minutes of warning between the first detection and the radiation alert.
- The automated tests also simulate a live response, a blocked network, HTTP 503 and a 20 s timeout (`qa/nasa_ui.py`), and cover the parsing logic in Node (`qa/nasa_unit.mjs`).

> The claude.ai artifact preview blocks outside network requests, so that hosted copy always shows **ARCHIVED**. The Vercel deployment, the local preview and the standalone file fetch **LIVE** data when online.

## 4. Other science sources

The game's **REAL** values come from these sources. They are also listed in-game under *NASA data & credits → Science sources & credits*. All links were checked on 14 Nov 2026.

| Value in the game | Source |
|---|---|
| Oxygen from Mars air: MOXIE made 122 g, up to 12 g/hour | NASA: [MOXIE completes Mars mission](https://www.nasa.gov/missions/mars-2020-perseverance/perseverance-rover/nasas-oxygen-generating-experiment-moxie-completes-mars-mission/) |
| 98 % water recovery on the ISS | NASA: [Water recovery milestone on the ISS](https://www.nasa.gov/missions/station/iss-research/nasa-achieves-water-recovery-milestone-on-international-space-station/) |
| Kilopower / KRUSTY fission reactor test (2018) | [NASA Technical Reports Server 20180005435](https://ntrs.nasa.gov/citations/20180005435) |
| Astronauts eating space-grown lettuce (Veggie) | NASA: [Space farming yields a crop of benefits](https://www.nasa.gov/technology/tech-transfer-spinoffs/space-farming-yields-a-crop-of-benefits-for-earth/) |
| Mars surface radiation ≈ 0.67 mSv/day | Hassler et al., *Science* 2014 (Curiosity RAD), [doi:10.1126/science.1244797](https://doi.org/10.1126/science.1244797) |
| Moon surface radiation ≈ 1.37 mSv/day | Zhang et al., *Science Advances* 2020 (Chang'e 4 LND), [doi:10.1126/sciadv.aaz1334](https://doi.org/10.1126/sciadv.aaz1334) |

*Junior Astronaut is a student project. It is not affiliated with or endorsed by NASA. Space-weather data is credited to NASA CCMC DONKI.*
