# 3-minute hackathon demo script

**Setup (before you go on stage):**
- Open the deployed site in Chrome on a laptop, full screen (F11). Keep a phone with the same URL ready, if you can.
- Check the **NASA DATA INSIDE** badge says **LIVE**. If the venue Wi-Fi blocks NASA, it will say **ARCHIVED**. That's fine: say so honestly (line in step 5).
- Turn the laptop volume to about 30 %. The music starts after the first click.
- Everything below uses **Demo mode**: a complete base is pre-built, random events are off, and a panel walks through 7 steps. Each **Next: … ▸** button in the DEMO MODE panel triggers the next step.

| Time | On screen (click) | Say (about 430 words in total, at a calm pace) |
|---|---|---|
| **0:00 – 0:20** | Main menu | "Astronauts on Mars or the Moon will depend on machines for every breath, every drink of water and every meal. Students learn these facts separately, but never how they connect. And the real NASA data on dangers like solar storms is written for scientists. **Junior Astronaut** turns all of that into a game that runs in any browser, even on a phone." |
| **0:20 – 0:45** | Click **🎬 Demo mode** → **Start the demo ▸** → **Next: 🎥 Tour the base ▸** (the camera orbits) | "This is a working colony on Mars. Solar panels and a small fission reactor make power. An oxygen generator and an ice miner make air and water from local resources, a recycler reuses water, and greenhouses grow food. Every building is 3D and every number is simulated hour by hour." |
| **0:45 – 1:10** | **Next: 🔬 Life-support science** (the explainer opens) | "Any gauge opens the real science, using this base's live numbers. Notice the tags: **REAL** values come from NASA missions like MOXIE, which made oxygen on Mars. **GAME** values are our simulation. We never mix them up." *(close the panel)* |
| **1:10 – 1:35** | **Next: 🌪️ Dust emergency** → pick a choice → read the debrief | "Emergencies interrupt you. Here a dust storm is cutting our solar power. You get two or three engineering choices, each with a real cost. Afterwards, a debrief explains which choice was best and why, so a mistake becomes a lesson." |
| **1:35 – 2:05** | **Next: ☢️ Radiation alert (NASA data)** → point at the NASA card → choose shelter | "This is our main innovation. This radiation alert is a **real solar storm** from NASA's DONKI space-weather database, fetched live. You can see the real date, the flare class, the CME speed, which detectors saw it and how many minutes of warning astronauts would have had. The storm's real strength scales the danger in the game." |
| **2:05 – 2:20** | **Next: 🛰️ NASA data & credits** (scroll the list briefly) | "Every NASA record links back to its original source. If NASA's servers are down, the game switches to an archive of real records and clearly says **ARCHIVED**. It never fakes live data." *(if the badge says ARCHIVED: "The venue network is blocking NASA right now, so you're seeing our labelled archive. That's exactly the fallback working.")* |
| **2:20 – 2:40** | **Next: 🌙 Switch to the Moon** → **Start the demo ▸** | "The Moon plays completely differently: no air, long dark spells behind the crater rim, and stronger radiation. The same building does a different job, which shows students that engineering depends on the environment." |
| **2:40 – 2:55** | **Next: 🏁 Jump to the final report** | "At the end, students get a report on survival, crew health, resources, engineering and learning: which topics they explored and which real NASA storms they survived. Then they get a rank from Cadet to Gold." |
| **2:55 – 3:00** | (Optional) hold up the phone running the game | "Junior Astronaut: real science, real NASA data, in any browser. Thank you!" |

## If something goes wrong
- **A modal is in the way:** press its main button. Demo steps always clear old pop-ups.
- **The 3D looks slow on the venue laptop:** go to ⚙️ Settings → Graphics quality → **Low**. It takes effect straight away.
- **No internet at all:** open `dist-standalone/junior-astronaut.html` from a USB stick. The whole game is in that one file and it uses the labelled archive.
- **Running short of time:** skip straight from step 4 (radiation) to step 7 (final report).

## Likely judge questions (short answers)
- **"Is the NASA data really live?"** Yes. On the deployed site the browser calls `ccmc.gsfc.nasa.gov/DONKI-API` directly, with no API key or server. The badge shows LIVE or ARCHIVED, and every event links to its NASA record.
- **"Are the doses real?"** The storms, dates and detector readings are real. The dose to the crew is a *simulated* game value, scaled by the real storm strength, and it's labelled as simulated.
- **"How do you know it works?"**
  - An automated test suite drives a real Chrome through Mars and Moon on desktop and phone.
  - It covers all 5 emergencies, NASA live/blocked/error/timeout cases and 7 screen sizes.
  - Results are in `docs/JUDGES.md`.
- **"What did you learn?"** *(personal answer: for example, building a 3D engine in React, working with a real scientific API, designing honest data labels)*
