# Junior Astronaut: project summary

**One line:** a 3D browser game where students keep a crew alive on Mars or the Moon for up to 90 days, learn the real science of life support, and face solar storms taken from real NASA space-weather records.

---

## The problem

- **Space science is taught as facts, not as systems.** Students learn that plants make oxygen and that radiation is dangerous. They rarely see how oxygen, water, food, power and radiation depend on each other, or why engineers make trade-offs.
- **Real NASA data is public but hard to reach for students.** Space-weather databases like NASA DONKI are written for scientists. To a 14-year-old, a record such as "SEP, GOES-P: 10 MeV, linked to M-class flare" means nothing, even though it's exactly the event that would put astronauts in a storm shelter.
- **Good simulations are often locked away.** Many need installs, powerful PCs or paid licences. A lot of students, including the person who built this, have only a phone.

## The solution

Junior Astronaut is a free colony simulator that runs in any modern browser on a laptop or a phone.

1. **Plan a base.** Students choose Mars or the Moon and a 30, 60 or 90-day mission. They place 11 kinds of buildings (solar arrays, batteries, a fission reactor, an oxygen generator, an ice miner, a water recycler, greenhouses, regolith shielding, an ISRU fabricator, a science lab and a comms dish) on a 3D landing site.
2. **Run the systems.** A simulation engine continuously tracks oxygen, water, food, power, crew health and radiation dose. Mars has dust storms that dim solar power. The Moon has long dark spells behind the crater rim.
3. **Handle emergencies.** Dust storms, O₂ generator failures, water leaks, battery failures and radiation alerts interrupt play. Each one offers 2–3 engineering choices with real trade-offs, and a debrief explains which option was best and why.
4. **Meet real NASA events.** Radiation alerts are built from real solar energetic particle storms in NASA's DONKI database, fetched live. Each alert shows the real date, the flare class, the CME speed, the detecting instruments, the minutes of warning astronauts would have had, and a link to the original NASA record.
5. **Learn and reflect.** Tapping any gauge opens the chemistry and physics behind it, using the base's live numbers, with each value tagged REAL or GAME. A final report scores survival, crew health, resources, engineering and learning, and awards a rank.

## What is innovative

- **Live scientific data drives the gameplay.** The NASA data isn't a fact screen bolted on. It decides when radiation emergencies happen, how strong they are (based on which GOES detectors recorded protons above 10 or 100 MeV) and how much warning the crew gets. Every session can bring different real storms.
- **Honesty is built in.**
  - Every number is tagged REAL (with a cited source) or GAME (a simulated value).
  - When NASA's API is unavailable, the game switches to an archive of real records and says **ARCHIVED**. It never pretends.
  - No NASA observation is invented.
- **Two worlds with different physics.** The same building does a different job on each world. On Mars, oxygen can be made from CO₂ air (like NASA's MOXIE). On the Moon, it must come from ice or regolith. Students see that engineering depends on the environment.
- **Teaching inside the decisions.** Debriefs rate each emergency decision Best, Good, Risky or Poor and explain the better option, so mistakes turn into lessons.
- **Runs anywhere, built to production standard.**
  - No install, account or API key.
  - Automatic graphics quality for phones.
  - A 47 KB first page with cached game code.
  - A strict Content-Security-Policy.
  - Hundreds of automated real-browser tests.

## STEM impact

| Discipline | What students actually do |
|---|---|
| **Science** | Splitting CO₂ for oxygen (MOXIE: 2 CO₂ → 2 CO + O₂), electrolysis of water ice, photosynthesis in greenhouses, breathing chemistry, water recovery (ISS ≈ 98 %), solar storms, radiation dose in mSv, and why Mars and the Moon differ (atmosphere, day length, shielding) |
| **Technology** | Reading real NASA space-weather records, understanding detectors (GOES > 10 MeV / > 100 MeV), linked events (flare → CME → SEP) |
| **Engineering** | Power budgets (generation vs. consumption vs. storage), redundancy, trade-offs between cost, time and risk, repair-or-replace decisions under pressure |
| **Mathematics** | Rates per day, storage capacity, running out of time ("how many days of O₂ are left?"), cumulative dose against a 600 mSv limit, scoring weights |

**Learning design:**
- Players learn by doing, not by reading.
- Explanations use the player's own base numbers.
- Wrong choices are explained instead of punished.
- The final report records codex entries read, quiz accuracy, planet facts seen, life-support topics explored, decisions explained and real NASA storms faced.

**Who benefits:** intermediate school students, teachers who want a 20–40 minute lab activity (one 30-day mission), STEM clubs and outreach events (demo mode), and anyone with only a phone.

## Technology in brief

React 19 · three.js 0.187 · React Three Fiber 9 · Drei 10 · Web Audio · NASA CCMC DONKI API · esbuild · Vercel · Playwright tests. There is no backend: it's a static site that calls NASA directly.

## What's next

- A classroom mode that exports the final report for teachers.
- More NASA datasets, such as Mars weather from rover instruments and lunar illumination maps.
- Language translations.
- Accessibility review with screen-reader users.
- Testing on more low-end phones.
