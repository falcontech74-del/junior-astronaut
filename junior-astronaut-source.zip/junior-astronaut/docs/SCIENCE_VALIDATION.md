# Scientific validation (Phase 8, 15 Nov 2026)

This review checked every scientific statement and number in the game against NASA, ESA, CDC and peer-reviewed sources. That covers the planet facts, the Codex, the quizzes, the life-support explainers, emergency texts, debriefs, the Handbook's "Real science vs game" table and the simulation constants. About 120 claims were checked. Most were correct, and 13 were corrected (listed below). Gameplay, graphics and features are unchanged apart from the corrected radiation numbers.

## 1. What was verified (correct as written)

| Topic | Value in the game | Source |
|---|---|---|
| Mars gravity | 3.71 m/s² (0.38 g) | Standard planetary data |
| Moon gravity | 1.62 m/s² (0.165 g) | Standard planetary data |
| Mars day | 1 sol = 24 h 39 min | Standard planetary data |
| Moon light at the pole | Sun circles the horizon once per 29.5 days; it rises less than ~1.5° | The Moon's spin axis is tilted ~1.5° |
| Mars air | 95 % CO₂, ~0.6 kPa (< 1 % of Earth's pressure) | NASA Mars facts |
| Sunlight | Mars ≈ 590 W/m² (43 %), Moon ≈ 1361 W/m² | Inverse-square law, 1.52 AU |
| Temperatures | Mars −125 to +20 °C planet-wide; Moon +127 to −173 °C at the equator; shadowed polar craters below −230 °C | NASA, LRO Diviner |
| Mars surface radiation | 0.67 mSv/day (galactic cosmic rays) | Hassler et al. 2014, *Science*, Curiosity RAD |
| Moon surface radiation | 1.37 mSv/day (1,369 µSv/day) | Zhang et al. 2020, *Science Advances*, Chang'e 4 LND |
| Career dose limit | 600 mSv | NASA-STD-3001 (2022) |
| Oxygen per person | 0.84 kg/day | NASA Life Support Baseline Values and Assumptions Document (BVAD) |
| Water per person | 2.5–3.5 L/day for drinking and food (more with washing) | NASA BVAD |
| MOXIE | 122 g of O₂ in total, up to 12 g/hour; 2 CO₂ → 2 CO + O₂ | NASA (2023) |
| Electrolysis | 2 H₂O → 2 H₂ + O₂; 9 kg water → 8 kg O₂ + 1 kg H₂ | Chemistry (molar masses) |
| ISS water recovery | ~98 % in 2023 (Brine Processor Assembly) | NASA (June 2023) |
| Kilopower / KRUSTY | Ground test completed in 2018 | NASA NTRS 20180005435 |
| Veggie lettuce | Eaten on the ISS in 2015 | NASA |
| Dust shield | Electrodynamic Dust Shield removed lunar regolith on Blue Ghost (March 2025) | NASA |
| Opportunity | Ended by the 2018 global dust storm | NASA JPL |
| InSight | More than 1,300 marsquakes | NASA JPL |
| Radio delay | Moon ≈ 1.3 s; Mars 3–22 min | Speed of light, orbital distances |
| Planet facts and quizzes (all 42 questions) | e.g. Olympus Mons ~22 km, Phobos orbits 3× a day, 382 kg of Apollo samples, Moon recedes 3.8 cm/yr, Armstrong limit ~6.3 kPa | NASA and standard references |
| NASA DONKI | Run by NASA CCMC at Goddard; FLR, CME and SEP endpoints; at most 60 days per request; no API key | DONKI tool page and API (checked 15 Nov 2026). Since 2020, most entries come from NASA's Moon to Mars Space Weather Analysis Office. |

## 2. What was corrected

| # | Was | Problem | Now |
|---|---|---|---|
| 1 | Solar-storm dose on **Mars** 180–260 mSv unshielded | 2–5× too high. Mars's CO₂ air stops most solar protons. NASA estimates ~40 mSv on the surface for the October 1989 storm (Simonsen et al. 2025) and ~20–100 mSv for the 1956, 1960 and 1972 storms. Curiosity's biggest measured surface storm (May 2024) was ~8 mGy. | **55–80 mSv** (×0.8–1.25 by real storm strength). Moon value unchanged: 350–455 mSv for an unprotected astronaut, since the Moon has no air. |
| 2 | Crew became ill above **40 mSv** in one storm | Wrong. Radiation sickness needs ~700 mSv+ in a short time, and mild symptoms appear from ~300 mSv (CDC). NASA's short-term limit is **250 mSv per solar particle event** (NASA-STD-3001). | Health is lost only above **250 mSv** per storm. The messages explain the 250 mSv per-storm and 600 mSv career limits. An emergency now counts as "handled well" below 250 mSv (was 100). |
| 3 | Habitat walls gave **no** protection without regolith shields | Any habitat wall stops part of a solar storm. NASA's estimates assume 10–20 g/cm² of shielding. | Habitat walls ×0.7. One shield ×0.5 and two shields ×0.1 are unchanged. |
| 4 | "Solar particle events are bursts of protons **from solar flares**" | Incomplete. The most intense SEPs are accelerated by **CME-driven shock waves**, as well as by flares. | Codex, explainer and alert texts now name both flares and CME shocks. |
| 5 | "Protons reach Mars in **about 6 hours**" | The first protons can arrive within an hour. The NASA card already showed the real warning time. | The alert says the game gives ~6 h of warning, but real protons can arrive within an hour. |
| 6 | "Mars's thin air **blocks a little**" / "**many** protons reach the surface" | Understated the shielding. ESA measured a 2021 storm at 30× less on Curiosity's surface than at the orbiter above. | "Only the most energetic protons reach the surface." |
| 7 | ISS oxygen candles burn **sodium chlorate** | ISS and Mir SFOG ("Vika"/TGK) candles use **lithium perchlorate**, about one crew member's oxygen for one day each (NASA). | LiClO₄ → LiCl + 2 O₂. The game's +10 kg is labelled GAME (about a dozen candles). |
| 8 | NASA Fission Surface Power "aims for **40 kW**" | Out of date. NASA's 2025 plan targets **at least 100 kW** on the Moon by about 2030. | Updated and labelled GAME for the game's 10 kW unit. |
| 9 | InSight quake "**magnitude 4.7** in 2022" | NASA reports an **estimated magnitude 5** (4 May 2022). | Uses NASA's figure. |
| 10 | Comms Dish: cargo "every **5** days"; trade-off text "every 6 days" | Inconsistent with the simulation (Mars every 15 sols, Moon every 6 days). | Texts match the simulation, and the note says the Mars depot is imagined (real launch windows open every ~26 months). |
| 11 | Apollo samples "**showed**" the Moon formed from a giant impact | Overstated. The giant-impact idea is the leading hypothesis, *supported* by the samples. | "Support the idea that…" |
| 12 | Dust storm explanation | Did not say how much stronger real storms can be. | Codex and Handbook: the 2018 storm (τ ≈ 10.8) cut Opportunity's power from ~645 to 22 Wh/day (−97 %). The game's storms (up to ~74 %) are labelled as milder. |

| 13 | A Mars radiation alert implied the real NASA storm hit Mars | DONKI's SEP detectors (GOES, SOHO, STEREO) are near Earth. Mars may be on another side of the Sun. | Mars alerts note that the real storm may have hit Mars harder, more weakly or not at all, and is used as a real example of timing and strength. |

Also updated:
- "Spacesuits give **almost no** protection" now reads "**little** protection from energetic solar protons", and the ALARA principle (keep doses As Low As Reasonably Achievable) was added.
- The debrief for working outside in a solar storm now depends on the dose. On the Moon (over 250 mSv) it is a **Poor** call. On Mars (below 250 mSv) it is a **Risky** call, because the dose still eats into the career limit.

## 3. Real measurements vs simulated game values

Every value in the game's science panels carries a **REAL** or **GAME** tag. The Mission Handbook's "Real science vs game" table lists all of them side by side.

| Real measurements and facts (used directly) | Simulated game values (clearly labelled) |
|---|---|
| Gravity, sunlight, day lengths, atmosphere, surface radiation (0.67 / 1.37 mSv/day), 0.84 kg O₂/person/day, electrolysis ratios, MOXIE output, 98 % ISS water recovery, 600 mSv career and 250 mSv per-storm limits | Building outputs (e.g. 4 kg O₂/day for 2 kW), costs in "kg of materials", tank sizes, storm doses (55–80 / 350–455 mSv), shield factors, health loss rates, event frequency (compressed: a solar storm every 2–3 weeks), cargo landers, threat levels, points and score |
| **NASA DONKI records**: event dates, flare classes, CME speeds, detecting instruments, warning times, links. Never invented, and labelled LIVE or ARCHIVED. | **Crew dose from a DONKI storm**: a GAME dose scaled ×0.8 / ×1 / ×1.25 by the real storm's strength (minor / moderate / strong) |

Survival timings are compressed and labelled GAME. Crew health reaches zero in about 1 day without oxygen, about 4 days without water and about 2.5 weeks without food. In reality, people die within minutes without air (cabin air lasts a day or two), in about 3 days without water and after several weeks without food.

## 4. Emergencies and resource needs: are they realistic for an educational simulation?

| Emergency | Real basis | Assessment |
|---|---|---|
| Mars dust storm | Regional and global storms; Opportunity 2018 | Realistic choices (load shedding, cleaning panels). Strength is milder than the worst real storms and labelled as such. |
| Moon dust cloud | Charged, abrasive regolith; Apollo 17 "lunar hay fever"; EDS on Blue Ghost | Realistic. |
| O₂ generator failure | MOXIE solid-oxide cells and dust filters; electrolyser fouling; ISS chemical candles as backup | Realistic. Corrected the candle chemistry. |
| Water leak | Freeze bursts (water expands ~9 %); thermal cycling | Realistic. |
| Battery failure | Li-ion cold-charging damage, thermal runaway; 0–40 °C operating range | Realistic. |
| Radiation alert | Real DONKI SEP events; NASA 250/600 mSv limits; storm shelters; water and hydrogen-rich shielding | **Corrected**: Mars doses, the illness threshold, habitat walls and the cause of SEPs. |

Resource needs per person per day are 0.84 kg O₂ (REAL), 3.5 L water (within NASA's planning range) and 1.2 kg food (GAME, below the ISS's ~1.8 kg including packaging). These are reasonable for an educational simulation and are labelled.

## 5. Scientific references

NASA and other primary sources. All were checked on 14–15 Nov 2026. They are also listed in-game under **NASA data & credits → Science sources & credits**.

**NASA data**
- NASA CCMC DONKI: https://ccmc.gsfc.nasa.gov/tools/DONKI/ · API: https://ccmc.gsfc.nasa.gov/DONKI/api/ · see [NASA_DATA.md](NASA_DATA.md)

**Radiation**
- NASA-STD-3001 radiation technical brief (600 mSv career, 250 mSv per SPE): https://www.nasa.gov/wp-content/uploads/2023/03/radiation-protection-technical-brief-ochmo.pdf
- Simonsen, Zawaski & Weeks (2025), *Moon 2 Mars Space Radiation Protection*, NASA NTRS: https://ntrs.nasa.gov/citations/20250006168
- Hassler et al. (2014), Curiosity RAD, *Science*: https://doi.org/10.1126/science.1244797
- Zhang et al. (2020), Chang'e 4 LND, *Science Advances*: https://doi.org/10.1126/sciadv.aaz1334
- NASA (2024), *NASA Watches Mars Light Up During Epic Solar Storm* (8,100 µGy on the surface): https://www.nasa.gov/solar-system/nasa-watches-mars-light-up-during-epic-solar-storm/
- ESA (2023), *Giant solar eruption felt on Earth, Moon and Mars* (30× less on Mars's surface): https://www.esa.int/Science_Exploration/Human_and_Robotic_Exploration/Exploration/ExoMars/Giant_solar_eruption_felt_on_Earth_Moon_and_Mars
- CDC, *Acute Radiation Syndrome: Information for Clinicians*: https://www.cdc.gov/radiation-emergencies/hcp/clinical-guidance/ars.html

**Life support**
- NASA, MOXIE completes Mars mission: https://www.nasa.gov/missions/mars-2020-perseverance/perseverance-rover/nasas-oxygen-generating-experiment-moxie-completes-mars-mission/
- NASA, ISS water recovery milestone (98 %): https://www.nasa.gov/missions/station/iss-research/nasa-achieves-water-recovery-milestone-on-international-space-station/
- NASA History, oxygen candles (lithium perchlorate, Mir fire): https://www.nasa.gov/history/25-years-ago-fire-aboard-space-station-mir/
- NASA, space farming (Veggie): https://www.nasa.gov/technology/tech-transfer-spinoffs/space-farming-yields-a-crop-of-benefits-for-earth/

**Power and dust**
- NASA NTRS, KRUSTY test results (2018): https://ntrs.nasa.gov/citations/20180005435
- NASA, Fission Surface Power (≥ 100 kW): https://www.nasa.gov/general/nasa-seeks-industry-feedback-on-fission-surface-power/
- NASA, Electrodynamic Dust Shield on Blue Ghost (2025): https://www.nasa.gov/blogs/missions/2025/03/14/nasa-science-data-received-blue-ghost-captures-eclipse-from-moon/
- NASA JPL, Opportunity and the 2018 dust storm (τ 10.8): https://www.jpl.nasa.gov/news/opportunity-hunkers-down-during-dust-storm/
- The Planetary Society, Opportunity power 645 → 22 Wh: https://www.planetary.org/articles/06-mer-update-opportunity-dust-storm-sleep

**Mars**
- NASA JPL, InSight magnitude-5 marsquake: https://www.jpl.nasa.gov/news/nasas-insight-records-monster-quake-on-mars/

## 6. Still needs attention

- **Solar-storm frequency is compressed.** Big solar storms that reach Mars's surface are rare: the May 2024 event was the largest Curiosity had measured in 12 years. The game uses one every 2–3 weeks, and this is labelled. A teacher's note could make it explicit.
- **Food mass** (1.2 kg/person/day) is below NASA's ISS planning value (~1.8 kg including packaging). Raising it would make missions harder, so it was left as a labelled GAME value.
- **Global dust storm strength** (up to ~74 % of sunlight blocked) is milder than 2018 (−97 % power). It is labelled. Making it realistic would require a reactor on every long Mars mission.
- **Dose physics is simplified.** The game does not separate absorbed dose (Gy) from dose equivalent (Sv), organ doses or spectrum hardness.
- **An expert review by a teacher or space-radiation scientist** would still be valuable before classroom use. This review is limited to published sources.
