// STEM learning system: life-support science, planet facts, decision analysis and the final mission score.

// ---------- 1. Life-support system explainers ----------
export const SYSTEMS = {
  o2: {
    icon: '🫁', title: 'Oxygen', unit: 'kg',
    need: 'Each astronaut breathes about 0.84 kg of oxygen per day (NASA). Four crew need ~3.4 kg every day.',
    science: [
      ['Breathing', 'Your cells burn sugar with oxygen to release energy: C₆H₁₂O₆ + 6 O₂ → 6 CO₂ + 6 H₂O + energy. That is why the crew uses up O₂ and breathes out CO₂.', 'real'],
      ['Mars: oxygen from the air', 'Mars air is 95% CO₂. A solid-oxide electrolyser heated to ~800 °C splits it: 2 CO₂ → 2 CO + O₂. NASA\'s MOXIE proved this on Perseverance (2021–2023).', 'real'],
      ['Moon: oxygen from ice', 'Electrolysis uses electricity to split water: 2 H₂O → 2 H₂ + O₂. Every 9 kg of water gives 8 kg of oxygen and 1 kg of hydrogen.', 'real'],
      ['Plants help', 'Photosynthesis runs breathing in reverse: 6 CO₂ + 6 H₂O + light → C₆H₁₂O₆ + 6 O₂. Greenhouses add a little oxygen and remove CO₂.', 'real'],
      ['In this game', 'An Oxygen Generator makes 4 kg/day for 2 kW (a scaled-up future plant). The oxygen tank holds 150 kg.', 'game'],
    ],
    tip: 'Keep at least 10 days of oxygen and build a second generator: redundancy means one failure is not a disaster.',
  },
  water: {
    icon: '💧', title: 'Water', unit: 'L',
    need: 'Drinking and food preparation use about 2.5–3.5 L per person per day; washing needs more.',
    science: [
      ['Mining ice', 'Heating icy soil turns the ice into water vapour, which is collected and condensed. Radar from orbit found buried ice in Mars\'s mid-latitudes; on the Moon it hides in craters that never see sunlight.', 'real'],
      ['Recycling', 'The ISS cleans urine, sweat and breath moisture by distillation and filtering, and reached 98% water recovery in 2023.', 'real'],
      ['Water has many jobs', 'Drinking, growing plants, making oxygen (on the Moon) and even shielding against radiation. Hydrogen-rich water is good at stopping protons.', 'real'],
      ['In this game', 'Each astronaut uses 3.5 L/day; a Water Recycler recovers 90% for up to 4 crew. An Ice Miner makes 20 L/day. Tanks hold 600 L.', 'game'],
    ],
    tip: 'A recycler saves 12.6 L/day for 4 crew for just 1 kW: usually cheaper than mining more ice.',
  },
  food: {
    icon: '🥫', title: 'Food', unit: 'kg',
    need: 'An astronaut needs about 2,500–3,000 kcal per day. ISS food weighs ~1.8 kg per person per day including packaging.',
    science: [
      ['Growing food in space', 'Hydroponic farms grow plants in nutrient water instead of soil, under pink-purple LEDs because plants absorb mostly red and blue light.', 'real'],
      ['It has been done', 'In 2015 ISS astronauts ate red romaine lettuce grown in the station\'s "Veggie" garden.', 'real'],
      ['Plants need energy', 'Growing food takes light, water, CO₂ and nutrients. On the Moon and Mars, the light comes from electricity, so every greenhouse needs power.', 'real'],
      ['In this game', 'Crew eat 1.2 kg/day each. A Greenhouse grows 2.6 kg/day (+25% with the Botanist) and uses 2.5 kW and 2 L of water. Real crops take weeks to grow; the game simplifies this.', 'game'],
    ],
    tip: 'Shipping food from Earth is very expensive. Two or three greenhouses make a long mission self-sufficient.',
  },
  energy: {
    icon: '⚡', title: 'Energy', unit: 'kW',
    need: 'Everything runs on electricity: life support (heat, air, pumps), oxygen generators, miners, greenhouses and labs.',
    science: [
      ['Solar power', 'Power = sunlight × area × efficiency. A 50 m² array of 25%-efficient cells gives 17 kW near the Moon (1361 W/m²) but only 7.4 kW at Mars (590 W/m²), because sunlight weakens with the square of the distance from the Sun.', 'real'],
      ['Energy vs power', 'Power (kW) is how fast energy is used. Energy (kWh) = power × time. A 10 kW base through a 12-hour Martian night needs 120 kWh of batteries.', 'real'],
      ['Nuclear fission', 'Splitting uranium-235 releases heat that is turned into electricity, day and night. NASA\'s Kilopower test (2018) proved small space reactors work.', 'real'],
      ['Load shedding', 'When power runs short, engineers switch off non-essential systems first. In this game life support always gets power first.', 'game'],
    ],
    tip: 'Mars: solar + batteries + clean panels, and a reactor for dust storms. Moon: a reactor for the dark spells.',
  },
  radiation: {
    icon: '☢️', title: 'Radiation', unit: 'mSv',
    need: 'People on Earth receive ~3 mSv per year. NASA\'s career limit for astronauts is 600 mSv.',
    science: [
      ['Two kinds of space radiation', 'Galactic cosmic rays arrive all the time from exploding stars far away. Solar particle events are sudden bursts of protons, accelerated by solar flares and by the shock waves of fast coronal mass ejections (CMEs).', 'real'],
      ['Why Earth is safe', 'Earth\'s magnetic field and thick air stop most particles. The Moon has neither. Mars has no global magnetic field, but its thin air stops most solar protons: in an October 2021 storm, Curiosity on the ground measured about 30 times less than an orbiter above Mars.', 'real'],
      ['Measured doses', 'Curiosity measured ~0.67 mSv/day on Mars\'s surface; China\'s Chang\'e 4 measured ~1.37 mSv/day on the Moon.', 'real'],
      ['Protection', 'Mass absorbs particles: a few metres of regolith, or water walls. A small, well-shielded "storm shelter" protects the crew during solar storms.', 'real'],
      ['NASA limits', 'NASA allows at most 250 mSv from one solar storm and 600 mSv in a whole career. Radiation sickness needs about 700 mSv or more in a short time.', 'real'],
      ['In this game', 'Two Regolith Shields touching the habitat cut storm doses by ~90%. Storm doses over 250 mSv cost crew health; reaching 600 mSv in total means evacuation. Mars storms are much weaker on the ground than Moon storms.', 'game'],
    ],
    tip: 'Build 2 shields next to the habitat early: solar storms come with only a few hours of warning.',
  },
};

// ---------- 2. Planet facts ----------
export const FACTS = {
  mars: [
    'A day on Mars (a sol) lasts 24 hours 39 minutes, only about 40 minutes longer than an Earth day.',
    'Olympus Mons on Mars is the tallest volcano in the solar system, about 22 km high.',
    'Valles Marineris, a canyon on Mars, is about 4,000 km long: it would stretch across the USA.',
    'Mars is red because its dust contains iron oxide, the same chemical as rust.',
    'Sunsets on Mars look blue because fine dust scatters blue light forward.',
    'A year on Mars lasts 687 Earth days.',
    'With 38% of Earth\'s gravity, you could jump about 2.6 times higher on Mars.',
    'MOXIE made 122 g of oxygen on Mars: enough for a small dog to breathe for about 10 hours.',
    'NASA\'s Ingenuity helicopter made 72 flights: the first powered flights on another planet.',
    'Mars\'s moon Phobos is slowly spiralling inwards and will break apart in tens of millions of years.',
    'Mars has seasons because its axis is tilted about 25°, close to Earth\'s 23.4°.',
    'NASA\'s InSight lander recorded more than 1,300 marsquakes.',
    'Liquid water cannot last on Mars\'s surface: the air pressure is so low that it boils and freezes at once.',
    'Radio messages take 3 to 22 minutes to travel between Earth and Mars.',
  ],
  moon: [
    'The Moon is slowly moving away from Earth by about 3.8 cm every year.',
    'Twelve astronauts walked on the Moon between 1969 and 1972.',
    'Apollo astronauts brought back 382 kg of Moon rock and soil.',
    'Apollo astronauts said Moon dust smells like spent gunpowder.',
    'Some shallow moonquakes recorded by Apollo seismometers lasted more than 10 minutes.',
    'Apollo footprints can last millions of years because there is no wind or rain to erase them.',
    'From the Moon, Earth looks about 3.7 times wider than the full Moon looks from Earth.',
    'Some craters at the Moon\'s south pole have not seen sunlight for billions of years.',
    'Shadowed lunar polar craters can be colder than −230 °C: among the coldest places measured in the solar system.',
    'The Moon has almost no atmosphere, so the sky is black even in daytime.',
    'On the Moon a 60 kg astronaut weighs about as much as a 10 kg object does on Earth.',
    'In 2009 NASA\'s LCROSS crashed a rocket stage into Cabeus crater and detected water in the plume.',
    'Radio messages reach the Moon in about 1.3 seconds.',
    'We always see the same side of the Moon because it spins exactly once per orbit (tidal locking).',
  ],
};

// ---------- 3. Engineering consequences and decision verdicts ----------
export const GRADES = {
  best: { label: 'Best call', icon: '✅', value: 1 },
  good: { label: 'Good call', icon: '👍', value: 0.7 },
  risky: { label: 'Risky call', icon: '⚠️', value: 0.35 },
  poor: { label: 'Poor call', icon: '❌', value: 0 },
};

export const ENG = {
  'dust.powerplan': 'Load shedding: cutting 4.5 kW of non-essential demand lets the batteries carry life support through dark, dusty sols. The price is no science and no new materials during the storm.',
  'mars.dust.eva': 'Clean, re-angled panels catch more of the hazy light that gets through the dust. Every spacewalk uses suit oxygen and wears out the crew.',
  'dust.ride': 'Nothing changes. Solar output falls with the thickness of the dust, so the batteries may run empty at night and life support could lose power.',
  'moon.dust.eva': 'Hand-brushing restores full solar power at once, but lunar dust is sharp and abrasive: it scratches visors and irritates eyes and lungs.',
  'dust.eds': 'Electric fields push the charged dust off without a spacewalk. It costs parts and stored energy but saves crew time and health.',
  'dust.leave': 'Moon dust does not blow away. As long as the panels stay coated, the base loses about 40% of its solar power.',
  'o2fail.repair': 'Replacing the damaged parts restores full capacity. It costs the most, but the oxygen supply becomes reliable again.',
  'o2fail.filter': 'Clearing the dust restores airflow, but the cracked cell keeps the generator at 70%: cheaper now, less oxygen every day afterwards.',
  'o2fail.flush': 'Rinsing removes the mineral scale and brings the generator back to 75%, but it uses precious water.',
  'o2fail.candles': 'Oxygen candles release oxygen from a chemical (LiClO₄ → LiCl + 2 O₂). They buy time, but they cannot replace a generator: the crew still needs 3.4 kg of oxygen every day.',
  'o2fail.makedo': 'With no materials, the generator stays broken. Oxygen falls by about 3.4 kg per day until you repair it.',
  'waterleak.replace': 'A permanent fix: the leak stops and no more water is lost.',
  'waterleak.patch': 'A temporary seal slows the leak to a quarter, but water keeps seeping out for days.',
  'waterleak.heat': 'Water expands about 9% when it freezes, which is what bursts pipes. Heaters fix the pipe and keep it above freezing, so future leaks are smaller.',
  'waterleak.reroute': 'Using the recycler as a bypass stops the loss and recovers water, but the extra load wears the recycler.',
  'waterleak.buckets': 'Catching the drips saves some water, but the leak keeps going until it is properly repaired.',
  'batfail.replace': 'New cells restore full storage, which matters most during nights, dust storms and dark spells.',
  'batfail.isolate': 'Disconnecting damaged cells is the safe engineering choice, but the base has less storage until the bank is repaired.',
  'batfail.gamble': 'Damaged lithium cells can go into thermal runaway: one hot cell heats its neighbours until they catch fire.',
  'radiation.shelter': 'Mass between the crew and the Sun\'s protons absorbs them. Sheltering stops the lab and outside work for half a day.',
  'radiation.waterwall': 'Water is full of hydrogen, which is very good at stopping protons. Most of the water is put back afterwards.',
  'radiation.work': 'Spacesuits give little protection from energetic solar protons, so the outside team gets the full dose. Engineers follow ALARA: keep doses As Low As Reasonably Achievable.',
  'endure': 'Nothing could be done, so the base absorbs the full effect. A Fabricator keeps materials coming for emergencies.',
};
export const engText = (planet, type, id) => ENG[`${planet}.${type}.${id}`] || ENG[`${type}.${id}`] || ENG[id] || ENG.endure;

const powerSafe = (e) => e.count('reactor') > 0 || (e.stats.cap >= 280 && e.res.battery >= e.stats.cap * 0.6);
const o2Days = (e) => e.res.o2 / Math.max(0.1, 0.84 * Math.max(1, e.crewActive()));

// Context-aware verdict: looks at the base when the decision was made.
export function judgeChoice(e, em, c) {
  const k = `${em.type}.${c.id}`, mars = em.planet === 'mars';
  const otherGen = [...e.buildings.values()].some((b) => b.type === 'oxygen' && b.built && b.id !== em.target && b.cond > 0 && b.on);
  const shields = e.habitatShields();
  const sunSoon = e.computeEnv(e.t + 0.5).sunFactor;
  const g = (grade, why) => ({ grade, why });
  switch (k) {
    case 'dust.powerplan': return powerSafe(e) ? g('good', 'Safe choice, but your reactor or full batteries could already carry life support, so you gave up science you may not have needed to.') : g('best', 'Without a reactor, cutting non-essential load is exactly what engineers do: the Opportunity rover\'s team used low-power modes to survive dust storms.');
    case 'dust.eva': if (mars) return em.level >= 2 || (e.storm && e.storm.peak > 0.85) ? g('risky', 'Spacewalks in a thick, late-mission storm are dangerous and cost crew health; the extra light gained is small.') : g('good', 'Clean panels help a lot in a light storm, at the cost of some crew health.');
      return e.res.mat < 60 ? g('best', 'You could not afford dust shields, so a quick spacewalk was the smartest way to get full power back.') : g('good', 'Full power right away, but the dust shield would have avoided the health cost.');
    case 'dust.ride': return powerSafe(e) ? g('good', 'Your reactor or well-charged batteries can carry life support, so riding it out is reasonable.') : g('poor', `With no reactor and only ${Math.round(e.res.battery)} kWh stored, nights in the storm may leave life support without power.`);
    case 'dust.eds': return e.res.mat + 40 >= 150 ? g('best', 'You had materials to spare, and the shield restores power without risking the crew.') : g('good', 'It works, but it used materials you may need for repairs.');
    case 'dust.leave': return sunSoon < 0.1 ? g('good', 'The Sun is behind the massif anyway, so dirty panels cost nothing right now. Clean them before sunrise!') : g('poor', 'In sunlight, dirty panels waste about 40% of your solar power every hour until someone cleans them.');
    case 'o2fail.repair': return otherGen && o2Days(e) > 15 ? g('good', 'Reliable, but you had a second generator and plenty of oxygen: a cheaper fix would also have worked.') : g('best', 'Oxygen is the most urgent need. With no backup generator, a full repair was the right call.');
    case 'o2fail.filter': case 'o2fail.flush': return otherGen || o2Days(e) > 12 ? g('best', 'A cheap partial fix is smart when you have backup oxygen or a second generator.') : g('good', 'It works, but at reduced output your oxygen margin stays thin; a full repair would be safer.');
    case 'o2fail.candles': return otherGen ? g('good', 'Your other generator keeps running, so candles bridge the gap. Remember to repair the broken one!') : o2Days(e) < 6 ? g('risky', 'Candles buy a few days, but the only generator stays off. Repair it as soon as you have materials.') : g('poor', 'Your only generator stays off and the crew still needs 3.4 kg of oxygen a day. Candles only delay the problem.');
    case 'o2fail.makedo': return g('risky', 'No affordable fix. Build an ISRU Fabricator so you always have materials for emergencies.');
    case 'waterleak.replace': return mars && !e.pipeHeated && e.days - e.t > 20 ? g('good', 'Fixed for good, but pipe heaters would also have halved future freeze leaks on a long Mars mission.') : g('best', 'A permanent repair stops all water loss.');
    case 'waterleak.patch': return e.count('ice') > 0 ? g('good', 'Your Ice Miner can make up the slow seep, so a cheap patch is acceptable.') : g('risky', 'Without an Ice Miner, every litre lost is gone for good. A proper repair would be safer.');
    case 'waterleak.heat': return g('best', 'You fixed the cause, not just the symptom: warm pipes do not freeze and burst.');
    case 'waterleak.reroute': return g('best', 'Clever reuse of existing equipment: no materials spent and water recovered.');
    case 'waterleak.buckets': return g('risky', 'Better than nothing, but the leak continues. Keep materials in reserve for repairs.');
    case 'batfail.replace': return powerSafe(e) && e.count('reactor') > 0 ? g('good', 'Full storage restored, though your reactor already guaranteed night power: isolating would have been cheaper.') : g('best', 'Storage keeps life support alive through nights and storms, so restoring it was the right call.');
    case 'batfail.isolate': return e.count('reactor') > 0 ? g('best', 'Safe and free: your reactor covers the lost storage.') : g('good', 'The safe engineering choice, but with less storage your nights get tighter. Repair the bank soon.');
    case 'batfail.gamble': return g('poor', `Reconnecting damaged cells risked a ${Math.round((0.5 + 0.1 * em.level) * 100)}% chance of fire. Engineers never gamble with thermal runaway.`);
    case 'radiation.shelter': return shields >= 2 ? g('best', 'Your 2 shields plus the shelter cut the dose by about 95%.') : g('good', `Sheltering halves the dose, but with only ${shields} shield${shields === 1 ? '' : 's'} touching the habitat the crew still gets a lot. Build 2 shields!`);
    case 'radiation.waterwall': return shields < 2 && e.res.water > 150 ? g('best', 'Without enough shields, a water wall was the best protection, and you could spare the water.') : g('good', 'Good protection and the lab kept working, but it tied up water you might need.');
    case 'radiation.work': return em.dose > 250 ? g('poor', `Two astronauts took about ${em.dose} mSv each: over NASA's 250 mSv limit for one solar storm, enough to make them ill and a big part of their 600 mSv career limit.`) : g('risky', `Two astronauts took about ${em.dose} mSv each. That is below NASA's 250 mSv storm limit, but it used up ${Math.round(em.dose / 6)}% of their 600 mSv career limit just to keep building. Avoidable doses should be avoided.`);
    default: return g('risky', 'There was no good option available. Keep materials and spare capacity for emergencies.');
  }
}

// ---------- 4. Survival score and astronaut ranks ----------
export const RANKS = {
  gold: { name: 'Gold Astronaut', icon: '🥇', color: '#ffd23f' },
  silver: { name: 'Silver Astronaut', icon: '🥈', color: '#d6dde8' },
  bronze: { name: 'Bronze Astronaut', icon: '🥉', color: '#e0955a' },
  cadet: { name: 'Astronaut Cadet', icon: '🎓', color: '#93a0b4' },
};

export function survivalScore(e, win) {
  const R = e.report, time = Math.max(0.01, R.time || 0);
  const daysFrac = Math.min(1, Math.min(e.t, e.days) / e.days);
  const alive = e.crewActive();
  const act = e.crew.filter((c) => c.status === 'active');
  const avgHealth = act.length ? act.reduce((a, c) => a + c.health, 0) / act.length : 0;
  const avgDose = e.crew.reduce((a, c) => a + c.dose, 0) / e.crew.length;
  const n = Math.max(1, alive);
  const reserveDays = Math.min(e.res.o2 / (0.84 * n), e.res.water / (3.5 * n * 0.3), e.res.food / (1.2 * n));
  const graded = e.decisions.filter((d) => d.grade);
  const quality = graded.length ? graded.reduce((a, d) => a + GRADES[d.grade].value, 0) / graded.length : 0.75;
  const bs = [...e.buildings.values()].filter((b) => b.built && b.type !== 'shield' && b.type !== 'lander');
  const avgCond = bs.length ? bs.reduce((a, b) => a + b.cond, 0) / bs.length : 100;
  const uptime = R.time ? (R.powerOkTime || 0) / time : 1, noShort = R.time ? 1 - (R.shortageTime || 0) / time : 1;
  const maint = Math.max(0, Math.min(1, (avgCond - 25) / 55)); // 80%+ average condition = full marks
  const quizAcc = e.quizCount ? e.quizScore / e.quizCount : 0.5;
  const goalFrac = e.objDone.size / e.objectives.length;
  const parts = {
    survival: { label: 'Survival', max: 35, value: 20 * daysFrac + 15 * (alive / 4), detail: `${Math.floor(Math.min(e.t, e.days))}/${e.days} days, ${alive}/4 crew` },
    health: { label: 'Crew health', max: 15, value: 10 * (avgHealth / 100) * (alive / 4) + 5 * Math.max(0, 1 - avgDose / 600), detail: `avg health ${Math.round(avgHealth)}%, avg dose ${Math.round(avgDose)} mSv` },
    resources: { label: 'Resources', max: 15, value: (10 * Math.max(0, noShort) + 5 * (alive ? Math.min(1, reserveDays / 10) : 0)) * daysFrac, detail: `no shortages ${Math.round(noShort * 100)}% of the time, ${Math.floor(reserveDays)} days of reserves left` },
    engineering: { label: 'Engineering', max: 25, value: (10 * quality + 7 * uptime + 8 * maint) * daysFrac, detail: `decision quality ${Math.round(quality * 100)}%, power uptime ${Math.round(uptime * 100)}%, equipment ${Math.round(avgCond)}%` },
    learning: { label: 'Learning', max: 10, value: 6 * quizAcc + 4 * goalFrac, detail: `quiz ${e.quizScore}/${e.quizCount}, goals ${e.objDone.size}/${e.objectives.length}` },
  };
  Object.values(parts).forEach((p) => { p.value = Math.max(0, Math.min(p.max, p.value)); });
  const total = Math.round(Object.values(parts).reduce((a, p) => a + p.value, 0));
  let rank = 'cadet';
  if (win && total >= 85 && alive === 4) rank = 'gold';
  else if (win && total >= 70 && alive >= 3) rank = 'silver';
  else if (win) rank = 'bronze';
  const grades = { best: 0, good: 0, risky: 0, poor: 0 };
  graded.forEach((d) => { grades[d.grade]++; });
  return { total, parts, rank, grades, quality, uptime, noShort, avgHealth, avgDose, reserveDays, avgCond };
}
