// Junior Astronaut simulation engine — no DOM/3D code. React and R3F read from it.
import { PLANETS, BUILDINGS, CODEX, OBJECTIVES, CREW, QUIZ, SECONDS_PER_DAY, MISSION_DAYS, THREAT, threatLevel } from './data.js';
import { Sound, Toasts, Modals, vibrate } from './bus.js';
import { buildEmergency, payCosts } from './emergencies.js';
import { FACTS, GRADES, judgeChoice, engText, survivalScore } from './learning.js';

export const GRID = 14;
export const TILE = 3;
export const HALF = (GRID * TILE) / 2;
export const LANDING_PAD = [0, 0, HALF + 7];
export const HAB = { i0: 6, j0: 6, i1: 7, j1: 7 }; // habitat occupies a 2×2 block at the centre
export const tileToWorld = (i, j) => [(i + 0.5) * TILE - HALF, 0, (j + 0.5) * TILE - HALF];
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
export const habDist = (i, j) => Math.max(i < HAB.i0 ? HAB.i0 - i : i > HAB.i1 ? i - HAB.i1 : 0, j < HAB.j0 ? HAB.j0 - j : j > HAB.j1 ? j - HAB.j1 : 0);

const SOLAR_PEAK = { mars: 7.4, moon: 17 };
// storage limits: tanks, pantry and a materials yard (anything above is vented or wasted)
export const STORE_CAP = { o2: 150, water: 600, food: 300, mat: 2500 };
const MOON_AZ0 = 2.2;
export const angDiff = (a, b) => { let d = (a - b) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };
export const moonSunAz = (P, t) => (t / P.lunarDay) * Math.PI * 2 + MOON_AZ0;
export const moonMassifAz = (P) => moonSunAz(P, (P.darkStart + P.darkEnd) / 2);

export class Engine {
  constructor(planetId, days = MISSION_DAYS) {
    this.planet = PLANETS[planetId];
    this.days = days;
    this.objectives = OBJECTIVES.filter((o) => !o.minDays || o.minDays <= days);
    this.milestones = [30, 60].filter((m) => m < days);
    this.milestonesDone = new Set();
    this.level = 0;
    this.repairs = 0;
    this.report = { emergencies: 0, minHealth: 100, events: {}, emResolved: 0, emFailed: 0,
      time: 0, shortageTime: 0, powerOkTime: 0, energyKWh: 0, recycledL: 0,
      made: { o2: 0, water: 0, food: 0, mat: 0 }, used: { o2: 0, water: 0, food: 0, mat: 0 },
      minRes: { o2: 45, water: 70, food: 75 } };
    // live per-source flows for the science explainers (units per day)
    this.flows = { o2: {}, water: {}, food: {} }; this.flowAcc = { o2: {}, water: {}, food: {} }; this.flowTime = 0;
    this.factsSeen = [];
    this.report.explainers = new Set(); // life-support science topics the player opened
    this.points = 0; this.decisions = []; this.activeEm = []; this.emId = 0;
    this.pipeHeated = false; this.landerCapLoss = 0;
    this.cargoEvery = planetId === 'mars' ? 15 : 6;
    this.t = planetId === 'mars' ? 0.3 : 0.2;
    this.speed = 1; this.prevSpeed = 1;
    this.res = { o2: 45, water: 70, food: 75, mat: 700, battery: 50, science: 0 };
    this.buildings = new Map(); this.nextId = 1;
    this.occ = Array.from({ length: GRID }, () => Array(GRID).fill(null));
    this.ice = new Set();
    this.crew = CREW.map((c) => ({ ...c, health: 100, dose: 0, status: 'active' }));
    this.objDone = new Set(); this.codex = new Set(); this.quizUsed = new Set();
    this.quizScore = 0; this.quizCount = 0;
    this.stats = { prod: 0, demand: 2, ratio: 1, habRatio: 1, cap: 50, flags: {} };
    this.storm = null; this.spe = null; this.over = false; this.result = null;
    this.nextResupply = null;
    this.rateAcc = { o2: 0, water: 0, food: 0, mat: 0, science: 0, time: 0 };
    this.rates = { o2: 0, water: 0, food: 0, mat: 0, science: 0 };
    this.effects = []; this.effectId = 1;
    this.shake = 0;
    this.ui = { buildType: null, ghost: null, selected: null };
    this.structVersion = 0;
    this._subs = new Set();
    this.env = this.computeEnv(this.t);

    // starting base: central habitat, lander, one solar array, one greenhouse
    this.addBuilding('habitat', HAB.i0, HAB.j0, true);
    this.addBuilding('lander', 9, 7, true);
    this.addBuilding('solar', 4, 6, true);
    this.addBuilding('greenhouse', 6, 9, true);
    const iceTiles = planetId === 'moon'
      ? [[11, 1], [12, 1], [11, 2], [12, 2], [13, 2], [12, 3], [10, 2], [13, 1]]
      : [[11, 9], [12, 9], [11, 10], [12, 10], [13, 10], [12, 11], [11, 11], [13, 11]];
    this.iceTiles = iceTiles;
    iceTiles.forEach(([i, j]) => this.ice.add(`${i},${j}`));
    this._scheduleEvents();
    this.codex.add(`planet_${planetId}`); this.codex.add('gravity'); this.codex.add('solar'); this.codex.add('greenhouse');
  }

  // ---------- subscriptions ----------
  subscribe = (fn) => { this._subs.add(fn); return () => this._subs.delete(fn); };
  getVersion = () => this.structVersion;
  bump() { this.structVersion++; this._subs.forEach((f) => f()); }

  // ---------- environment (sun, day/night) ----------
  computeEnv(t) {
    const P = this.planet;
    let el, az, sunFactor;
    if (P.id === 'mars') {
      const phase = ((t % 1) + 1) % 1;
      const ang = (phase - 0.25) * Math.PI * 2;
      const s = Math.sin(ang);
      el = s * (58 * Math.PI / 180) - 0.05;
      az = ang - Math.PI / 2 + 0.4;
      sunFactor = Math.max(0, s);
    } else {
      // Lunar south pole: the Sun circles the horizon once per synodic month (29.53 Earth days)
      // and is hidden whenever its azimuth is behind the high terrain of a distant massif.
      az = moonSunAz(P, t);
      const hw = ((P.darkEnd - P.darkStart) / 2 / P.lunarDay) * Math.PI * 2;
      const edge = (0.4 / P.lunarDay) * Math.PI * 2;
      const lit = smooth(hw - edge, hw + edge, Math.abs(angDiff(az, moonMassifAz(P))));
      el = (-5 + lit * 13) * Math.PI / 180; // render angle (real Sun is only ~1.5° high; exaggerated so the base is lit)
      sunFactor = lit; // vertical sun-tracking panels: full output whenever the Sun is visible
    }
    const sunDir = [Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)];
    const day = P.id === 'mars' ? smooth(-0.12, 0.2, Math.sin(el)) : smooth(-0.04, 0.06, Math.sin(el));
    return { el, az, sunDir, sunFactor, day, storm: this.stormIntensity ? this.stormIntensity(t) : 0 };
  }

  // ---------- events schedule ----------
  _scheduleEvents() {
    const D = this.days, P = this.planet;
    const r = (a, b) => a + Math.random() * (b - a);
    const ev = [];
    const add = (day, type, extra = {}) => { if (day > 0.6 && day < D - 0.25) ev.push({ day, type, lvl: threatLevel(day), ...extra }); };
    const every = (start, gap, fn) => { for (let d = start; d < D; d += gap(d)) fn(d); };
    const L = threatLevel;
    if (P.id === 'mars') {
      // regional dust storms every ~2 weeks, longer and thicker at higher threat levels
      every(r(8, 10.5), () => r(12, 16), (d) => add(d, 'duststorm', { dur: 2.5 + L(d) * 0.8 + r(0, 1), peak: [0.6, 0.75, 0.85, 0.9][L(d)] }));
      if (D >= 60) add(r(D * 0.66, D * 0.74), 'duststorm', { dur: r(7, 9), peak: 0.93, global: true });
      every(r(4.5, 6.5), () => r(8, 11), (d) => add(d, 'dustdevil'));
      every(r(16, 19), () => r(20, 26), (d) => add(d, 'spe', { dose: Math.round(55 * [1, 1.15, 1.3, 1.45][L(d)]) })); // Mars air stops most solar protons
      every(r(6, 8), () => r(18, 24), (d) => add(d, 'quake'));
      every(r(19, 21), () => r(22, 30), (d) => add(d, 'meteor'));
    } else {
      // the low polar Sun passes behind the massif once every lunar day (29.53 Earth days)
      for (let k = 0; ; k++) {
        const ds = P.darkStart + k * P.lunarDay, de = P.darkEnd + k * P.lunarDay;
        if (ds - 2 >= D) break;
        add(ds - 2, 'dark_warn', { start: ds, end: de }); add(ds, 'dark'); add(de, 'dawn');
      }
      every(r(7, 9), () => r(14, 17), (d) => add(d, 'spe', { dose: Math.round(350 * [1, 1.1, 1.2, 1.3][L(d)]) }));
      every(r(4, 5.5), (d) => [7, 6, 5, 4][L(d)] * r(0.8, 1.2), (d) => add(d, 'meteor'));
      every(r(14, 16), () => r(18, 24), (d) => add(d, 'quake'));
      every(r(8, 11), (d) => [17, 15, 13, 11][L(d)] * r(0.85, 1.15), (d) => add(d, 'em', { em: 'dust' })); // regolith dust clouds from nearby impacts
    }
    // interactive emergencies: oxygen, water and battery systems fail more often as the base ages
    const deck = ['o2fail', 'waterleak', 'batfail'].sort(() => Math.random() - 0.5);
    let di = 0;
    every(r(5, 7), (d) => [9, 7, 5.5, 4.5][L(d)] * r(0.85, 1.15), (d) => add(d, 'em', { em: deck[di++ % deck.length] }));
    // equipment failures become more frequent as the base ages
    every(r(12, 15), (d) => [16, 13, 11, 9][L(d)] * r(0.8, 1.2), (d) => add(d, 'failure'));
    // new emergencies from threat level II onwards
    const pool = ['leak', 'contamination', 'illness', 'cropblight'];
    let n = 0;
    every(r(21, 25), (d) => [99, 11, 9, 7][L(d)] * r(0.85, 1.15), (d) => add(d, pool[n++ % pool.length]));
    // threat level changes and checkpoints
    THREAT.slice(1).forEach((t, k) => { if (t.from < D) ev.push({ day: t.from, type: 'phase', level: k + 1 }); });
    this.milestones.forEach((m) => ev.push({ day: m, type: 'milestone', m }));
    // short planet facts (toasts) every ~3 days
    every(1, () => r(2.6, 3.4), (d) => add(d, 'fact'));
    // Mission Control quizzes
    const quizGap = D <= 30 ? 3.3 : 3.6;
    every(1.5, () => quizGap, (d) => add(d + r(0, 0.4), 'quiz'));
    for (const e of ev.filter((x) => x.type === 'spe')) ev.push({ day: e.day - 0.25, type: 'spe_warn', dose: e.dose });
    ev.sort((a, b) => a.day - b.day);
    this.events = ev;
  }

  // ---------- buildings ----------
  addBuilding(type, i, j, instant = false) {
    const id = this.nextId++;
    const size = type === 'habitat' ? 2 : 1;
    const b = { id, type, i, j, size, built: instant, progress: instant ? 1 : 0, cond: 100, on: true, dust: 1, popAt: 0 };
    this.buildings.set(id, b);
    for (let a = 0; a < size; a++) for (let c = 0; c < size; c++) this.occ[i + a][j + c] = id;
    this.bump();
    return b;
  }
  worldPos(b) {
    const p = tileToWorld(b.i, b.j);
    if (b.size === 2) { p[0] += TILE / 2; p[2] += TILE / 2; }
    return p;
  }
  count(type) { let n = 0; this.buildings.forEach((b) => { if (b.type === type && b.built) n++; }); return n; }
  // plain-language power advice for the ⚡ gauge (same logic as the ⭐ suggestion)
  powerAdvice() {
    const P = this.planet, S = this.stats, net = S.prod - S.demand;
    if (net >= 0) return '';
    const solarAvg = this.count('solar') * SOLAR_PEAK[P.id] * (P.id === 'mars' ? 0.3 : 0.8) + this.count('reactor') * 10;
    if (S.prod < 0.5) {
      if (P.id === 'moon') return 'Dark: solar makes nothing now. Only a reactor (or stored battery power) keeps you going.';
      return solarAvg < S.demand || S.cap >= S.demand * 13
        ? 'Night, and your batteries are running empty. Your Solar Arrays do not make enough by day to fill them. Add Solar Arrays first: extra batteries cannot help if they never fill up.'
        : 'Night: solar makes nothing now. Battery Banks store daytime power for the night; a reactor works day and night.';
    }
    return 'Using more than you make: add Solar Arrays or a reactor, or switch off the lab.';
  }
  // ⭐ build suggestion for the build bar: urgent survival needs first; null means "follow the mission goals".
  // Uses only what the player can see (stores, daily rates, power failures, the coming lunar dark).
  suggestion() {
    const P = this.planet, R = this.res, S = this.stats, r = this.rates;
    const has = (t) => { let k = 0; this.buildings.forEach((b) => { if (b.type === t) k++; }); return k; };
    const left = (v, rate) => (rate < -0.05 ? v / -rate : Infinity);
    const when = (d) => (d < 1 ? 'less than a day' : `${Math.floor(d)} day${Math.floor(d) === 1 ? '' : 's'}`);
    const freeIce = this.iceTiles.some(([i, j]) => this.occ[i][j] == null);
    const wl = left(R.water, r.water), ol = left(R.o2, r.o2), fl = left(R.food, r.food);
    if (wl < 4) {
      if (!has('recycler')) return { type: 'recycler', why: `Water runs out in ${when(wl)}. A Water Recycler saves 90% of the crew's water.` };
      if (freeIce && has('ice') < 2) return { type: 'ice', why: `Water runs out in ${when(wl)}. An Ice Miner on a blue ice tile makes 20 L a day.` };
    }
    if (ol < 4) return { type: 'oxygen', why: `Oxygen runs out in ${when(ol)}. Build another Oxygen Generator.` };
    if (fl < 5) return { type: 'greenhouse', why: `Food runs out in ${when(fl)}. A Greenhouse grows 2.6 kg a day.` };
    if (P.id === 'moon' && !has('reactor')) {
      for (let k = 0; k < 4; k++) {
        const ds = P.darkStart + k * P.lunarDay, de = P.darkEnd + k * P.lunarDay;
        if (this.t < de && ds - this.t < 8) {
          return { type: 'reactor', why: this.t < ds ? `Darkness from Day ${Math.floor(ds) + 1}: solar panels will stop. Save ${BUILDINGS.reactor.cost} kg for a Fission Reactor.` : 'It is dark: solar makes nothing. Only a Fission Reactor makes power now.' };
        }
      }
    }
    // worn equipment makes less (output = condition %): prompt a repair before it becomes a crisis
    const order = ['oxygen', 'ice', 'recycler', 'greenhouse', 'habitat', 'solar', 'battery', 'reactor', 'fabricator', 'comms', 'lab'];
    const worn = [...this.buildings.values()].filter((b) => b.built && b.cond > 0 && b.cond < 50 && order.includes(b.type))
      .sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type) || a.cond - b.cond)[0];
    const hab = [...this.buildings.values()].find((b) => b.type === 'habitat');
    if (hab && hab.cond < 50) {
      const c = this.repairCost(hab);
      return { type: null, repair: hab.id, why: R.mat >= c ? `The Habitat is leaking air (${Math.round(hab.cond)}%). Tap here, then 🔧 Repair (${c} kg) before the oxygen runs out.` : `The Habitat is leaking air and a repair needs ${c} kg of materials. Get materials fast: answer Mission Control quizzes, build an ISRU Fabricator, or recycle a building you can spare.` };
    }
    if (worn && R.mat >= this.repairCost(worn)) {
      return { type: null, repair: worn.id, why: `Your ${this.bName(worn)} is worn down to ${Math.round(worn.cond)}%, so it works at only ${Math.round(worn.cond)}%. Tap here, then 🔧 Repair (${this.repairCost(worn)} kg).` };
    }
    // a broken life-support machine: repair it, or explain how to find the materials
    const broken = [...this.buildings.values()].filter((b) => b.built && b.cond <= 0 && ['oxygen', 'ice', 'recycler', 'greenhouse'].includes(b.type))
      .sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type))[0];
    if (broken) {
      const c = this.repairCost(broken);
      return { type: null, repair: broken.id, why: R.mat >= c
        ? `Your ${this.bName(broken)} is broken and makes nothing. Tap here, then 🔧 Repair (${c} kg).`
        : `Your ${this.bName(broken)} is broken and a repair needs ${c} kg, but you have ${Math.floor(R.mat)} kg. Get materials: answer Mission Control quizzes, or recycle a building you can spare (you get half its cost back).` };
    }
    // storm-shelter goal: shields only count when they touch the habitat; say so if there is no room left
    if (!this.objDone.has('shield') && this.habitatShields() < 2) {
      let ring = 0;
      for (let i = HAB.i0 - 1; i <= HAB.i1 + 1; i++) for (let j = HAB.j0 - 1; j <= HAB.j1 + 1; j++) if (habDist(i, j) === 1 && this.occ[i][j] == null) ring++;
      const pending = [...this.buildings.values()].filter((b) => b.type === 'shield' && !b.built && habDist(b.i, b.j) === 1).length;
      if (ring + pending + this.habitatShields() < 2) return { type: null, why: 'Shields only protect the crew when they touch the habitat, and every tile around it is in use. Recycle a building next to the habitat to make room for 2 shields.' };
    }
    // the mission goals put the life-support basics first: follow them until oxygen, water recycling and ice mining exist
    const basics = has('oxygen') && has('recycler') && (has('ice') || !freeIce);
    if (!basics) return null;
    if (this.t - (this.lastPowerFail ?? -99) < 1.5) {
      if (P.id === 'mars') {
        const avg = has('solar') * SOLAR_PEAK.mars * 0.3 + has('reactor') * 10;   // rough daily average output
        return avg < S.demand || S.cap >= S.demand * 13
          ? { type: 'solar', why: 'Power ran out: your base uses more than the Solar Arrays make over a whole sol. Add solar (or switch the lab off).' }
          : { type: 'battery', why: 'Power ran out at night: a Battery Bank stores 120 kWh of daytime solar power for the night.' };
      }
      return { type: has('reactor') ? 'solar' : 'reactor', why: 'Power ran out. Add power before building more machines.' };
    }
    if (!has('fabricator') && this.t > 3 && R.mat < 450) return { type: 'fabricator', why: 'Building and repairs use materials. An ISRU Fabricator makes 50 kg a day from local soil, so build one while you can still afford it.' };
    return null;
  }
  habitatShields() { let n = 0; this.buildings.forEach((b) => { if (b.type === 'shield' && b.built && habDist(b.i, b.j) === 1) n++; }); return n; }
  shieldedNear(b) {
    let s = false;
    this.buildings.forEach((o) => {
      if (o.type !== 'shield' || !o.built || o === b) return;
      const d = b.size === 2 ? habDist(o.i, o.j) : Math.max(Math.abs(o.i - b.i), Math.abs(o.j - b.j));
      if (d <= 1) s = true;
    });
    return s;
  }
  canPlace(type, i, j) {
    if (i == null) return { ok: false, why: '' };
    if (this.occ[i][j] != null) return { ok: false, why: 'That tile is already used' };
    const isIce = this.ice.has(`${i},${j}`);
    if (type === 'ice' && !isIce) return { ok: false, why: 'Ice Miners must sit on an ice deposit (blue tiles)' };
    if (type === 'reactor' && habDist(i, j) < 4) return { ok: false, why: 'Too close to the habitat (radiation!). Keep it 4+ tiles away' };
    if (this.res.mat < BUILDINGS[type].cost) return { ok: false, why: 'Not enough materials' };
    let tip = isIce && type !== 'ice' ? 'Tip: save ice tiles for Ice Miners' : '';
    if (type === 'recycler' && [...this.buildings.values()].some((b) => b.type === 'recycler')) tip = 'Tip: one Water Recycler already handles 4 crew. A second one only helps as a spare.';
    if (type === 'shield' && habDist(i, j) !== 1) tip = 'Tip: this shield does not touch the habitat, so it will not protect the crew in a solar storm (it still guards nearby buildings).';
    return { ok: true, why: tip };
  }
  crewActive() { return this.crew.filter((c) => c.status === 'active').length; }
  hasRole(role) { return this.crew.some((c) => c.role === role && c.status === 'active'); }
  bEff(b) { return b.built && b.on && b.cond > 0 ? b.cond / 100 : 0; }
  bName(b) { return b.type === 'habitat' ? 'Habitat' : b.type === 'lander' ? 'Lander' : BUILDINGS[b.type].name; }
  isActive(b) {
    if (!b.built || !b.on || b.cond <= 0) return false;
    const def = BUILDINGS[b.type];
    if (def && def.power < 0) return this.stats.ratio > 0.05;
    return true;
  }
  solarOutput(b) {
    return SOLAR_PEAK[this.planet.id] * this.env.sunFactor * (1 - 0.82 * this.stormIntensity()) * b.dust * this.bEff(b);
  }
  baseCost(b) { return b.type === 'habitat' ? 300 : b.type === 'lander' ? 200 : BUILDINGS[b.type].cost; }
  repairCost(b) { return Math.ceil((this.baseCost(b) * 0.5 * (100 - b.cond)) / 100 * (this.hasRole('Engineer') ? 0.6 : 1)); }
  canEVA() { return !this.spe && this.env.day > 0.3 && this.stormIntensity() < 0.4 && this.crewActive() > 0; }

  hurtCrew(n, amount) {
    const act = this.crew.filter((c) => c.status === 'active').sort(() => Math.random() - 0.5).slice(0, n);
    act.forEach((c) => { c.health = clamp(c.health - amount, 1, 100); });
  }
  repairLander() {
    const cost = Math.round(40 * (this.hasRole('Engineer') ? 0.6 : 1));
    if (!this.landerCapLoss || this.res.mat < cost) return;
    this.res.mat -= cost; this.landerCapLoss = 0; this.repairs++; Sound.done(); this.bump();
  }

  // ---------- interactive emergencies ----------
  triggerEmergency(type, ev = {}) {
    const em = buildEmergency(this, type, ev);
    if (!em) { if (type === 'o2fail') this.fireEvent({ type: 'failure' }); return null; }
    em.onset();
    em.lostCrewAtStart = this.crew.filter((c) => c.status !== 'active').length;
    this.activeEm.push(em);
    this.report.emergencies++;
    this.report.events[type] = (this.report.events[type] || 0) + 1;
    Sound.alert(); vibrate([200, 100, 200]);
    this.shake = Math.max(this.shake, 0.2);
    // autoDecide: optional synchronous decision maker (used by automated test players)
    if (this.autoDecide) this.choose(em, this.autoDecide(em));
    else Modals.open({ custom: 'emergency', em, engine: this, icon: em.icon, title: em.title, dismissable: false, kind: 'emergency', wide: true, buttons: [] }).then((v) => this.choose(em, v));
    this.bump();
    return em;
  }
  choose(em, v) {
    if (!em || em.chosen) return;
    let c = em.choices.find((x) => x.id === v) || (typeof v === 'number' ? em.choices[v] : null) || em.choices[0];
    if (!c.available) c = em.choices.find((x) => x.available);
    // judge the decision against the base as it was when the choice was made
    const verdict = judgeChoice(this, em, c);
    let better = null;
    for (const o of em.choices) {
      if (o === c || !o.available) continue;
      const g = judgeChoice(this, em, o);
      if (GRADES[g.grade].value > GRADES[verdict.grade].value && (!better || GRADES[g.grade].value > GRADES[better.grade].value)) better = { label: o.label, icon: o.icon, grade: g.grade, why: g.why };
    }
    const before = { ...this.res };
    payCosts(this, c.costs);
    c.apply();
    const delta = {};
    for (const k of ['o2', 'water', 'food', 'mat', 'battery']) { const d = this.res[k] - before[k]; if (Math.abs(d) >= 0.5) delta[k] = Math.round(d); }
    if (c.costs && c.costs.health) delta.health = -c.costs.health;
    em.chosen = c;
    em.outcomeAt = this.t + em.duration;
    this.points += c.points;
    const dec = { day: Math.floor(this.t) + 1, type: em.type, title: em.title, icon: em.icon, choice: c.label, choiceIcon: c.icon, choiceId: c.id, points: c.points,
      grade: verdict.grade, why: verdict.why, eng: engText(em.planet, em.type, c.id), better, delta, note: c.note,
      nasa: em.nasa ? { time: em.nasa.firstObs || em.nasa.time, strength: em.nasa.strength, src: em.nasa.src, link: em.nasa.link } : null };
    this.decisions.push(dec);
    em.decision = dec;
    (c.points > 0 ? Sound.good : Sound.click).call(Sound);
    if (!this.autoDecide && !this.noDebrief) Modals.open({ custom: 'debrief', front: true, dec, em, icon: '🧑‍🏫', title: 'Decision debrief', kind: { best: 'good', good: 'good', risky: 'warn', poor: 'danger' }[dec.grade], wide: true, buttons: [{ label: 'Got it: back to the base', value: 'ok', primary: true }] });
    else Toasts.push(`${c.icon} <b>${c.label}</b>: ${c.note}. <b>${c.points >= 0 ? '+' : ''}${c.points} mission points</b>`, c.points > 0 ? 'good' : c.points < 0 ? 'danger' : 'warn', null, 7000);
    this.bump();
  }
  _updateEmergencies(dt) {
    const F = this.stats.flags;
    for (const em of this.activeEm) {
      if (F.cold) em.hadCold = true;
      if (this.crew.filter((c) => c.status !== 'active').length > em.lostCrewAtStart) em.lostCrew = true;
      // ongoing water leak
      if (em.leakRate > 0 && this.t < em.leakUntil) { const w = Math.min(this.res.water, em.leakRate * dt); this.res.water -= w; em.leaked = (em.leaked || 0) + w; }
      // battery gamble: thermal runaway check
      if (em.runawayAt && !em.runawayChecked && this.t >= em.runawayAt) {
        em.runawayChecked = true;
        const roll = em.forceRunaway ?? (Math.random() < em.runawayChance);
        if (roll) {
          em.runaway = true;
          const b = em.target === 'lander' ? null : this.buildings.get(em.target);
          if (b) b.cond = 0; else this.landerCapLoss = 40;
          this.res.battery = 0;
          const pos = b ? this.worldPos(b) : this.worldPos(this.buildings.get(2));
          const near = [...this.buildings.values()].filter((o) => o.built && o !== b && o.type !== 'shield' && Math.hypot(this.worldPos(o)[0] - pos[0], this.worldPos(o)[2] - pos[2]) < 6.5);
          near.forEach((o) => { o.cond = Math.max(0, o.cond - 30); });
          const pen = Math.round(20 * em.mult); this.points -= pen;
          this.decisions.push({ day: Math.floor(this.t) + 1, type: 'batfail', title: 'Thermal runaway', choice: 'Gamble lost', points: -pen });
          this.addEffect('burst', pos, { color: '#ff5a2a' }); this.shake = 0.8; Sound.bad();
          Toasts.push(`🔥 <b>Thermal runaway!</b> The battery caught fire: all stored energy lost${near.length ? ` and ${near.length} nearby building${near.length > 1 ? 's' : ''} damaged` : ''}. −${pen} points`, 'danger', null, 8000);
        } else {
          const bonus = Math.round(5 * em.mult); this.points += bonus;
          Toasts.push(`🎲 The battery held. Lucky this time! +${bonus} points`, 'warn', null, 6000);
        }
        this.bump();
      }
      // outcome
      if (em.chosen && !em.done && this.t >= em.outcomeAt) {
        em.done = true;
        em.onEnd && em.onEnd();
        if (em.type === 'o2fail' && this.buildings.get(em.target) && this.buildings.get(em.target).cond === 0) {
          const pen = Math.round(10 * em.mult); this.points -= pen; this.report.emFailed++;
          Toasts.push(`🫁 The oxygen generator is still broken after ${em.duration} days. Repair it from its info panel! −${pen} points`, 'danger', () => this.select(em.target), 8000);
        } else if (em.success()) {
          const bonus = Math.round(15 * em.mult); this.points += bonus; this.report.emResolved++;
          Toasts.push(`✅ <b>${em.title.replace('!', '')}</b> handled successfully. +${bonus} points`, 'good', null, 6000);
        } else {
          this.report.emFailed++;
          Toasts.push(`⚠️ <b>${em.title.replace('!', '')}</b> caused real damage to the mission. No success bonus.`, 'warn', null, 6000);
        }
        this.bump();
      }
    }
    this.activeEm = this.activeEm.filter((em) => !em.done || (em.leakRate > 0 && this.t < em.leakUntil));
  }
  lunarDust() { return this.dustCloudUntil && this.t < this.dustCloudUntil ? Math.min(1, (this.dustCloudUntil - this.t) / 0.3) * 0.5 : 0; }
  activeAlerts() {
    const out = [];
    for (const em of this.activeEm) {
      if (em.leakRate > 0 && this.t < em.leakUntil) out.push(`WATER LEAK −${em.leakRate.toFixed(0)} L/day`);
      if (em.type === 'o2fail' && this.buildings.get(em.target) && this.buildings.get(em.target).cond === 0) out.push('O₂ GENERATOR OFFLINE');
    }
    if (this.spe && this.spe.mit && this.spe.mit.workOutside) out.push('CREW OUTSIDE IN A SOLAR STORM');
    return out;
  }

  // ---------- player actions ----------
  setSpeed(s) { this.speed = s; if (s) this.prevSpeed = s; this.bump(); }
  startBuild(type) {
    if (this.ui.buildType === type) { this.cancelBuild(); return; }
    this.ui.buildType = type; this.ui.ghost = null; this.ui.selected = null; this.bump();
  }
  cancelBuild() { this.ui.buildType = null; this.ui.ghost = null; this.bump(); }
  setGhost(tile) {
    const g = this.ui.ghost;
    if ((!g && !tile) || (g && tile && g[0] === tile[0] && g[1] === tile[1])) return;
    this.ui.ghost = tile; this.bump();
  }
  place(i, j) {
    const type = this.ui.buildType;
    const v = this.canPlace(type, i, j);
    if (!v.ok) { Sound.bad(); Toasts.push(`✗ ${v.why}`, 'warn', null, 2500); return false; }
    this.res.mat -= BUILDINGS[type].cost;
    this.addBuilding(type, i, j);
    Sound.place();
    this.ui.ghost = null;
    if (this.res.mat < BUILDINGS[type].cost || ['reactor', 'lab', 'comms', 'fabricator'].includes(type)) this.ui.buildType = null;
    this.bump();
    return true;
  }
  select(id) { this.ui.selected = id; if (id != null) { this.ui.buildType = null; this.ui.ghost = null; } this.bump(); }
  toggle(b) { b.on = !b.on; this.bump(); }
  repair(b) {
    const c = this.repairCost(b);
    if (this.res.mat < c || this.spe) return;
    this.res.mat -= c; b.cond = 100; this.repairs++; Sound.done();
    this.addEffect('burst', this.worldPos(b), { color: '#5ad1ff' });
    this.bump();
  }
  clean() {
    if (!this.canEVA()) { Toasts.push('Too dark or stormy for a spacewalk right now.', 'warn'); return; }
    this.buildings.forEach((o) => { if (o.type === 'solar') o.dust = 1; });
    Toasts.push('🧑‍🚀 The crew went on an EVA and brushed the dust off every solar panel.', 'good');
    this.report.cleanings = (this.report.cleanings || 0) + 1;
    this.bump();
  }
  recycle(b) {
    const d = BUILDINGS[b.type];
    this.res.mat += Math.floor(d.cost * (b.built ? 0.5 : 1));
    this.occ[b.i][b.j] = null; this.buildings.delete(b.id);
    this.addEffect('burst', this.worldPos(b), { color: '#ffc23d' });
    this.ui.selected = null; this.bump();
  }

  addEffect(kind, pos, extra = {}) {
    this.effects.push({ id: this.effectId++, kind, pos, born: performance.now(), ...extra });
    this.bump();
  }
  removeEffect(id) { this.effects = this.effects.filter((e) => e.id !== id); this.bump(); }

  // ---------- main tick ----------
  tick(dtReal) {
    const running = this.speed > 0 && !Modals.isOpen() && !this.over;
    if (running) {
      let simDt = (dtReal * this.speed) / SECONDS_PER_DAY;
      while (simDt > 0) {
        const s = Math.min(simDt, 0.01);
        this.t += s; simDt -= s;
        this.env = this.computeEnv(this.t);
        this.step(s);
        if (this.over || Modals.isOpen()) break;
      }
    } else this.env = this.computeEnv(this.t);
    return running;
  }

  stormIntensity(t = this.t) {
    if (!this.storm) return 0;
    const s = this.storm;
    const ramp = Math.min(1, (t - s.start) / 0.5) * Math.min(1, Math.max(0, (s.until + 0.6 - t) / 0.6));
    return clamp(ramp, 0, 1) * s.peak;
  }

  step(dt) {
    const P = this.planet, R = this.res, S = this.stats, env = this.env;
    const n = this.crewActive();
    const stormI = this.stormIntensity();
    // construction
    this.buildings.forEach((b) => {
      if (b.built) return;
      const rate = (24 / BUILDINGS[b.type].buildHours) * (n > 0 ? 1 : 0) * (this.spe && !(this.spe.mit && this.spe.mit.workOutside) ? 0 : 1) * (n >= 3 ? 1 : 0.6);
      b.progress = Math.min(1, b.progress + dt * rate);
      if (b.progress >= 1) this.completeBuilding(b);
    });
    // equipment wear: grows with the threat level (aging machines, dust, thermal cycling)
    this.level = threatLevel(this.t);
    const wear = 0.3 * THREAT[this.level].wear * dt;
    this.buildings.forEach((b) => { if (b.built && b.type !== 'shield' && b.type !== 'lander') b.cond = Math.max(0, b.cond - wear); });
    // power
    let prod = 0, demand = 2, cap = 50 - this.landerCapLoss;
    const peak = SOLAR_PEAK[P.id];
    this.buildings.forEach((b) => {
      const e = this.bEff(b); if (!e) return;
      if (b.type === 'solar') prod += peak * env.sunFactor * (1 - 0.82 * stormI) * b.dust * e;
      else if (b.type === 'reactor') prod += 10 * e;
      else if (b.type === 'battery') cap += 120 * e;
      else if (BUILDINGS[b.type] && BUILDINGS[b.type].power < 0) demand += -BUILDINGS[b.type].power;
      if (P.id === 'mars' && b.type === 'solar') b.dust = Math.max(0.45, b.dust - dt * (0.012 + 0.06 * stormI));
    });
    const hours = dt * 24;
    let ratio = 1, habRatio = 1; // life support gets power first (load shedding)
    const net = prod - demand;
    if (net >= 0) R.battery = Math.min(cap, R.battery + net * hours * 0.92);
    else {
      const need = -net * hours;
      if (R.battery >= need) R.battery -= need;
      else {
        const avail = prod + R.battery / hours;
        habRatio = clamp(avail / 2, 0, 1);
        ratio = demand > 2 ? clamp((avail - 2) / (demand - 2), 0, 1) : 1;
        R.battery = 0;
      }
    }
    R.battery = Math.min(R.battery, cap);
    Object.assign(S, { prod, demand, ratio, habRatio, cap });
    if (habRatio < 1 || ratio < 0.99) this.lastPowerFail = this.t;

    // production
    const FA = this.flowAcc, M = this.report.made, U = this.report.used;
    const add = (k, v, src) => {
      R[k] += v; this.rateAcc[k] += v;
      if (M[k] != null) { if (v > 0) M[k] += v; else U[k] -= v; }
      if (src && FA[k]) FA[k][src] = (FA[k][src] || 0) + v;
    };
    this.report.energyKWh += prod * hours;
    let recCap = 0, o2WaterShort = false;
    const sheltering = !!(this.spe && this.spe.mit && this.spe.mit.shelter);
    this.buildings.forEach((b) => {
      const e = this.bEff(b) * ratio; if (!e) return;
      switch (b.type) {
        case 'oxygen':
          if (P.id === 'moon') {
            const needW = 4.5 * dt * e; const f = Math.min(1, R.water / needW);
            if (f < 1) o2WaterShort = true;
            add('water', -needW * f, 'O₂ generator (electrolysis)'); add('o2', 4 * dt * e * f, 'O₂ generators');
          } else add('o2', 4 * dt * e, 'O₂ generators');
          break;
        case 'ice': add('water', 20 * dt * e * (this.hasRole('Geologist') ? 1.25 : 1), 'Ice miners'); break;
        case 'greenhouse': {
          const needW = 2 * dt * e; const f = Math.min(1, R.water / needW);
          add('water', -needW * f, 'Greenhouse irrigation');
          add('food', 2.6 * dt * e * f * (this.hasRole('Botanist') ? 1.25 : 1), 'Greenhouses'); add('o2', 0.4 * dt * e * f, 'Greenhouse plants');
          break;
        }
        case 'fabricator': if (!sheltering) add('mat', 50 * dt * e); break;
        case 'lab': if (n > 0 && !sheltering) add('science', 10 * dt * e); break;
        case 'comms': add('science', 1 * dt * e); break;
        case 'recycler': recCap += 4 * e; break;
      }
    });
    S.flags.o2WaterShort = o2WaterShort;
    const recFrac = n > 0 ? 0.9 * Math.min(1, recCap / n) : 0;
    add('o2', -0.84 * n * dt, 'Crew breathing');
    add('water', -3.5 * n * dt, 'Crew drinking & washing');
    if (recFrac > 0) { add('water', 3.5 * n * dt * recFrac, 'Water recycler'); this.report.recycledL += 3.5 * n * dt * recFrac; }
    add('food', -1.2 * n * dt, 'Crew meals');
    // a badly worn or damaged habitat leaks air
    const hab = this.buildings.get(1);
    S.flags.leak = !!(hab && hab.cond < 50);
    if (S.flags.leak) add('o2', -(2 + (50 - hab.cond) * 0.06) * dt, 'Habitat air leak');
    this._updateEmergencies(dt);
    const F = S.flags;
    F.noO2 = R.o2 <= 0; F.noWater = R.water <= 0; F.noFood = R.food <= 0; F.cold = habRatio < 0.5;
    for (const k of ['o2', 'water', 'food', 'mat']) R[k] = Math.max(0, Math.min(R[k], STORE_CAP[k]));
    // mission performance tracking for the final report
    const RP = this.report;
    RP.time += dt;
    if (F.noO2 || F.noWater || F.noFood || F.cold) RP.shortageTime += dt;
    if (ratio >= 0.999) RP.powerOkTime += dt;
    for (const k of ['o2', 'water', 'food']) RP.minRes[k] = Math.min(RP.minRes[k], R[k]);
    this.flowTime += dt;
    if (this.flowTime > 0.03) {
      for (const k of ['o2', 'water', 'food']) {
        const out = {};
        for (const src in FA[k]) { const v = FA[k][src] / this.flowTime; const old = this.flows[k][src] || 0; out[src] = src in this.flows[k] ? old * 0.6 + v * 0.4 : v; FA[k][src] = 0; }
        this.flows[k] = out;
      }
      this.flowTime = 0;
    }
    this.rateAcc.time += dt;
    if (this.rateAcc.time > 0.05) {
      for (const k of ['o2', 'water', 'food', 'mat', 'science']) { this.rates[k] = this.rates[k] * 0.6 + (this.rateAcc[k] / this.rateAcc.time) * 0.4; this.rateAcc[k] = 0; }
      this.rateAcc.time = 0;
    }

    // crew health & radiation
    const shields = this.habitatShields();
    const shieldF = shields >= 2 ? 0.1 : shields === 1 ? 0.5 : 0.7; // the habitat walls alone stop some protons
    this.crew.forEach((c) => {
      if (c.status !== 'active') return;
      let dh = this.hasRole('Commander') ? 7.5 : 6;
      if (F.noO2) dh = -75;
      if (F.noWater) dh -= 30;
      if (F.noFood) dh -= 12;
      if (F.cold) dh -= 28 * (1 - habRatio * 2);
      c.health = clamp(c.health + dh * dt, 0, 100);
      c.dose += P.radiationPerDay * (shields >= 2 ? 0.55 : 0.8) * dt;
      if (this.spe) {
        // crew working outside get no benefit from the regolith shields around the habitat
        const m = this.spe.mit;
        const outside = m && m.workOutside && (!m.outside || m.outside.includes(c.name));
        const f = outside ? m.factor : shieldF * (m && !m.workOutside ? m.factor : 1);
        const d = (this.spe.dose / this.spe.dur) * f * dt; c.dose += d; c.stormDose = (c.stormDose || 0) + d;
      }
      if (c.health < this.report.minHealth) this.report.minHealth = c.health;
      if (c.health <= 0) this.loseCrew(c, 'lost');
      else if (c.dose >= 600) this.loseCrew(c, 'evacuated');
    });

    this._reportLosses();
    if (this.storm && this.t > this.storm.until + 0.6) { this.storm = null; Toasts.push('🌤️ The dust storm has cleared. Solar power restored.', 'good'); }
    if (this.spe && this.t > this.spe.until) {
      // acute effects: NASA limits a solar-storm dose to 250 mSv (NASA-STD-3001); above it the crew's health suffers
      // (radiation sickness needs ~700 mSv+ in a short time; mild symptoms from ~300 mSv)
      let worst = 0;
      this.crew.forEach((c) => { if (c.status !== 'active') return; const sd = c.stormDose || 0; worst = Math.max(worst, sd); const hurt = Math.max(0, sd - 250) * 0.25; if (hurt > 0) c.health = clamp(c.health - hurt, 0, 100); });
      if (this.spe.mit && this.spe.mit.waterBack) this.res.water = Math.min(STORE_CAP.water, this.res.water + this.spe.mit.waterBack);
      Toasts.push(`☢️ Solar storm over. Highest storm dose: <b>${Math.round(worst)} mSv</b>. ${worst <= 250 ? 'Within NASA\'s 250 mSv storm limit: no illness, but it adds to the career dose.' : worst < 700 ? 'Over NASA\'s 250 mSv storm limit: some crew feel sick and their cancer risk rose.' : 'Radiation sickness! Crew health dropped.'}`, worst <= 250 ? 'good' : 'warn');
      this.spe = null;
      this.bump();
    }
    if (this.nextResupply != null && this.t >= this.nextResupply) {
      this.nextResupply = this.count('comms') > 0 ? this.t + this.cargoEvery : null;
      if (this.count('comms') > 0) this.resupply();
    }
    while (this.events.length && this.events[0].day <= this.t) this.fireEvent(this.events.shift());
    this.checkObjectives();
    if (!this.over && this.crewActive() === 0) this.endGame(false);
    else if (!this.over && this.t >= this.days) this.endGame(true); // success only after the full mission length
  }

  completeBuilding(b) {
    b.built = true; b.progress = 1; b.popAt = performance.now();
    this.addEffect('burst', this.worldPos(b), { color: '#3dff8a' });
    Sound.done();
    const def = BUILDINGS[b.type];
    Toasts.push(`${def.icon} <b>${def.name}</b> is online!`, 'good');
    if (b.type === 'comms' && this.nextResupply == null) { this.nextResupply = this.t + 2; Toasts.push('📡 Earth link established: first cargo lander in 2 days.', 'info'); }
    if (CODEX[b.type]) this.unlock(b.type);
    this.bump();
  }

  loseCrew(c, why) {
    c.status = why;
    (this._lostNow = this._lostNow || []).push(c);
  }
  // one pop-up per time step, even if several astronauts are lost together
  _reportLosses() {
    const lost = this._lostNow; if (!lost || !lost.length) return;
    this._lostNow = [];
    Sound.bad(); vibrate([300]);
    const F = this.stats.flags;
    const cause = F.noO2 ? 'The base ran out of oxygen.' : F.noWater ? 'The base ran out of water.' : F.noFood ? 'The food ran out.' : 'Life support failed without power.';
    const evac = lost.filter((c) => c.status === 'evacuated'), dead = lost.filter((c) => c.status === 'lost');
    const parts = [];
    if (dead.length) parts.push(`<p>${dead.map((c) => `<b>${c.name}</b>`).join(', ')} did not survive. ${cause}</p>`);
    if (evac.length) parts.push(`<p>${evac.map((c) => `<b>${c.name}</b>`).join(', ')} passed NASA's 600 mSv career radiation limit and must return to Earth.</p>`);
    parts.push(`<p class="muted">Perks lost: ${lost.map((c) => `${c.role} (${c.perk})`).join('; ')}</p>`);
    Modals.open({ icon: dead.length ? '🕯️' : '🚀', title: dead.length ? (dead.length > 1 ? 'Crew members lost' : 'Crew member lost') : 'Crew evacuated', body: parts.join(''), kind: 'danger' });
    this.bump();
  }

  unlock(key, silent) {
    if (this.codex.has(key) || !CODEX[key]) return;
    this.codex.add(key);
    if (!silent) Toasts.push(`📘 New Science Codex entry: <b>${CODEX[key].title}</b>. Tap to read`, 'codex', () => this.onOpenCodex && this.onOpenCodex(key), 6500);
    this.codexPing = performance.now();
  }

  // ---------- events ----------
  fireEvent(e) {
    const P = this.planet;
    if (e.type === 'fact') { this.showFact(); return; }
    const dmgK = THREAT[threatLevel(this.t)].dmg;
    if (['meteor', 'quake', 'failure', 'leak', 'contamination', 'illness', 'cropblight', 'battery_fault', 'dark'].includes(e.type)) {
      this.report.emergencies++;
      this.report.events[e.type] = (this.report.events[e.type] || 0) + 1;
    }
    switch (e.type) {
      case 'quiz': this.quiz(); break;
      case 'duststorm': this.triggerEmergency('dust', e); break;
      case 'em': this.triggerEmergency(e.em, e); break;
      case 'dustdevil': {
        let k = 0; this.buildings.forEach((b) => { if (b.type === 'solar' && b.built) { b.dust = 1; k++; } });
        if (k) { Toasts.push('🌀 A dust devil swept across the base and blew your solar panels clean! (Real "cleaning events" kept Spirit and Opportunity alive.)', 'good', null, 7000); this.unlock('duststorm'); }
        break;
      }
      case 'spe_warn': this.pendingRadiation = this.triggerEmergency('radiation', { dose: e.dose }); break;
      case 'spe': {
        const em = this.pendingRadiation; this.pendingRadiation = null;
        if (em && !em.chosen) this.choose(em, 'shelter'); // no decision made: crew shelters by default
        const mit = em ? em.mit : null;
        this.spe = { until: this.t + 0.5, dur: 0.5, dose: em ? em.dose : e.dose, mit };
        this.crew.forEach((c) => { c.stormDose = 0; });
        Toasts.push(mit && mit.workOutside ? '☢️ Solar storm hitting the base. Crew still working outside!' : '☢️ Solar particle event in progress: crew protected inside.', mit && mit.workOutside ? 'danger' : 'warn', null, 6000);
        this.shake = 0.15;
        this.report.emergencies += em ? 0 : 1;
        this.bump(); // update the HUD (radiation glow) immediately
        break;
      }
      case 'meteor': {
        const pool = [...this.buildings.values()].filter((b) => b.built && !['shield', 'lander'].includes(b.type));
        if (!pool.length) break;
        const b = pool[Math.floor(Math.random() * pool.length)];
        const shielded = this.shieldedNear(b);
        this.addEffect('meteor', this.worldPos(b), {
          onDone: () => {
            if (!this.buildings.has(b.id)) return;
            const dmg = shielded ? 12 : Math.min(85, (45 + Math.random() * 20) * dmgK);
            b.cond = Math.max(0, b.cond - dmg);
            Sound.bad(); vibrate([200]); this.shake = 0.9;
            Toasts.push(`☄️ ${P.id === 'moon' ? 'Micrometeoroid' : 'Meteorite'} hit the <b>${this.bName(b)}</b>! ${shielded ? 'A nearby regolith shield absorbed most of it.' : `Damage: ${Math.round(dmg)}%. Tap it to repair.`}`, shielded ? 'info' : 'danger', () => this.select(b.id), 7000);
            this.unlock('shield');
            this.bump();
          },
        });
        break;
      }
      case 'quake': {
        this.shake = 1.4; Sound.alert();
        const pool = [...this.buildings.values()].filter((b) => b.built && b.type !== 'lander');
        const hit = pool.sort(() => Math.random() - 0.5).slice(0, 2);
        hit.forEach((b) => { b.cond = Math.max(0, b.cond - (12 + Math.random() * 18) * dmgK); });
        this.unlock('quake');
        Toasts.push(`〰️ ${P.id === 'mars' ? 'Marsquake' : 'Moonquake'}! ${hit.map((b) => this.bName(b)).join(' & ')} damaged.`, 'warn', () => this.onOpenCodex && this.onOpenCodex('quake'), 7000);
        this.bump();
        break;
      }
      case 'failure': {
        const pool = [...this.buildings.values()].filter((b) => b.built && ['oxygen', 'ice', 'recycler', 'greenhouse', 'solar'].includes(b.type));
        if (!pool.length) break;
        const b = pool[Math.floor(Math.random() * pool.length)];
        b.cond = Math.min(b.cond, 20);
        Sound.alert();
        Toasts.push(`🔧 Equipment fault: the <b>${this.bName(b)}</b> is running at 20%. Tap it to repair.`, 'danger', () => this.select(b.id), 8000);
        this.bump();
        break;
      }
      case 'dark_warn':
        Sound.alert(); this.unlock('dark', true);
        Modals.open({ icon: '🌑', title: 'Darkness in 2 days', kind: 'warn', body: `<p>At the pole the Sun never sets the normal way: it circles low around the horizon once every 29.5 days. On Day ${Math.floor(e.start) + 1} it will pass behind a distant massif and stay hidden until about Day ${Math.floor(e.end) + 1} (<b>${Math.round(e.end - e.start)} days</b>). Solar arrays will make <b>zero</b> power.</p><p>Have a <b>Fission Reactor</b> running, charge your batteries, and be ready to switch off non-essential buildings.</p><p class="fact">📘 Real rim sites near Shackleton crater are sunlit 80–90% of the time, but dark spells can last up to about a week. At the equator, night lasts about 14.8 Earth days at −173 °C.</p>` });
        break;
      case 'dark': Toasts.push('🌑 The low Sun has slipped behind the massif on the horizon. Earthshine lights the base.', 'warn', null, 7000); break;
      case 'dawn': {
        // electrostatically charged dust is lofted near the light/dark boundary and settles on panels
        let k = 0; this.buildings.forEach((b) => { if (b.type === 'solar' && b.built) { b.dust = Math.min(b.dust, 0.86); k++; } });
        Toasts.push(`🌅 The Sun is back from behind the massif!${k ? ' Charged dust drifted onto the panels in the dark: tap a solar array and clean them for full power.' : ''}`, 'good', null, 8000);
        break;
      }
      case 'phase': {
        const T = THREAT[e.level];
        Sound.alert(); this.unlock('maintenance', true);
        Modals.open({ icon: '📈', title: `Threat level ${T.short}: ${T.name}`, kind: 'warn', body: `<p>Day ${Math.floor(this.t) + 1}. The mission is entering a harder phase:</p><ul><li>Equipment now wears out <b>${T.wear}×</b> faster. Keep repairing buildings.</li><li>Impacts and quakes do <b>${Math.round((T.dmg - 1) * 100)}% more damage</b>.</li><li>Emergencies come more often${P.id === 'mars' ? ' and dust storms grow thicker' : ''}.</li></ul><p class="fact">📘 Long missions get harder as machines age. That's why spare parts, recycling and ISRU matter.</p>` });
        break;
      }
      case 'milestone': {
        this.milestonesDone.add(e.m); this.res.mat += 150; Sound.good();
        Toasts.push(`🏁 Checkpoint: <b>Day ${e.m}</b> reached with ${this.crewActive()}/4 crew. Earth sends congratulations and +150 kg materials.`, 'good', null, 8000);
        break;
      }
      case 'leak': {
        const hab = this.buildings.get(1);
        hab.cond = Math.max(0, Math.min(hab.cond, 45) - 5 * dmgK); this.res.o2 = Math.max(0, this.res.o2 - 4);
        Sound.alert(); vibrate([200, 80, 200]); this.unlock('pressure', true);
        Modals.open({ icon: '🎈', title: 'Habitat air leak!', kind: 'danger', body: `<p>A seal in the habitat has failed and air is hissing out. <b>4 kg of oxygen</b> escaped, and the habitat keeps leaking while its condition is under 50%.</p><p><b>Tap the habitat and repair it</b> as soon as you can.</p><p class="fact">📘 In 2018 the ISS crew sealed a 2 mm leak in a Soyuz spacecraft with epoxy and gauze.</p>` });
        this.bump();
        break;
      }
      case 'contamination': {
        const rec = this.count('recycler') > 0;
        const loss = this.res.water * (rec ? 0.05 : 0.25);
        this.res.water -= loss; Sound.alert();
        Toasts.push(`🦠 Microbes found in the water tank! ${rec ? `The recycler's filters cleaned most of it (lost ${Math.round(loss)} L).` : `Without a Water Recycler to purify it, ${Math.round(loss)} L had to be dumped.`}`, rec ? 'warn' : 'danger', null, 8000);
        break;
      }
      case 'illness': {
        const pool = this.crew.filter((c) => c.status === 'active');
        if (!pool.length) break;
        const c = pool[Math.floor(Math.random() * pool.length)];
        c.health = Math.max(1, c.health - 30 * dmgK); Sound.alert(); this.unlock('health', true);
        Toasts.push(`🤒 ${c.name} is ill and resting. Health −${Math.round(30 * dmgK)}%. Keep oxygen, water, food and heat steady so they recover${this.hasRole('Commander') ? ' (the Commander helps the crew recover faster)' : ''}.`, 'warn', () => this.onOpenCodex && this.onOpenCodex('health'), 8000);
        break;
      }
      case 'cropblight': {
        const gh = [...this.buildings.values()].filter((b) => b.type === 'greenhouse' && b.built);
        if (!gh.length) break;
        const keep = this.hasRole('Botanist') ? 65 : 40;
        gh.forEach((b) => { b.cond = Math.min(b.cond, keep); });
        this.res.food *= 0.92; Sound.alert();
        Toasts.push(`🍂 Plant disease in the greenhouse${gh.length > 1 ? 's' : ''}! Crops damaged to ${keep}%${this.hasRole('Botanist') ? ' (the Botanist limited the damage)' : ''} and 8% of stored food spoiled. Repair the greenhouses.`, 'danger', () => this.select(gh[0].id), 8000);
        this.bump();
        break;
      }
      case 'battery_fault': {
        const bats = [...this.buildings.values()].filter((b) => b.type === 'battery' && b.built);
        if (!bats.length) { this.fireEvent({ type: 'failure' }); break; }
        const b = bats[Math.floor(Math.random() * bats.length)];
        b.cond = Math.min(b.cond, 30); this.res.battery *= 0.5; Sound.alert();
        Toasts.push('🔥 Battery cell overheated! A Battery Bank shut down to 30% and half the stored energy was lost. Repair it.', 'danger', () => this.select(b.id), 8000);
        this.bump();
        break;
      }
    }
  }

  resupply() {
    Toasts.push('🚀 Cargo lander on final approach to the landing pad…', 'info');
    this.report.cargo = (this.report.cargo || 0) + 1;
    this.addEffect('lander', LANDING_PAD, {
      onDone: () => {
        const R = this.res;
        R.food += 25; R.o2 += 15; R.water += 30; R.mat += 120;
        Sound.good(); this.shake = 0.3;
        Toasts.push('📦 Cargo delivered: +25 kg food, +15 kg O₂, +30 L water, +120 kg materials', 'good', null, 7000);
      },
    });
  }

  async quiz() {
    if (this.over) return;
    const pool = [...QUIZ[this.planet.id].map((q, k) => ({ ...q, key: `${this.planet.id}${k}` })), ...QUIZ.general.map((q, k) => ({ ...q, key: `g${k}` }))].filter((q) => !this.quizUsed.has(q.key));
    if (!pool.length) return;
    const q = pool[Math.floor(Math.random() * pool.length)];
    this.quizUsed.add(q.key);
    Sound.tone(600, 0.1, 'triangle', 0.05); Sound.tone(900, 0.12, 'triangle', 0.05, 0.1);
    const order = q.o.map((_, k) => k).sort(() => Math.random() - 0.5);
    const pick = await Modals.open({
      icon: '🛰️', title: 'Mission Control Challenge', kind: 'quiz', dismissable: false,
      body: `<p class="q">${q.q}</p><p class="muted">Answer correctly to earn +60 kg materials and +5 science.</p>`,
      buttons: order.map((k) => ({ label: q.o[k], value: k })),
    });
    const ok = pick === q.a;
    if (ok) { this.res.mat += 60; this.res.science += 5; Sound.good(); } else Sound.bad();
    this.quizScore += ok ? 1 : 0; this.quizCount += 1;
    await Modals.open({
      icon: ok ? '✅' : '❌', title: ok ? 'Correct!' : 'Not quite', kind: ok ? 'good' : 'danger',
      body: `${ok ? '' : `<p>The answer is <b>${q.o[q.a]}</b>.</p>`}<p class="fact">📘 ${q.e}</p>${ok ? '<p class="reward">+60 kg materials · +5 science</p>' : ''}`,
    });
  }

  showFact() {
    const pool = FACTS[this.planet.id];
    const unseen = pool.map((_, k) => k).filter((k) => !this.factsSeen.includes(k));
    if (!unseen.length) return null;
    const k = unseen[Math.floor(Math.random() * unseen.length)];
    this.factsSeen.push(k);
    Toasts.push(`${this.planet.id === 'mars' ? '🔴' : '🌕'} <b>Did you know?</b> ${pool[k]}`, 'fact', null, 9000);
    return pool[k];
  }

  checkObjectives() {
    for (const o of this.objectives) {
      if (this.objDone.has(o.id) || !o.check(this)) continue;
      this.objDone.add(o.id);
      this.res.mat += o.reward;
      Sound.good();
      Toasts.push(`🎯 Goal complete: <b>${o.title}</b>${o.reward ? ` · +${o.reward} kg materials` : ''}`, 'good');
      this.bump();
    }
  }

  endGame(win) {
    if (this.over) return;
    this.over = true;
    this.ui.buildType = null; this.ui.ghost = null;
    const alive = this.crewActive();
    const sci = Math.floor(this.res.science);
    const avgDose = this.crew.reduce((a, c) => a + c.dose, 0) / 4;
    const goalFrac = this.objDone.size / this.objectives.length;
    const sciGoal = Math.round(150 * this.days / 30);
    let stars = 0;
    if (win) { stars = 1; if (alive >= 3) stars = 2; if (alive === 4 && sci >= sciGoal && goalFrac >= 0.8) stars = 3; }
    const daysDone = Math.min(this.t, this.days);
    const score = Math.round(this.points * 2 + alive * 250 * (this.days / 30) + sci * 3 + this.objDone.size * 60 + this.quizScore * 40 + daysDone * 10 + this.report.emergencies * 15 + (win ? 500 : 0) - avgDose);
    win ? Sound.good() : Sound.bad();
    const stem = survivalScore(this, win);
    this.result = { win, alive, sci, sciGoal, avgDose, stars, score, daysDone, goalFrac, level: threatLevel(daysDone), points: this.points, stem, rank: stem.rank };
    this.bump();
  }
}
