// Tiny UI bus: sound, toasts and a modal queue that React components subscribe to.

export const Sound = {
  ctx: null, on: true,
  init() {
    if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { this.on = false; } }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  },
  tone(f, d = 0.08, type = 'sine', v = 0.06, delay = 0, f2) {
    if (!this.on || !this.ctx) return;
    try {
      const t = this.ctx.currentTime + delay, o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g).connect(this.ctx.destination); o.start(t); o.stop(t + d + 0.02);
    } catch (e) { /* ignore */ }
  },
  click() { this.tone(880, 0.05, 'triangle', 0.04); },
  place() { this.tone(330, 0.12, 'square', 0.035, 0, 660); },
  done() { [523, 659, 784].forEach((f, k) => this.tone(f, 0.14, 'triangle', 0.05, k * 0.08)); },
  alert() { [0, 0.22].forEach((d) => this.tone(740, 0.16, 'sawtooth', 0.035, d, 520)); vibrate([120, 60, 120]); },
  good() { [659, 880, 1175].forEach((f, k) => this.tone(f, 0.18, 'sine', 0.05, k * 0.09)); },
  bad() { this.tone(220, 0.3, 'sawtooth', 0.04, 0, 140); },
};
export function vibrate(p) { try { navigator.vibrate && navigator.vibrate(p); } catch (e) { /* ignore */ } }

function emitter() {
  const subs = new Set();
  return { subscribe(fn) { subs.add(fn); return () => subs.delete(fn); }, emit() { subs.forEach((f) => f()); } };
}

// ---- toasts ----
let toastId = 1;
export const Toasts = {
  ...emitter(),
  list: [],
  push(html, kind = 'info', onClick, ms = 5200) {
    const id = toastId++;
    const max = window.innerWidth <= 900 || window.innerHeight <= 500 ? 2 : 4;
    this.list = [{ id, html, kind, onClick }, ...this.list].slice(0, max);
    this.emit();
    setTimeout(() => this.remove(id), ms);
  },
  remove(id) { this.list = this.list.filter((t) => t.id !== id); this.emit(); },
  clear() { this.list = []; this.emit(); },
};

// ---- modals ----
export const Modals = {
  ...emitter(),
  queue: [],
  current: null,
  open(opts) {
    return new Promise((resolve) => {
      if (opts.front) this.queue.unshift({ opts, resolve }); else this.queue.push({ opts, resolve });
      if (!this.current) this._next();
    });
  },
  _next() { this.current = this.queue.shift() || null; this.emit(); },
  close(value) {
    const c = this.current; if (!c) return;
    this.current = null; this.emit();
    c.resolve(value);
    if (this.queue.length) setTimeout(() => { if (!this.current) this._next(); }, 120);
  },
  clear() { this.queue = []; this.current = null; this.emit(); },
  isOpen() { return !!this.current; },
};
