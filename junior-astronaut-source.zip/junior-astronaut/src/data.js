// ===== Junior Astronaut — game data (science values are real-world approximations) =====

export const SECONDS_PER_DAY = 24; // real seconds per in-game day at 1x speed
export const MISSION_DAYS = 90; // default mission length
export const DURATIONS = [
  { days: 30, label: 'Short Mission', note: 'Learn the basics. One storm season, one lunar dark spell.' },
  { days: 60, label: 'Standard Mission', note: 'Equipment starts to age and emergencies grow. Two lunar dark spells.' },
  { days: 90, label: 'Extended Mission', note: 'Full endurance test: aging equipment, a possible global dust storm, three lunar dark spells.' },
];
// Threat levels rise with the mission day (not the mission length), so longer missions reach harder phases.
export const THREAT = [
  { from: 0, name: 'Settling in', wear: 1.0, dmg: 1.0, short: 'I' },
  { from: 20, name: 'Expansion', wear: 1.5, dmg: 1.1, short: 'II' },
  { from: 45, name: 'Endurance', wear: 2.2, dmg: 1.2, short: 'III' },
  { from: 70, name: 'Final push', wear: 3.0, dmg: 1.3, short: 'IV' },
];
export const threatLevel = (day) => (day >= 70 ? 3 : day >= 45 ? 2 : day >= 20 ? 1 : 0);

export const PLANETS = {
  mars: {
    id: 'mars',
    name: 'Mars',
    site: 'Arcadia Planitia',
    siteNote: 'Mid-latitude plains with buried water ice',
    dayUnit: 'Sol',
    accent: '#ff7a3d',
    gravity: 3.71,
    gravityG: 0.38,
    irradiance: 590, // W/m² at Mars (avg)
    solarFactor: 0.43,
    tempMax: -30, // Viking 2 (48°N) early-summer average daily max ≈ 241 K
    tempMin: -82, // ... and daily min ≈ 191 K
    radiationPerDay: 0.67, // mSv/day on surface (Curiosity RAD)
    stats: [
      ['Gravity', '3.71 m/s² (0.38 g)'],
      ['Day length', '1 sol = 24 h 39 min (day and night every sol)'],
      ['Temperature', '−125 to +20 °C planet-wide; ≈ −30 °C day / −80 °C night at this latitude'],
      ['Atmosphere', '95% CO₂, <1% of Earth\'s pressure'],
      ['Sunlight', '~43% of Earth\'s (590 W/m²)'],
      ['Surface radiation', '~0.7 mSv per day'],
      ['Radio delay', '3–22 minutes one way'],
      ['Distance', '55–400 million km'],
    ],
    challenge: 'Weaker sunlight, dust storms and freezing nights every sol.',
  },
  moon: {
    id: 'moon',
    name: 'The Moon',
    site: 'South Pole · Shackleton rim',
    siteNote: 'Crater rim beside a permanently shadowed, ice-filled crater',
    dayUnit: 'Day', // Earth days
    accent: '#5ad1ff',
    gravity: 1.62,
    gravityG: 0.165,
    irradiance: 1361,
    solarFactor: 1.0,
    tempMax: -40, // approximate, sunlit polar rim (sun only ~1.5° high)
    tempMin: -170, // approximate, after days without sunlight
    radiationPerDay: 1.37, // Chang'e 4 LND measurement
    darkStart: 13, // worst-case lunar day at a rim site: Sun hidden behind distant terrain ~6–7 days
    darkEnd: 19,
    lunarDay: 29.53, // synodic month: the Sun circles the polar horizon once per 29.53 Earth days
    sunElevDeg: 1.5,
    stats: [
      ['Gravity', '1.62 m/s² (0.17 g)'],
      ['Day length', '29.5 Earth days. At the pole the Sun circles the horizon and can hide behind hills for days'],
      ['Temperature', '+127 to −173 °C at the equator; polar rim ≈ −40 °C in sun, ≈ −230 °C in shadowed craters'],
      ['Atmosphere', 'Almost none — a near vacuum'],
      ['Sunlight', '100% of Earth\'s orbit value (1361 W/m²)'],
      ['Surface radiation', '~1.4 mSv per day'],
      ['Radio delay', '~1.3 seconds one way'],
      ['Distance', '384,400 km'],
    ],
    challenge: 'No air, sharp dust, micrometeoroids and a 6-day dark spell when the Sun slips behind the hills.',
  },
};

// Building catalogue. power: + produces, − consumes (kW). Rates are per in-game day.
export const BUILDINGS = {
  solar: {
    name: 'Solar Array', icon: '☀️', cost: 80, buildHours: 6, power: 0,
    short: 'Makes power from sunlight',
    desc: (p) => p.id === 'mars'
      ? 'Peak 7.4 kW on Mars. Output falls at night, in dust storms and as dust settles on panels.'
      : 'Peak 17 kW. Vertical panels track the low polar Sun. Zero output during the dark period.',
  },
  battery: {
    name: 'Battery Bank', icon: '🔋', cost: 100, buildHours: 6, power: 0,
    short: 'Stores 120 kWh', desc: () => 'Stores spare solar energy for the night. Adds 120 kWh of storage.',
  },
  reactor: {
    name: 'Fission Reactor', icon: '⚛️', cost: 420, buildHours: 20, power: 10,
    short: '10 kW day and night',
    desc: () => 'A small Kilopower-style reactor: steady 10 kW whatever the weather. Must be at least 4 tiles from the habitat.',
  },
  oxygen: {
    name: 'Oxygen Generator', icon: '🫁', cost: 150, buildHours: 12, power: -2,
    short: '+4 kg O₂/day',
    desc: (p) => p.id === 'mars'
      ? 'Scaled-up MOXIE: splits CO₂ from the Martian air into O₂. Uses 2 kW.'
      : 'Electrolyser: splits water into hydrogen and oxygen. Uses 2 kW and 4.5 L water per day.',
  },
  ice: {
    name: 'Ice Miner', icon: '🧊', cost: 150, buildHours: 12, power: -1.5,
    short: '+20 L water/day · on ice',
    desc: () => 'Digs icy regolith, heats it and collects the meltwater. Must be built on an ice deposit (blue tiles).',
  },
  recycler: {
    name: 'Water Recycler', icon: '♻️', cost: 120, buildHours: 8, power: -1,
    short: 'Recovers 90% of water',
    desc: () => 'Cleans sweat, wash water and urine back into drinking water for up to 4 crew. Uses 1 kW.',
  },
  greenhouse: {
    name: 'Greenhouse', icon: '🌱', cost: 200, buildHours: 18, power: -2.5,
    short: '+2.6 kg food, +0.4 kg O₂',
    desc: () => 'LED-lit hydroponic farm. Plants turn CO₂ and water into food and oxygen. Uses 2.5 kW and 2 L water/day.',
  },
  shield: {
    name: 'Regolith Shield', icon: '🧱', cost: 40, buildHours: 4, power: 0,
    short: 'Blocks radiation & impacts',
    desc: () => 'A 3D-printed berm of local soil. Shields next to the habitat cut radiation; shields protect neighbouring buildings from impacts.',
  },
  fabricator: {
    name: 'ISRU Fabricator', icon: '🏭', cost: 180, buildHours: 12, power: -3,
    short: '+50 kg materials/day',
    desc: () => 'Turns local regolith into building material by sintering and 3D printing. Uses 3 kW.',
  },
  lab: {
    name: 'Science Lab', icon: '🔬', cost: 200, buildHours: 12, power: -1.5,
    short: '+10 science/day',
    desc: () => 'Crew analyse rock, ice and dust samples here. Uses 1.5 kW.',
  },
  comms: {
    name: 'Comms Dish', icon: '📡', cost: 120, buildHours: 8, power: -0.5,
    short: 'Unlocks cargo landers',
    desc: (p) => `Links the base to Earth (${p.id === 'mars' ? '3–22 min' : '1.3 s'} delay). ${p.id === 'mars' ? 'A cargo lander arrives every 15 sols from an imagined depot in Mars orbit' : 'Earth sends a cargo lander every 6 days'}.`,
  },
};

export const BUILD_ORDER = ['solar', 'battery', 'oxygen', 'ice', 'recycler', 'greenhouse', 'shield', 'fabricator', 'lab', 'comms', 'reactor'];

// Codex entries: unlocked when the matching building is first completed (or at start).
export const CODEX = {
  planet_mars: {
    title: 'Mars — the Red Planet', icon: '🔴',
    text: 'Mars is red because its dust contains iron oxide (rust). Its air is 95% carbon dioxide and so thin that the pressure is less than 1% of Earth\'s. Liquid water cannot last on the surface: it quickly freezes or evaporates. But there is a lot of water ice under the ground, which makes plains like Arcadia Planitia good places for a base.',
  },
  planet_moon: {
    title: 'The Moon\'s South Pole', icon: '🌙',
    text: 'The Moon\'s axis is tilted only about 1.5°, so near the poles the Sun skims along the horizon. Some crater rims get sunlight most of the time, while the floors of deep craters have not seen sunlight for billions of years. Those permanently shadowed craters can drop to about −230 °C and trap water ice. That is why NASA\'s Artemis missions are aiming for the south pole.',
  },
  solar: {
    title: 'Solar Power', icon: '☀️',
    text: 'Solar power: P = irradiance × area × efficiency. A 50 m² array with 25% efficient cells gives 1361 × 50 × 0.25 ≈ 17 kW in full sunlight near the Moon. Mars is about 1.5 times farther from the Sun, and the inverse-square law means it gets only ~43% as much sunlight: about 7.4 kW from the same array. On Mars, dust settling on the panels slowly reduces output.',
  },
  battery: {
    title: 'Energy Storage', icon: '🔋',
    text: 'Energy (kWh) = power (kW) × time (h). A base that needs 10 kW through a 12-hour Martian night needs 120 kWh of stored energy. Batteries work well for one night, but the Moon\'s long dark periods are too long for batteries alone. That is why lunar bases plan nuclear or other steady power.',
  },
  reactor: {
    title: 'Nuclear Fission Power', icon: '⚛️',
    text: 'In fission, uranium-235 nuclei split and release heat, which is turned into electricity. NASA\'s Kilopower test (KRUSTY, 2018) proved a small reactor could give steady power day and night. Reactors are placed far from people or buried, because radiation from a source gets weaker with the square of the distance.',
  },
  oxygen: {
    title: 'Making Oxygen (ISRU)', icon: '🫁',
    text: 'Each astronaut needs about 0.84 kg of oxygen per day. On Mars, the MOXIE experiment on the Perseverance rover pulled oxygen out of CO₂ (2 CO₂ → 2 CO + O₂) and made 122 g in total between 2021 and 2023. On the Moon, oxygen can come from splitting water: 2 H₂O → 2 H₂ + O₂. 9 kg of water gives 8 kg of oxygen.',
  },
  ice: {
    title: 'Water Ice Mining', icon: '🧊',
    text: 'Water is the most useful resource in space: you can drink it, grow plants with it, split it into oxygen, and turn it into rocket fuel (H₂ + O₂). Orbiters have found ice under the surface in Mars\'s mid-latitudes and in the permanently shadowed craters at the Moon\'s poles. Heating icy soil turns the ice into vapour that can be collected.',
  },
  recycler: {
    title: 'Closing the Water Loop', icon: '♻️',
    text: 'In 2023 the International Space Station reached 98% water recovery: almost every drop of sweat, breath moisture and urine is cleaned and reused. On a long mission, recycling water is far cheaper than shipping it from Earth at thousands of dollars per kilogram.',
  },
  greenhouse: {
    title: 'Space Farming', icon: '🌱',
    text: 'Photosynthesis: 6 CO₂ + 6 H₂O + light → C₆H₁₂O₆ + 6 O₂. Plants make food and oxygen while removing the carbon dioxide astronauts breathe out. Space farms use pink-purple LEDs because plants mostly absorb red and blue light. Lettuce, radishes and peppers have already been grown on the ISS.',
  },
  shield: {
    title: 'Radiation Shielding', icon: '🧱',
    text: 'Earth\'s magnetic field and thick air protect us from cosmic rays and solar particles. The Moon has neither, and Mars has only thin air. A few metres of regolith (local soil) piled over or around a habitat absorbs much of that radiation. It also stops micrometeoroids, which hit the airless Moon at around 20 km/s.',
  },
  fabricator: {
    title: 'Building With Local Soil', icon: '🏭',
    text: 'Launching 1 kg to the Moon or Mars costs a huge amount. ISRU (In-Situ Resource Utilization) means "living off the land". Regolith can be sintered (heated until the grains fuse) or 3D-printed into bricks, landing pads and walls. NASA and ESA have printed test structures from simulated regolith.',
  },
  lab: {
    title: 'Why We Do Science', icon: '🔬',
    text: 'Rocks are time capsules. Apollo samples support the idea that the Moon formed from debris after a giant impact on the young Earth. On Mars, scientists search old lake beds such as Jezero Crater for signs that microbes once lived there. Perseverance is collecting samples so they can be studied on Earth.',
  },
  comms: {
    title: 'Talking to Earth', icon: '📡',
    text: 'Radio travels at the speed of light, about 300,000 km/s. That is fast enough to reach the Moon in about 1.3 seconds, but a message to Mars takes 3 to 22 minutes depending on where the planets are in their orbits. Mars crews must solve emergencies by themselves, with no quick help from Mission Control.',
  },
  radiation: {
    title: 'Space Radiation', icon: '☢️',
    text: 'Dose is measured in millisieverts (mSv). On Earth, people get about 3 mSv per year. On the surface of Mars it is about 0.7 mSv per day, and on the Moon about 1.4 mSv per day. Solar particle events are bursts of protons accelerated by solar flares and by the shock waves in front of fast coronal mass ejections (CMEs). On the airless Moon a big one can add hundreds of mSv to an unprotected astronaut, so bases need a shielded "storm shelter". NASA limits astronauts to 250 mSv per solar storm and 600 mSv in a whole career. Mars\'s thin air stops most solar protons: in the biggest storm Curiosity has measured (May 2024) the surface dose was about 8 mGy, like 30 chest X-rays.',
  },
  duststorm: {
    title: 'Martian Dust Storms', icon: '🌪️',
    text: 'Mars dust storms can grow to cover the whole planet and last for months. In 2018 a global dust storm blocked so much sunlight that the solar-powered Opportunity rover\'s power fell from about 645 to 22 watt-hours a day (−97%), and it never woke up again. Dust devils sometimes blow panels clean. This "cleaning event" kept the Spirit and Opportunity rovers alive for years.',
  },
  dark: {
    title: 'Day and Night on the Moon', icon: '🌑',
    text: 'The Moon spins once relative to the Sun every 29.5 Earth days. At the equator that gives about 14.8 days of sunlight and then about 14.8 days of night at −173 °C. At the poles the Sun never rises high: it circles the horizon, less than about 1.5° up, once every 29.5 days. Hills and crater rims block it for part of that circle. The best spots on Shackleton\'s rim are sunlit 80–90% of the time, but even there darkness can last from about a day to about a week. In this game the Sun disappears behind a distant massif for 6 days, like a bad lunar day at a rim site. During darkness, Earthshine (sunlight reflected off Earth) faintly lights the ground.',
  },
  gravity: {
    title: 'Low Gravity', icon: '🦘',
    text: 'Weight = mass × gravity. A 100 kg astronaut in a suit weighs 981 N on Earth, 371 N on Mars and only 162 N on the Moon. Apollo astronauts found that hopping like a kangaroo was easier than walking! Over long stays, low gravity weakens bones and muscles, so crews must exercise every day.',
  },
  pressure: {
    title: 'Keeping the Air In', icon: '🎈',
    text: 'A habitat holds Earth-like air at about 101 kPa, while outside there is ~0.6 kPa on Mars and almost nothing on the Moon. Even a tiny hole leaks air quickly. In 2018 the ISS crew found a 2 mm hole in a docked Soyuz spacecraft and sealed it with epoxy and gauze. Leaks are found by listening, watching pressure gauges and using ultrasonic detectors.',
  },
  maintenance: {
    title: 'Wear and Maintenance', icon: '🛠️',
    text: 'Dust, temperature swings from day to night, radiation and constant use slowly wear out fans, pumps, seals and electronics. On a long mission, spare parts and repair skills matter as much as the machines themselves. 3D printing spare parts from local materials (ISRU) could be key for future Moon and Mars bases.',
  },
  health: {
    title: 'Staying Healthy in Space', icon: '🩺',
    text: 'Crews must handle illness without a hospital nearby. Spacecraft carry medical kits and crews train in first aid. On the Moon, Earth\'s doctors are only 1.3 seconds away by radio. On Mars, a question and answer can take up to 44 minutes, so Mars crews need more medical independence.',
  },
  quake: {
    title: 'Quakes on Other Worlds', icon: '〰️',
    text: 'Seismometers left by the Apollo astronauts recorded moonquakes, some of them shallow quakes lasting over 10 minutes. NASA\'s InSight lander detected more than 1,300 marsquakes, including an estimated magnitude-5 quake on 4 May 2022, the biggest quake ever recorded on another planet. Bases must be built to survive the shaking.',
  },
};

export const scienceGoal = (g) => Math.round(150 * (g.days || 30) / 30);
export const OBJECTIVES = [
  { id: 'solar', title: 'More power', text: 'Build a second Solar Array', reward: 120, check: (g) => g.count('solar') >= 2 },
  { id: 'oxygen', title: 'Breathe easy', text: 'Build an Oxygen Generator', reward: 120, check: (g) => g.count('oxygen') >= 1 },
  { id: 'ice', title: 'Find water', text: 'Build an Ice Miner on a blue ice tile', reward: 120, check: (g) => g.count('ice') >= 1 },
  { id: 'recycler', title: 'Close the loop', text: 'Build a Water Recycler', reward: 100, check: (g) => g.count('recycler') >= 1 },
  { id: 'greenhouse', title: 'Feed the crew', text: 'Build a second Greenhouse', reward: 120, check: (g) => g.count('greenhouse') >= 2 },
  {
    id: 'night', title: 'Survive the dark',
    text: (p) => p.id === 'mars' ? 'Build a Battery Bank for the nights' : 'Build a Fission Reactor before Day 13',
    reward: 150, check: (g) => g.planet.id === 'mars' ? g.count('battery') >= 1 : g.count('reactor') >= 1,
  },
  { id: 'shield', title: 'Storm shelter', text: 'Place 2 Regolith Shields touching the habitat', reward: 100, check: (g) => g.habitatShields() >= 2 },
  { id: 'lab', title: 'Do science', text: 'Build a Science Lab', reward: 100, check: (g) => g.count('lab') >= 1 },
  { id: 'comms', title: 'Phone home', text: 'Build a Comms Dish', reward: 80, check: (g) => g.count('comms') >= 1 },
  { id: 'science', title: 'Discoverer', text: (p, g) => `Collect ${scienceGoal(g)} science points`, reward: 0, check: (g) => g.res.science >= scienceGoal(g) },
  // extra goals for longer missions
  { id: 'reserve', minDays: 60, title: 'Power reserve', text: 'Reach 290 kWh of storage (2 Battery Banks)', reward: 150, check: (g) => g.stats.cap >= 290 },
  { id: 'farm', minDays: 60, title: 'Farmer', text: 'Run 3 Greenhouses', reward: 150, check: (g) => g.count('greenhouse') >= 3 },
  { id: 'maint', minDays: 60, title: 'Maintenance crew', text: 'Repair 5 buildings', reward: 120, check: (g) => g.repairs >= 5 },
  { id: 'fortress', minDays: 90, title: 'Fortress', text: 'Build 6 Regolith Shields', reward: 120, check: (g) => g.count('shield') >= 6 },
];

export const CREW = [
  { name: 'Cmdr. Asha Rao', role: 'Commander', perk: 'Keeps crew calm: +25% health recovery', color: '#ff9f43' },
  { name: 'Eng. Mateo Silva', role: 'Engineer', perk: 'Repairs cost 40% less', color: '#54a0ff' },
  { name: 'Dr. Mei Chen', role: 'Botanist', perk: 'Greenhouses grow 25% more', color: '#1dd1a1' },
  { name: 'Dr. Kofi Mensah', role: 'Geologist', perk: 'Ice Miners dig 25% more', color: '#c56cf0' },
];

// Quiz bank. a = index of correct option.
export const QUIZ = {
  mars: [
    { q: 'How strong is gravity on Mars compared with Earth?', o: ['About 16%', 'About 38%', 'About 62%', 'About 90%'], a: 1, e: 'Mars gravity is 3.71 m/s², about 38% of Earth\'s 9.81 m/s². A 40 kg student would feel like they weighed about 15 kg.' },
    { q: 'What gas makes up most of the Martian atmosphere?', o: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Helium'], a: 2, e: 'About 95% is CO₂. MOXIE on the Perseverance rover proved we can pull oxygen out of it.' },
    { q: 'Why do solar panels give less power on Mars than near the Moon?', o: ['Mars is farther from the Sun, so sunlight is weaker', 'Mars spins backwards', 'Red light cannot make electricity', 'Mars has no daytime'], a: 0, e: 'Inverse-square law: Mars is about 1.5× farther from the Sun than Earth, so it gets 1/1.5² ≈ 43% of the sunlight.' },
    { q: 'How long does a radio message take to travel from Earth to Mars?', o: ['Instantly', 'About 1 second', '3 to 22 minutes', 'About 3 days'], a: 2, e: 'Light-speed signals take 3–22 minutes each way, depending on where the planets are. Mars crews must handle emergencies on their own.' },
    { q: 'What colour is the sky near the Sun at sunset on Mars?', o: ['Red', 'Blue', 'Green', 'Pure black'], a: 1, e: 'Fine Martian dust scatters blue light forward, so Martian sunsets look blue. The daytime sky is butterscotch.' },
    { q: 'How did "dust devils" help NASA\'s Spirit and Opportunity rovers?', o: ['They blew dust off the solar panels', 'They charged the batteries with static', 'They carried the rovers to new places', 'They brought rain'], a: 0, e: 'These "cleaning events" restored solar power and helped the rovers last years beyond their 90-sol plan.' },
    { q: 'Why can\'t liquid water stay on the Martian surface for long?', o: ['Mars is too hot', 'The air pressure is so low that it boils or freezes quickly', 'Mars has no gravity', 'Martian soil is magnetic'], a: 1, e: 'With less than 1% of Earth\'s air pressure, water boils at very low temperatures and freezes in the cold. Mars\'s water is mostly ice.' },
    { q: 'What are the names of Mars\'s two moons?', o: ['Io and Europa', 'Phobos and Deimos', 'Titan and Rhea', 'Luna and Selene'], a: 1, e: 'Phobos ("fear") and Deimos ("dread") are small, potato-shaped moons. Phobos orbits Mars three times a day.' },
    { q: 'How often do Earth and Mars line up for a fuel-efficient launch window?', o: ['Every month', 'About every 26 months', 'Every 10 years', 'Only once a century'], a: 1, e: 'Launch windows to Mars open about every 26 months, so real Mars cargo cannot arrive every few weeks the way it does in this game.' },
    { q: 'What is Olympus Mons?', o: ['A Martian moon', 'The tallest volcano in the solar system', 'A dust storm', 'A NASA rover'], a: 1, e: 'Olympus Mons on Mars rises about 22 km, roughly 2.5 times the height of Mount Everest.' },
    { q: 'What did NASA\'s Ingenuity helicopter achieve in 2021?', o: ['First landing on Phobos', 'First powered, controlled flight on another planet', 'First Mars sample returned to Earth', 'First human on Mars'], a: 1, e: 'Ingenuity flew in Mars\'s very thin air by spinning its rotors at about 2,400 rpm. It made 72 flights.' },
    { q: 'How long can a global Martian dust storm last?', o: ['A few minutes', 'One hour', 'Weeks to months', 'Exactly one sol'], a: 2, e: 'Global dust storms can wrap the whole planet for weeks to months, which is why long Mars missions need power that does not depend on sunlight.' },
    { q: 'Why must Mars astronauts wear pressure suits outside?', o: ['The air is too hot', 'The air pressure is so low that body fluids would boil', 'Mars has too much oxygen', 'The gravity is too strong'], a: 1, e: 'Mars\'s air pressure (~0.6 kPa) is far below the Armstrong limit (~6.3 kPa), where water boils at body temperature.' },
    { q: 'Why does the base have to save energy before a long dust storm?', o: ['Dust blocks sunlight from the solar arrays', 'Dust makes batteries explode', 'Dust stops the radio', 'Dust freezes the oxygen'], a: 0, e: 'Thick dust can block most of the sunlight, so solar arrays produce only a fraction of their normal power.' },
  ],
  moon: [
    { q: 'How strong is gravity on the Moon compared with Earth?', o: ['About 1/6', 'About 1/2', 'About 1/3', 'The same'], a: 0, e: 'At 1.62 m/s², the Moon\'s gravity is about 16.5% of Earth\'s. That\'s why Apollo astronauts bounced around!' },
    { q: 'Where is water ice most likely found on the Moon?', o: ['On top of mountains', 'In permanently shadowed craters near the poles', 'In the dark "seas" (maria)', 'Floating in lunar lakes'], a: 1, e: 'Crater floors near the poles never see sunlight and stay around −230 °C, cold enough to trap ice for billions of years.' },
    { q: 'How long does a radio signal take to travel from Earth to the Moon?', o: ['About 1.3 seconds', 'About 1 minute', 'About 20 minutes', 'About 1 day'], a: 0, e: 'The Moon is 384,400 km away. At 300,000 km/s, light takes about 1.3 seconds.' },
    { q: 'Why is there no wind or weather on the Moon?', o: ['It is too cold', 'It has almost no atmosphere', 'It is too small to spin', 'Its weather is all underground'], a: 1, e: 'The Moon has only a very thin "exosphere". With no air there is no wind or rain, and no sound either!' },
    { q: 'Why does NASA plan to use fission reactors on the Moon?', o: ['To heat the oceans', 'Long dark periods with no sunlight', 'Solar panels don\'t work in a vacuum', 'To make the Moon brighter'], a: 1, e: 'Lunar nights can last up to 14 Earth days, which is too long for batteries alone. A reactor gives steady power day and night.' },
    { q: 'Why is lunar dust (regolith) so dangerous?', o: ['It is radioactive gold', 'Its grains are sharp and jagged because nothing wears them smooth', 'It is always wet', 'It is magnetic and explodes'], a: 1, e: 'With no wind or water to wear it down, lunar dust stays sharp like broken glass. It scratched Apollo spacesuits and clogged seals.' },
    { q: 'What faintly lights the Moon\'s surface during the lunar night?', o: ['Starlight from Mars', 'Earthshine — sunlight reflected off Earth', 'Glowing lunar rocks', 'Nothing at all'], a: 1, e: 'Earth reflects sunlight onto the Moon. From the Moon, a "full Earth" looks much bigger and brighter than a full Moon does from Earth.' },
    { q: 'How do astronauts make oxygen from lunar ice?', o: ['Melting it releases oxygen gas', 'Electrolysis splits water into hydrogen and oxygen', 'Freezing it further', 'Mixing it with regolith'], a: 1, e: '2 H₂O → 2 H₂ + O₂ using electricity. The hydrogen can be kept for rocket fuel.' },
    { q: 'Who were the first people to walk on the Moon?', o: ['Yuri Gagarin and Valentina Tereshkova', 'Neil Armstrong and Buzz Aldrin', 'John Glenn and Sally Ride', 'Michael Collins and Alan Shepard'], a: 1, e: 'Apollo 11 landed on 20 July 1969. Michael Collins stayed in orbit while Armstrong and Aldrin walked on the surface.' },
    { q: 'What is the name of NASA\'s program to return humans to the Moon?', o: ['Gemini', 'Artemis', 'Voyager', 'Mercury'], a: 1, e: 'Artemis is named after Apollo\'s twin sister in Greek mythology. It aims to land astronauts near the lunar south pole.' },
    { q: 'Why can astronaut footprints on the Moon last for millions of years?', o: ['The soil is glue', 'There is no wind or rain to erase them', 'The Moon is frozen', 'They were painted'], a: 1, e: 'Without an atmosphere there is no weather. Only very slow micrometeoroid "gardening" slowly erases them.' },
    { q: 'What are the large dark areas on the Moon called?', o: ['Maria (ancient lava plains)', 'Oceans of water', 'Shadows of Earth', 'Forests'], a: 0, e: '"Maria" is Latin for seas. Early astronomers thought they were water, but they are ancient lava flows.' },
    { q: 'How did the Moon most likely form?', o: ['It was captured passing by', 'From debris after a Mars-sized object hit the young Earth', 'It split from the Sun', 'It grew from comets'], a: 1, e: 'The giant-impact hypothesis is supported by Apollo rock samples, which are very similar in chemistry to Earth\'s mantle.' },
    { q: 'Why do we always see the same side of the Moon?', o: ['The Moon does not spin', 'It spins exactly once per orbit (tidal locking)', 'The far side is invisible', 'Earth blocks it'], a: 1, e: 'Tidal locking makes the Moon\'s spin match its 27.3-day orbit, so one face always points towards Earth.' },
  ],
  general: [
    { q: 'About how much oxygen does one astronaut breathe in a day?', o: ['0.08 kg', '0.84 kg', '8.4 kg', '84 kg'], a: 1, e: 'About 0.84 kg per person per day. A crew of 4 needs about 100 kg of O₂ for a month.' },
    { q: 'What does ISRU stand for?', o: ['International Space Rocket Union', 'In-Situ Resource Utilization', 'Integrated Solar Radiation Unit', 'Ice Storage & Recycling Unit'], a: 1, e: '"In-Situ" means "in place". ISRU means using local resources such as ice, soil and air instead of shipping everything from Earth.' },
    { q: 'Why pile regolith around a space habitat?', o: ['To keep out aliens', 'To block radiation and micrometeoroids', 'To make it look natural', 'To grow plants on it'], a: 1, e: 'A few metres of soil absorbs much of the cosmic radiation and stops tiny high-speed meteoroids.' },
    { q: 'In photosynthesis, plants take in CO₂ and release…', o: ['Nitrogen', 'Oxygen', 'Hydrogen', 'Methane'], a: 1, e: '6 CO₂ + 6 H₂O + light → glucose + 6 O₂. Greenhouses help clean a base\'s air.' },
    { q: 'A base uses 10 kW for a 12-hour night. How much energy must the batteries store?', o: ['1.2 kWh', '22 kWh', '120 kWh', '1,200 kWh'], a: 2, e: 'Energy = Power × Time = 10 kW × 12 h = 120 kWh.' },
    { q: 'Which unit measures the radiation dose a person receives?', o: ['Decibel (dB)', 'Millisievert (mSv)', 'Kelvin (K)', 'Newton (N)'], a: 1, e: 'People on Earth get about 3 mSv per year. On Mars an astronaut gets about that much in under 5 days.' },
    { q: 'About how much water does the ISS recycle?', o: ['25%', '50%', '75%', '98%'], a: 3, e: 'In 2023 the ISS life-support system reached 98% water recovery. Yesterday\'s coffee becomes tomorrow\'s coffee!' },
    { q: 'What does a solar panel turn sunlight into?', o: ['Heat only', 'Electricity', 'Oxygen', 'Water'], a: 1, e: 'Solar cells use the photovoltaic effect: light knocks electrons loose in silicon and creates an electric current.' },
    { q: 'Which gas do astronauts breathe out that must be removed from the cabin air?', o: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Helium'], a: 2, e: 'Too much CO₂ causes headaches and worse. Life-support systems scrub it out, and plants can use it too.' },
    { q: 'What happens to astronauts\' bones in low gravity without exercise?', o: ['They get stronger', 'They lose density', 'Nothing at all', 'They grow longer forever'], a: 1, e: 'Without exercise, astronauts can lose about 1% of bone mass per month, so they exercise about 2 hours a day on the ISS.' },
    { q: 'Hydrogen and oxygen made from ice can be used as…', o: ['Rocket fuel', 'Building bricks', 'Solar panels', 'Radiation'], a: 0, e: 'Liquid hydrogen and liquid oxygen are a powerful rocket propellant, which is why ice could turn the Moon into a fuel station.' },
    { q: 'Why must a long-stay base repair its equipment regularly?', o: ['Machines wear out and break over time', 'Repairs make it look nicer', 'Robots get bored', 'It is required by law'], a: 0, e: 'Pumps, seals and fans wear out. ISS crews spend a big share of their working time on maintenance.' },
    { q: 'Which unit measures electrical power?', o: ['Kilogram', 'Kilowatt', 'Kilometre', 'Kelvin'], a: 1, e: 'Power is measured in watts (W). 1 kW = 1,000 W. Energy is power × time, measured in kilowatt-hours (kWh).' },
  ],
};

// ===== Engineering trade-offs (shown in build hint, info panel and Mission Handbook) =====
export const TRADEOFFS = {
  solar: 'Cheap and simple, but only works when the Sun is up. Mars arrays give less than half the Moon\'s power and get dusty. You need batteries or a reactor for darkness.',
  battery: 'Stores daytime energy for the night (energy = power × time). Great for one Martian night, but far too heavy and expensive for a 6-day lunar dark spell.',
  reactor: 'Steady 10 kW whatever the weather or light. Costs 5× a solar array and must be kept 4+ tiles from people (radiation falls off with distance squared).',
  oxygen: 'Makes the oxygen everyone needs, but uses 2 kW. On the Moon it also uses 4.5 L of water per day, so it competes with drinking water and farming.',
  ice: 'The only big source of new water, but it needs a scarce ice tile and 1.5 kW. One miner fills the gap that recycling cannot close.',
  recycler: 'Cuts the crew\'s water loss by 90% for just 1 kW. Usually cheaper than mining more ice, but it only recycles water you already have.',
  greenhouse: 'Grows food and a little oxygen, but uses 2.5 kW and 2 L of water per day. Shipping all food from Earth would cost far more than growing it here.',
  shield: 'Cheap (40 kg) and needs no power, but every shield uses a building tile. Two shields touching the habitat cut solar-storm doses by about 90%, which matters most on the airless Moon.',
  fabricator: 'Costs 180 kg and 3 kW, then makes 50 kg of materials a day. It pays for itself in about 4 days: an investment, as long as you can spare the power.',
  lab: 'Earns science, the reason for the mission, but uses 1.5 kW and makes nothing the crew needs to survive. Switch it off in a power crisis.',
  comms: 'Brings cargo every 6 days on the Moon, or every 15 sols on Mars (from an imagined orbital depot: real Earth–Mars launch windows open only every ~26 months). Helpful, but a colony that depends on resupply is not self-sufficient.',
};

// ===== Real science vs game simplifications (Mission Handbook) =====
// kind: 'real' = real-world measured/physical value used directly; 'game' = simplified or scaled for gameplay
export const SCIENCE_TABLE = [
  ['Time', '1 sol = 24 h 39 min; 1 lunar day = 29.5 Earth days', '1 game day = 24 real seconds at 1×: a 90-day mission takes 36 min at 1×, 9 min at 4× or 4.5 min at 8×', 'game'],
  ['Gravity', 'Mars 3.71 m/s², Moon 1.62 m/s²', 'Used directly for astronaut hop height and speed', 'real'],
  ['Sunlight', 'Mars ≈ 590 W/m², Moon ≈ 1361 W/m²', 'Used directly: P = sunlight × 50 m² × 25% → 7.4 kW / 17 kW', 'real'],
  ['Mars day/night', 'Sun rises and sets every sol', 'Same, with a smooth day curve', 'real'],
  ['Moon polar light', 'Sun circles the horizon (≤ ~1.5° high) once per 29.5 days; rim sites lit 80–90%, darkness up to ~1 week', 'Sun hides behind a massif for 6 days every 29.5 days (Days 13–19, 43–49, 72–78). Lighting angle exaggerated so the base is visible', 'game'],
  ['Temperature', 'Mars mid-latitude summer ≈ −30 °C / −80 °C; Moon pole ≈ −40 °C sunlit, much colder in darkness', 'Shown in the HUD for information only. The sim models heating as part of the habitat\'s 2 kW load', 'game'],
  ['Oxygen need', '≈ 0.84 kg per person per day (NASA)', 'Used directly', 'real'],
  ['Water need', '≈ 2.5–3.5 L drinking + food prep per person per day (more with washing)', '3.5 L per person per day; recycler recovers 90% (ISS reached 98%)', 'game'],
  ['Food', '≈ 1.8 kg per person per day including packaging', '1.2 kg per person per day', 'game'],
  ['Oxygen generator', 'MOXIE made 6–12 g/hour; 122 g in total', 'A scaled-up future plant: 4 kg/day for 2 kW', 'game'],
  ['Electrolysis', '9 kg of water → 8 kg O₂ + 1 kg H₂', '4.5 L water → 4 kg O₂ on the Moon', 'real'],
  ['Fission reactor', 'Kilopower/KRUSTY (2018 test): designs of 1–10 kW. In 2025 NASA set a goal of a reactor of at least 100 kW on the Moon by about 2030', '10 kW, must sit 4+ tiles from the habitat', 'game'],
  ['Surface radiation', 'Mars ≈ 0.67 mSv/day (Curiosity), Moon ≈ 1.37 mSv/day (Chang\'e 4)', 'Used directly (reduced inside the habitat)', 'real'],
  ['Solar particle event', 'Moon: a large event can give an unprotected astronaut hundreds of mSv. Mars: the air stops most protons; NASA estimates ~20–100 mSv on the surface for the biggest storms of the space age, and Curiosity measured ~8 mGy in May 2024', 'Unshielded: 55–80 mSv (Mars) / 350–455 mSv (Moon), ×0.8–1.25 by real storm strength. Habitat walls ×0.7, 1 shield ×0.5, 2 shields ×0.1', 'game'],
  ['Career dose limit', 'NASA career limit: 600 mSv (NASA-STD-3001)', 'Crew member is evacuated at 600 mSv', 'real'],
  ['Dose limit per solar storm', 'NASA short-term limit: 250 mSv per solar particle event. Radiation sickness needs about 700 mSv or more in a short time (mild symptoms from ~300)', 'Storm doses above 250 mSv cost crew health; lower doses only add to the career dose', 'real'],
  ['Survival without supplies', 'Without air: minutes (cabin air lasts a day or two); without water: about 3 days; without food: several weeks', 'Crew health falls to zero in ~1 day without oxygen, ~4 days without water and ~2.5 weeks without food', 'game'],
  ['Radio delay', 'Mars 3–22 minutes, Moon ≈ 1.3 s', 'Information only', 'real'],
  ['Event frequency', 'Dust storms, quakes, impacts and big solar particle events happen on months-to-years timescales', 'Compressed so every mission has challenges (a solar storm every 2–3 weeks); they get more frequent and stronger at higher threat levels', 'game'],
  ['Threat levels', 'Real risks grow as equipment ages and missions get longer', 'Level I (Days 1–19), II (20–44), III (45–69), IV (70–90): more wear, stronger storms and more emergencies', 'game'],
  ['Equipment wear', 'Dust, temperature cycling and use wear out machines; ISS crews do a lot of maintenance', 'Every building loses 0.3% condition per day × threat level (×1 to ×3); repair with materials', 'game'],
  ['Mars cargo', 'Earth–Mars launch windows open only every ~26 months', 'Imagined supply depot in Mars orbit: a lander every 15 sols (Moon: every 6 days)', 'game'],
  ['Global dust storms', 'Can cover all of Mars for weeks to months. The 2018 storm (opacity τ ≈ 10.8) cut Opportunity\'s solar power by ~97% and ended its mission', 'On 60- and 90-day missions, one ~8-sol global storm in the second half that blocks up to ~74% of sunlight: milder than the worst real storms', 'game'],
  ['Resources & costs', 'Real missions are measured in tonnes and billions of dollars', '"kg of materials", kW and science points are simplified game units', 'game'],
  ['Emergency choices', 'Real crews weigh repair time, spare parts, power and crew safety', 'Each choice has fixed costs and effects; harder threat levels raise costs and severity, and points ×1 to ×1.75', 'game'],
  ['Oxygen candles', 'The ISS carries solid-fuel oxygen generators (lithium perchlorate "candles"; one gives about a day of oxygen for one person) as a backup', '+10 kg O₂ (about a dozen candles) for 25 kg materials', 'game'],
  ['Dust shields', 'NASA\'s Electrodynamic Dust Shield lifted dust off surfaces on the Moon (Blue Ghost, 2025)', 'Cleans lunar panels to 92% for 40 kg + 30 kWh', 'real'],
  ['Storage', 'Every tank and pantry has a size; bigger tanks mean more mass to launch', 'Tanks hold 150 kg O₂ (≈45 days for 4 crew), 600 L water and 300 kg food; the yard holds 2,500 kg materials. Extra is wasted', 'game'],
];
