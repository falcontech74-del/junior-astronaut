// Phase 6 polish: settings, launch curtain, first-time tutorial, hackathon demo mode, verified credits.
import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { Sound, Modals, Toasts } from './bus.js';
import { Settings, Music, lowEnd } from './settings.js';

const useSettings = () => useSyncExternalStore(Settings.subscribe, Settings.getVersion);

// ---------------- Settings ----------------
export const openSettings = (extra) => Modals.open({ icon: '⚙️', title: 'Settings', custom: 'settings', extra, buttons: [{ label: 'Done', primary: true }] });
export function SettingsBody({ extra }) {
  useSettings();
  const row = (label, sub, ctl) => <div className="set-row"><div><b>{label}</b>{sub && <small>{sub}</small>}</div>{ctl}</div>;
  const toggle = (key, id) => <button id={id} role="switch" aria-checked={!!Settings[key]} className={`sw ${Settings[key] ? 'on' : ''}`} onClick={() => { Sound.init(); Settings.set({ [key]: !Settings[key] }); Music.unlock(); Sound.click(); }}><i /></button>;
  return (
    <div className="m-body settings">
      {row('🔊 Sound effects', 'Clicks, alerts and success chimes', toggle('sfx', 'set-sfx'))}
      {row('🎵 Background music', 'Calm ambient music, made live in your browser', toggle('music', 'set-music'))}
      {row('Music volume', null, <input id="set-vol" type="range" min="0" max="1" step="0.05" value={Settings.musicVol} onChange={(e) => Settings.set({ musicVol: +e.target.value })} />)}
      {row('🖥️ Graphics quality', `Auto picks ${lowEnd() ? 'Low' : 'High'} on this device. Low = faster on phones and older laptops. Applies to the next mission.`,
        <div className="seg" id="set-quality">{['auto', 'high', 'low'].map((q) => <button key={q} data-q={q} className={Settings.quality === q ? 'on' : ''} onClick={() => { Sound.click(); Settings.set({ quality: q }); }}>{q[0].toUpperCase() + q.slice(1)}</button>)}</div>)}
      {row('🎓 Tutorial', Settings.tutorialDone ? 'Completed. You can replay it on your next mission.' : 'Will start on your next mission.',
        <button className="btn sm" id="set-tutorial" onClick={() => { Sound.click(); Settings.set({ tutorialDone: false }); if (extra && extra.replay) { Modals.close(); extra.replay(); } }}>{extra && extra.replay ? 'Replay now' : 'Replay'}</button>)}
    </div>
  );
}

// ---------------- launch curtain (shown while the 3D scene is built) ----------------
export function LaunchCurtain({ planet, ready }) {
  const [gone, setGone] = useState(false);
  const [stage, setStage] = useState(0);
  const t0 = useRef(performance.now());
  useEffect(() => { const id = setInterval(() => setStage((s) => Math.min(3, s + 1)), 450); return () => clearInterval(id); }, []);
  useEffect(() => {
    if (!ready) return;
    const wait = Math.max(0, 1100 - (performance.now() - t0.current));
    const id = setTimeout(() => setGone(true), wait);
    return () => clearTimeout(id);
  }, [ready]);
  const STAGES = ['Calculating descent trajectory', planet.id === 'mars' ? 'Shaping the plains of ' + planet.site : 'Mapping the ' + planet.site, 'Switching on life support', 'Waking up the crew'];
  return (
    <div id="curtain" className={`${gone ? 'gone' : ''} ${planet.id}`} aria-hidden={gone}>
      <div className={`globe ${planet.id}`} />
      <h2>{planet.id === 'mars' ? 'Landing on Mars' : 'Landing on the Moon'}</h2>
      <p>{STAGES[stage]}…</p>
      <div className="cur-bar"><i style={{ width: `${ready ? 100 : 25 + stage * 20}%` }} /></div>
    </div>
  );
}

// ---------------- first-time tutorial (coach marks; the game stays playable) ----------------
const touch = () => window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
export const TUTORIAL = [
  { id: 'welcome', title: 'Welcome, Commander! 👩‍🚀', text: 'This one-minute tour shows how to keep your crew alive. The clock is paused while we look around.' },
  { id: 'gauges', title: 'Life-support gauges', target: '#resources', text: 'Oxygen, water, food, power and crew health. The small number shows the change per day. Tap a gauge any time to see the real science behind it.' },
  { id: 'camera', title: 'Look around', text: () => (touch() ? 'Drag with one finger to rotate, pinch to zoom, and drag with two fingers to pan.' : 'Drag to rotate, scroll to zoom, and right-drag to pan the camera.') },
  { id: 'pick', title: 'Build an Oxygen Generator', target: '.bcard[data-type="oxygen"]', text: 'Your crew needs 3.4 kg of oxygen every day. Tap the Oxygen Generator card in the build bar.', done: (e) => e.ui.buildType === 'oxygen' || has(e, 'oxygen') },
  { id: 'place', title: 'Place it', pos: 'top', text: () => (touch() ? 'Tap a free tile near the habitat to preview it (green = OK), then tap ✓ Build. Building uses 🧱 materials.' : 'Click a free tile near the habitat (green = OK). Building uses 🧱 materials.'), done: (e) => has(e, 'oxygen') },
  { id: 'time', title: 'Start the clock', target: '#speed', text: 'Press ▶ to run time, or ⏩ to go faster. New buildings take a few hours of game time to finish.', done: (e) => e.speed > 0 },
  { id: 'goals', title: 'Mission goals', target: '#objectives', text: 'Goals guide you and pay bonus materials. The ⭐ card in the build bar is always a good next step.' },
  { id: 'emerg', title: 'Emergencies & real NASA data', text: 'Dust storms, failures and solar storms will interrupt you. Each choice has costs, and a debrief explains the engineering. Radiation alerts are based on real NASA space-weather records.' },
  { id: 'ready', title: 'You are ready!', text: 'Keep oxygen, water and food above zero until the last day. Replay this tour from ⚙️ Settings.' },
];
const has = (e, t) => [...e.buildings.values()].some((b) => b.type === t);

export function Tutorial({ engine, onDone }) {
  const [k, setK] = useState(0);
  const [rect, setRect] = useState(null);
  const step = TUTORIAL[k];
  useEffect(() => { engine.setSpeed(0); engine.tutorial = true; return () => { engine.tutorial = false; }; }, [engine]);
  useEffect(() => {
    const id = setInterval(() => {
      const el = step.target && document.querySelector(step.target);
      const r = el && el.getBoundingClientRect();
      setRect(r && r.width ? { x: r.left, y: r.top, w: r.width, h: r.height } : null);
      // advance only from the step this timer belongs to (a slow device may tick again before React re-renders)
      if (step.done && step.done(engine)) { setK((v) => { if (v !== k) return v; Sound.good(); return v + 1; }); }
      if (k < 5 && engine.speed > 0 && step.id !== 'time') engine.setSpeed(0); // keep paused until the clock step
    }, 250);
    return () => clearInterval(id);
  }, [k, step, engine]);
  useEffect(() => { if (k >= TUTORIAL.length) finish(); });
  const finish = () => { Settings.set({ tutorialDone: true }); onDone(); };
  if (k >= TUTORIAL.length) return null;
  const H = window.innerHeight, W = window.innerWidth;
  const below = rect && rect.y + rect.h / 2 < H / 2;
  // 'top' steps need the map free (placing a building): the card sits over the top bar instead
  const cardStyle = step.pos === 'top' ? { top: 8 }
    : rect ? (below ? { top: Math.min(H - 220, rect.y + rect.h + 14) } : { bottom: Math.min(H - 220, H - rect.y + 14) }) : { top: '38%' };
  const text = typeof step.text === 'function' ? step.text() : step.text;
  return (
    <div id="tutorial" data-step={step.id}>
      {rect && <div className="tut-ring" style={{ left: rect.x - 6, top: rect.y - 6, width: rect.w + 12, height: rect.h + 12 }} />}
      <div className="tut-card" style={{ ...cardStyle, left: Math.max(8, (W - Math.min(380, W - 16)) / 2), width: Math.min(380, W - 16) }}>
        <div className="tut-top"><span className="tut-n">Tutorial {k + 1}/{TUTORIAL.length}</span><button className="tut-skip" onClick={() => { Sound.click(); finish(); }}>Skip tour ✕</button></div>
        <b>{step.title}</b>
        <p>{text}</p>
        {step.done && <p className="tut-do">👉 Do it now: the tour continues by itself.</p>}
        <div className="tut-btns">
          {k > 0 && <button className="btn sm" onClick={() => { Sound.click(); setK(k - 1); }}>◂ Back</button>}
          <button className="btn sm primary" id="tut-next" onClick={() => { Sound.click(); setK(k + 1); }}>{k === TUTORIAL.length - 1 ? 'Start playing ▸' : step.done ? 'Skip step ▸' : 'Next ▸'}</button>
        </div>
      </div>
    </div>
  );
}

// ---------------- hackathon demo mode ----------------
// Builds a working base instantly, then lets the presenter trigger each showcase moment in order.
export function setupDemo(engine) {
  const e = engine;
  e.res.mat = 5000;
  const plan = [['solar', 4, 4], ['solar', 3, 4], ['solar', 4, 3], ['battery', 3, 3], ['battery', 2, 4], ['oxygen', 9, 4], ['oxygen', 9, 3], ['ice', ...(e.iceTiles[0] || [11, 11])], ['ice', ...(e.iceTiles[1] || [11, 12])], ['recycler', 8, 9],
    ['greenhouse', 4, 8], ['greenhouse', 3, 8], ['shield', 5, 6], ['shield', 5, 7], ['fabricator', 9, 6], ['lab', 9, 9], ['comms', 8, 4], ['reactor', ...(e.planet.id === 'mars' ? [11, 5] : [2, 9])]];
  for (const [t, i, j] of plan) {
    let spot = e.canPlace(t, i, j).ok ? [i, j] : null;
    for (let r = 1; !spot && r < 6; r++) for (let a = -r; a <= r && !spot; a++) for (let b = -r; b <= r && !spot; b++) if (e.canPlace(t, i + a, j + b).ok) spot = [i + a, j + b];
    if (!spot) continue;
    e.ui.buildType = t; e.place(...spot); e.ui.buildType = null;
  }
  e.buildings.forEach((b) => { if (!b.built) e.completeBuilding(b); });
  Object.assign(e.res, { mat: 900, o2: 120, water: 450, food: 220 });
  e.res.battery = e.stats.cap || e.res.battery;
  e.events = e.events.filter((x) => !['em', 'duststorm', 'spe', 'spe_warn', 'quiz', 'failure', 'leak', 'contamination', 'illness', 'cropblight', 'meteor', 'quake'].includes(x.type));
  e.demo = true;
  e.bump();
}

export const DEMO_STEPS = [
  { id: 'tour', label: '🎥 Tour the base', say: 'A working colony: solar + reactor power, oxygen from ' + 'local resources, recycled water and greenhouses.' },
  { id: 'science', label: '🔬 Life-support science', say: 'Every gauge opens the real chemistry and physics, with live numbers from this base.' },
  { id: 'dust', label: '🌪️ Dust emergency', say: 'Emergencies give 2–3 engineering choices with real costs.' },
  { id: 'radiation', label: '☢️ Radiation alert (NASA data)', say: 'Radiation alerts are built from real NASA DONKI solar-storm records.' },
  { id: 'sources', label: '🛰️ NASA data & credits', say: 'Every NASA record links back to its official source.' },
  { id: 'moon', label: '🌙 Switch to the Moon', say: 'The Moon plays differently: no air, long dark spells behind the crater rim, stronger radiation.' },
  { id: 'report', label: '🏁 Jump to the final report', say: 'The mission report scores survival, crew health, resources, engineering and learning, and awards a rank.' },
];

export function DemoPanel({ engine, actions, startAt = 0 }) {
  const [open, setOpen] = useState(true);
  const [k, setK] = useState(startAt);
  const stepsRef = useRef(null);
  // keep the next step visible when the steps scroll sideways (phones)
  useEffect(() => {
    const box = stepsRef.current; const el = box && box.querySelector('.dp-step.next');
    if (box && el && box.scrollWidth > box.clientWidth) box.scrollLeft = Math.max(0, el.offsetLeft - box.offsetLeft - 8);
  }, [k, open]);
  const run = (i) => {
    const st = DEMO_STEPS[i]; if (!st) return;
    Sound.click(); setK(i + 1);
    Toasts.push(`🎬 <b>${st.label.replace(/^\S+\s/, '')}</b>: ${st.say}`, 'info', null, 6000);
    actions[st.id] && actions[st.id]();
  };
  return (
    <div id="demo-panel" className={open ? '' : 'min'}>
      <div className="dp-h" onClick={() => setOpen(!open)}><span className="dp-live">●</span> DEMO MODE <span className="chev">{open ? '▾' : '▸'}</span></div>
      {open && (
        <>
          <div className="dp-steps" ref={stepsRef}>{DEMO_STEPS.map((st, i) => <button key={st.id} data-demo={st.id} className={`dp-step ${i < k ? 'done' : ''} ${i === k ? 'next' : ''}`} onClick={() => run(i)}>{st.label}</button>)}</div>
          <button className="btn sm primary dp-next" id="demo-next" disabled={k >= DEMO_STEPS.length} onClick={() => run(k)}>{k >= DEMO_STEPS.length ? 'Demo complete ✓' : `Next: ${DEMO_STEPS[k].label} ▸`}</button>
        </>
      )}
    </div>
  );
}

// ---------------- verified sources & credits (checked 14 Nov 2026) ----------------
export const SCIENCE_SOURCES = [
  { what: 'Oxygen from Mars air (MOXIE, 122 g, 12 g/hour)', who: 'NASA', url: 'https://www.nasa.gov/missions/mars-2020-perseverance/perseverance-rover/nasas-oxygen-generating-experiment-moxie-completes-mars-mission/' },
  { what: '98% water recovery on the ISS', who: 'NASA', url: 'https://www.nasa.gov/missions/station/iss-research/nasa-achieves-water-recovery-milestone-on-international-space-station/' },
  { what: 'Kilopower / KRUSTY fission reactor test (2018)', who: 'NASA Technical Reports Server', url: 'https://ntrs.nasa.gov/citations/20180005435' },
  { what: 'Astronauts eating space-grown lettuce (Veggie)', who: 'NASA', url: 'https://www.nasa.gov/technology/tech-transfer-spinoffs/space-farming-yields-a-crop-of-benefits-for-earth/' },
  { what: 'Mars surface radiation, 0.67 mSv/day (Curiosity RAD)', who: 'Hassler et al., Science (2014)', url: 'https://doi.org/10.1126/science.1244797' },
  { what: 'Moon surface radiation, 1.37 mSv/day (Chang\'e 4)', who: 'Zhang et al., Science Advances (2020)', url: 'https://doi.org/10.1126/sciadv.aaz1334' },
];
// scientific validation references (Phase 8, checked 15 Nov 2026)
export const SCI_REFS = [
  { what: 'Astronaut radiation limits: 600 mSv career, 250 mSv per solar storm (NASA-STD-3001)', who: 'NASA', url: 'https://www.nasa.gov/wp-content/uploads/2023/03/radiation-protection-technical-brief-ochmo.pdf' },
  { what: 'Solar-storm doses on the Moon and Mars surfaces (Simonsen et al., 2025)', who: 'NASA Technical Reports Server', url: 'https://ntrs.nasa.gov/citations/20250006168' },
  { what: 'Biggest solar storm measured on Mars\'s surface: 8,100 micrograys (May 2024)', who: 'NASA', url: 'https://www.nasa.gov/solar-system/nasa-watches-mars-light-up-during-epic-solar-storm/' },
  { what: 'Mars\'s air cut a 2021 storm\'s dose 30× compared with orbit', who: 'ESA', url: 'https://www.esa.int/Science_Exploration/Human_and_Robotic_Exploration/Exploration/ExoMars/Giant_solar_eruption_felt_on_Earth_Moon_and_Mars' },
  { what: 'Radiation sickness thresholds (0.3–0.7 Gy and above)', who: 'CDC', url: 'https://www.cdc.gov/radiation-emergencies/hcp/clinical-guidance/ars.html' },
  { what: 'Oxygen candles: lithium perchlorate, one per crew member per day', who: 'NASA History', url: 'https://www.nasa.gov/history/25-years-ago-fire-aboard-space-station-mir/' },
  { what: 'Electrodynamic Dust Shield cleared lunar dust on Blue Ghost (2025)', who: 'NASA', url: 'https://www.nasa.gov/blogs/missions/2025/03/14/nasa-science-data-received-blue-ghost-captures-eclipse-from-moon/' },
  { what: 'Fission Surface Power: a lunar reactor of at least 100 kW', who: 'NASA', url: 'https://www.nasa.gov/general/nasa-seeks-industry-feedback-on-fission-surface-power/' },
  { what: 'Largest marsquake: estimated magnitude 5 (InSight, 2022)', who: 'NASA JPL', url: 'https://www.jpl.nasa.gov/news/nasas-insight-records-monster-quake-on-mars/' },
  { what: '2018 global dust storm, opacity τ ≈ 10.8 (Opportunity)', who: 'NASA JPL', url: 'https://www.jpl.nasa.gov/news/opportunity-hunkers-down-during-dust-storm/' },
];
export const SOFTWARE = [
  { what: 'React', url: 'https://react.dev/' },
  { what: 'three.js', url: 'https://threejs.org/' },
  { what: 'React Three Fiber', url: 'https://r3f.docs.pmnd.rs/' },
  { what: 'Drei helpers', url: 'https://github.com/pmndrs/drei' },
];
export function CreditsPanel() {
  const a = (u, t) => <a href={u} target="_blank" rel="noopener noreferrer">{t} ↗</a>;
  return (
    <div className="credits" id="credits">
      <div className="rp-h">📚 Science sources behind the game's REAL values</div>
      <ul className="src-links">{SCIENCE_SOURCES.map((s) => <li key={s.url}>{s.what}: {a(s.url, s.who)}</li>)}</ul>
      <div className="rp-h">🔬 Scientific references (radiation, life support, Mars &amp; Moon)</div>
      <ul className="src-links" id="sci-refs">{SCI_REFS.map((s) => <li key={s.url}>{s.what}: {a(s.url, s.who)}</li>)}</ul>
      <div className="rp-h">🛠️ Built with</div>
      <ul className="src-links">{SOFTWARE.map((s) => <li key={s.url}>{a(s.url, s.what)}</li>)}</ul>
      <div className="rp-h">🙏 Credits</div>
      <p className="small">Game design, code, 3D models and procedural music: the Junior Astronaut team, with AI-assisted development. Space-weather data: NASA Community Coordinated Modeling Center (CCMC), DONKI. All 3D models, textures and sounds are generated in code; no third-party art is used.</p>
      <p className="small muted">All links were checked on 14 Nov 2026 (science sources) and 15 Nov 2026 (scientific references). Junior Astronaut is an educational project and is not affiliated with or endorsed by NASA.</p>
    </div>
  );
}
