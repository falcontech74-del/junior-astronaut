// Interactive emergencies: each one has an immediate effect (onset), 2–3 choices with different
// costs and consequences, mission points, and an outcome check a few days later.
import { THREAT, threatLevel } from './data.js';
import { NasaData, STRENGTH } from './nasa/donki.js';

export const EMERGENCY_TYPES = ['dust', 'o2fail', 'waterleak', 'batfail', 'radiation'];
const SEV = [1, 1.2, 1.45, 1.7]; // severity by threat level

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const builtOf = (e, type) => [...e.buildings.values()].filter((b) => b.type === type && b.built);

// Build an emergency for the current planet and threat level. Returns null if it cannot happen
// (e.g. oxygen-generator failure with no oxygen generator).
export function buildEmergency(e, type, ev = {}) {
  const P = e.planet, mars = P.id === 'mars';
  const L = threatLevel(e.t), sev = SEV[L], mult = 1 + 0.25 * L;
  const eng = e.hasRole('Engineer') ? 0.6 : 1;
  const em = { id: ++e.emId, type, planet: P.id, day: e.t, level: L, sev, mult, choices: [], effectNow: '', done: false };

  if (type === 'dust') {
    if (mars) {
      const dur = ev.dur ?? (2.5 + L * 0.8 + Math.random()), peak = ev.peak ?? [0.6, 0.75, 0.85, 0.9][L];
      Object.assign(em, {
        icon: '🌪️', title: ev.global ? 'GLOBAL dust storm!' : 'Dust storm approaching!', duration: dur + 0.6,
        cause: ev.global
          ? `A <b>planet-wide dust storm</b> is wrapping around Mars. For about <b>${Math.round(dur)} sols</b> the dust will block up to <b>${Math.round(peak * 82)}%</b> of the sunlight reaching your solar arrays.`
          : `Wind is lifting dust off the plains. A regional storm will block up to <b>${Math.round(peak * 82)}%</b> of the sunlight for about <b>${Math.round(dur)} sols</b>.`,
        effectNow: `Solar power will drop to about ${Math.round((1 - peak * 0.82) * 100)}% while the storm lasts.`,
        fact: 'In 2018 a global Martian dust storm lasted months and ended the solar-powered Opportunity rover\'s mission.',
        onset: () => {
          if (e.storm && e.t < e.storm.until) { e.storm.until = Math.max(e.storm.until, e.t + dur); e.storm.peak = Math.max(e.storm.peak, peak); }
          else e.storm = { start: e.t, until: e.t + dur, peak };
          e.unlock('duststorm', true);
        },
      });
      em.choices = [
        { id: 'powerplan', icon: '⚡', label: 'Emergency power plan', desc: 'Switch the Science Lab and Fabricator off until the storm passes. Life support keeps its power.', costs: {}, note: 'Lose science and materials production during the storm', points: 30,
          apply: () => { em.switched = [...e.buildings.values()].filter((b) => (b.type === 'lab' || b.type === 'fabricator') && b.on); em.switched.forEach((b) => (b.on = false)); } },
        { id: 'eva', icon: '🧹', label: 'EVA: clean & re-angle panels', desc: 'Two astronauts go out every sol to clear dust, so the arrays catch more of the hazy light.', costs: { o2: 3, health: Math.round(8 * sev) }, note: `Storm blocks 30% less light; 2 crew lose ${Math.round(8 * sev)}% health`, points: 20,
          apply: () => { if (e.storm) e.storm.peak *= 0.7; e.buildings.forEach((b) => { if (b.type === 'solar') b.dust = 1; }); e.hurtCrew(2, 8 * sev); } },
        { id: 'ride', icon: '🔋', label: 'Ride it out on batteries', desc: 'Change nothing and hope the stored energy lasts.', costs: {}, note: 'Free, but life support may run out of power at night', points: 0, apply: () => {} },
      ];
      em.success = () => !em.hadCold && !em.lostCrew;
      em.onEnd = () => { (em.switched || []).forEach((b) => { if (e.buildings.has(b.id)) b.on = true; }); };
    } else {
      const dirt = Math.max(0.35, 0.58 - 0.06 * L);
      Object.assign(em, {
        icon: '🌫️', title: 'Regolith dust cloud!', duration: 3,
        cause: 'The Moon has no wind, but a meteorite hit the ground nearby and sprayed fine regolith over the base. The dust is electrically charged, so it clings to the solar panels.',
        effectNow: `Solar arrays coated: output drops to ${Math.round(dirt * 100)}% until cleaned.`,
        fact: 'Apollo 17 astronaut Harrison Schmitt got "lunar hay fever" from sharp Moon dust. In 2025 NASA\'s Electrodynamic Dust Shield lifted dust off surfaces on the Blue Ghost lander.',
        onset: () => { e.buildings.forEach((b) => { if (b.type === 'solar') b.dust = Math.min(b.dust, dirt); }); e.dustCloudUntil = e.t + 0.8; },
      });
      const evaOK = e.canEVA();
      em.choices = [
        { id: 'eva', icon: '🧑‍🚀', label: 'EVA brush-off', desc: 'Two astronauts brush the panels clean by hand. Sharp dust irritates eyes and lungs.', costs: { o2: 3, health: Math.round(6 * sev) }, note: `Panels 100% clean; 2 crew lose ${Math.round(6 * sev)}% health`, points: 25,
          available: evaOK, why: 'Too dark or unsafe for a spacewalk right now',
          apply: () => { e.buildings.forEach((b) => { if (b.type === 'solar') b.dust = 1; }); e.hurtCrew(2, 6 * sev); } },
        { id: 'eds', icon: '⚡', label: 'Electrodynamic dust shield', desc: 'Pulse electric fields through the panel covers to push the charged dust off.', costs: { battery: 30, mat: 40 }, note: 'Panels 92% clean, no spacewalk needed', points: 30,
          apply: () => { e.buildings.forEach((b) => { if (b.type === 'solar') b.dust = Math.max(b.dust, 0.92); }); } },
        { id: 'leave', icon: '⏳', label: 'Leave it for now', desc: 'Moon dust does not blow away. Panels stay dirty until someone cleans them.', costs: {}, note: 'Free, but solar power stays low', points: 0, apply: () => {} },
      ];
      em.success = () => [...e.buildings.values()].filter((b) => b.type === 'solar').every((b) => b.dust > 0.8) && !em.lostCrew;
    }
  }

  if (type === 'o2fail') {
    const gens = builtOf(e, 'oxygen').filter((b) => b.cond > 0);
    if (!gens.length) return null;
    const g = pick(gens);
    const repair = Math.round(90 * sev * eng);
    Object.assign(em, {
      icon: '🫁', title: 'Oxygen generator failure!', duration: 4, target: g.id,
      cause: mars
        ? 'Fine Martian dust choked the CO₂ intake filter and one solid-oxide electrolysis cell has cracked. The generator has shut down.'
        : 'Minerals dissolved in the lunar ice water have fouled the electrolyser membrane. The generator has shut down.',
      effectNow: `Oxygen production from this generator: 0 kg/day. The crew still breathes ${(0.84 * e.crewActive()).toFixed(2)} kg/day.`,
      fact: 'The ISS keeps "oxygen candles" as a backup. Each one holds lithium perchlorate, a chemical that gives off oxygen when it is lit. One candle makes about a day of oxygen for one person.',
      onset: () => { g.cond = 0; },
    });
    em.choices = [
      { id: 'repair', icon: '🔧', label: 'Full repair', desc: 'Replace the broken cell and filters.', costs: { mat: repair }, note: 'Back to 100% immediately', points: 30, apply: () => { g.cond = 100; } },
      mars
        ? { id: 'filter', icon: '🧹', label: 'Clean the intake filter', desc: 'An astronaut clears the dust. The cracked cell stays, so output is lower.', costs: { mat: 20, health: 5 }, note: 'Runs at 70%; 1 crew loses 5% health', points: 20, apply: () => { g.cond = 70; e.hurtCrew(1, 5); } }
        : { id: 'flush', icon: '💧', label: 'Flush with clean water', desc: 'Rinse the membrane with distilled water.', costs: { water: 15, mat: 10 }, note: 'Runs at 75%', points: 20, apply: () => { g.cond = 75; } },
      { id: 'candles', icon: '🕯️', label: 'Burn oxygen candles', desc: 'Release 10 kg of emergency oxygen now and repair the generator later from its info panel.', costs: { mat: 25 }, note: '+10 kg O₂ now, generator stays OFF until repaired', points: 5, apply: () => { e.res.o2 = Math.min(150, e.res.o2 + 10); } },
    ];
    em.success = () => e.buildings.has(g.id) && g.cond > 0 && e.res.o2 > 0 && !em.lostCrew;
  }

  if (type === 'waterleak') {
    const rate = (mars && e.pipeHeated ? 0.5 : 1) * (8 + 4 * L);
    const rec = builtOf(e, 'recycler').find((b) => b.on && b.cond > 0); // needs a working recycler
    Object.assign(em, {
      icon: '🚿', title: 'Water system leak!', duration: 6, leakRate: rate, leakUntil: e.t + 6,
      cause: mars
        ? 'A water pipe froze in the −80 °C night and burst. Water is spraying out and freezing on the floor.'
        : 'Huge temperature swings cracked a water line. Escaping water boils and freezes at once in the vacuum.',
      effectNow: `5% of stored water lost, and it keeps leaking at ${rate.toFixed(0)} L/day until fixed.`,
      fact: 'Water is precious in space: the ISS recycles about 98% of its water, including sweat and urine.',
      onset: () => { em.lostAtOnset = e.res.water * 0.05; e.res.water *= 0.95; },
    });
    em.choices = [
      { id: 'replace', icon: '🔧', label: 'Replace the pipe section', desc: 'Shut the valves and fit a new pipe.', costs: { mat: Math.round(50 * sev * eng) }, note: 'Leak stops now', points: 30, apply: () => { em.leakRate = 0; } },
      { id: 'patch', icon: '🩹', label: 'Patch with sealant tape', desc: 'Quick and cheap, but the patch seeps.', costs: { mat: 15 }, note: `Leak slows to ${(rate * 0.25).toFixed(0)} L/day for 6 days`, points: 15, apply: () => { em.leakRate = rate * 0.25; } },
      mars
        ? { id: 'heat', icon: '🔥', label: 'Add pipe heaters & insulation', desc: 'Fix the pipe and keep it warm so future freezes leak half as much.', costs: { battery: 25, mat: 30 }, note: 'Leak stops; future Mars pipe leaks halved', points: 25, apply: () => { em.leakRate = 0; e.pipeHeated = true; } }
        : { id: 'reroute', icon: '♻️', label: 'Reroute through the recycler', desc: 'Send the leaking line through the Water Recycler and recover what was lost.', costs: {}, note: 'Leak stops, 50% of lost water recovered; recycler −30% condition', points: 25,
          available: !!rec, why: 'Needs a working Water Recycler',
          apply: () => { em.leakRate = 0; if (rec) rec.cond = Math.max(0, rec.cond - 30); e.res.water += ((em.lostAtOnset || 0) + (em.leaked || 0)) * 0.5; } },
    ];
    em.success = () => e.res.water > 0 && !em.lostCrew;
  }

  if (type === 'batfail') {
    const bats = builtOf(e, 'battery').filter((b) => b.cond > 0);
    const b = bats.length ? pick(bats) : null;
    Object.assign(em, {
      icon: '🔋', title: 'Battery failure!', duration: 3, target: b ? b.id : 'lander',
      cause: mars
        ? `${b ? 'A Battery Bank' : 'The lander battery'} froze during the −80 °C night. Cold lithium cells lose capacity and can be damaged when charged.`
        : `${b ? 'A Battery Bank' : 'The lander battery'} overheated in constant sunlight. With no air to carry heat away, one cell went into thermal runaway.`,
      effectNow: b ? '45% of stored energy lost and this bank is down to 30% capacity.' : '45% of stored energy lost and the lander battery is down to half capacity.',
      fact: 'Batteries work best between about 0 °C and 40 °C, so space batteries need heaters and radiators.',
      onset: () => { e.res.battery *= 0.55; if (b) b.cond = 30; else e.landerCapLoss = 25; },
    });
    const restore = () => { if (b) b.cond = 100; else e.landerCapLoss = 0; };
    em.choices = [
      { id: 'replace', icon: '🔋', label: 'Replace damaged cells', desc: 'Swap in new cells from spares.', costs: { mat: Math.round((b ? 70 : 40) * sev * eng) }, note: 'Full capacity restored', points: 30, apply: restore },
      { id: 'isolate', icon: '✂️', label: 'Isolate the bad module', desc: 'Disconnect the damaged cells. Safe, but you lose capacity until you repair it.', costs: {}, note: b ? 'Bank stays at 50% capacity until repaired' : 'Lander battery stays at half capacity', points: 15,
        apply: () => { if (b) b.cond = 50; } },
      { id: 'gamble', icon: '🎲', label: 'Keep using it', desc: 'Reconnect everything and hope the cell holds.', costs: {}, note: `Full capacity now, but a ${Math.round((0.5 + 0.1 * L) * 100)}% chance of thermal runaway (fire) within a day`, points: 0,
        apply: () => { restore(); em.runawayAt = e.t + 0.6; em.runawayChance = 0.5 + 0.1 * L; } },
    ];
    em.success = () => !em.runaway && !em.hadCold && !em.lostCrew;
  }

  if (type === 'radiation') {
    // a real NASA DONKI solar energetic particle (SEP) event shapes this alert; its strength scales the
    // simulated dose (game rule): strong ×1.25 (GOES >100 MeV), moderate ×1, minor ×0.8
    const nasa = NasaData.disabled ? null : NasaData.nextStorm();
    const nf = nasa ? STRENGTH[nasa.strength].factor : 1;
    // Mars: the CO₂ air stops most solar protons (NASA estimates ~20–100 mSv on the surface for the biggest storms
    // of the space age); the airless Moon gets the full storm. Values are simulated (game), scaled by the real storm.
    const dose = Math.round((ev.dose ?? Math.round((mars ? 55 : 350) * [1, 1.15, 1.3, 1.45][L])) * nf);
    const shields = e.habitatShields();
    Object.assign(em, {
      icon: '☢️', title: 'Radiation alert!', duration: 0.85, dose, nasa, baseDose: Math.round(dose / nf),
      cause: mars
        ? `Satellites saw a big eruption on the Sun: a solar flare and a fast cloud of solar gas called a coronal mass ejection (CME). Its shock wave speeds up protons. Mars's thin air stops most of them. Still, an unprotected astronaut would get about <b>${dose} mSv</b> in this extreme storm. The game gives you about 6 hours of warning. In real life the first protons can arrive within an hour.`
        : `Satellites saw a big eruption on the Sun: a solar flare and a fast cloud of solar gas called a coronal mass ejection (CME). Its shock wave speeds up protons. The Moon has no air and no magnetic field to stop them. An unprotected astronaut would get about <b>${dose} mSv</b>. The game gives you about 6 hours of warning. In real life the first protons can arrive within an hour.`,
      effectNow: `${shields >= 2 ? '✅ Your 2+ shields already cut the dose by ~90%.' : `⚠ Only ${shields} shield${shields === 1 ? '' : 's'} touching the habitat.`} NASA's limit is 250 mSv per solar storm: above it the crew's health suffers. Every dose also adds to the 600 mSv career limit.`,
      fact: 'Water and hydrogen-rich materials are good radiation shields. Astronauts could surround their sleeping area with water tanks during a solar storm.',
      onset: () => { e.unlock('radiation', true); },
    });
    em.choices = [
      { id: 'shelter', icon: '🏠', label: 'Everyone into the storm shelter', desc: 'The crew gathers in the most shielded part of the habitat. Lab, fabricator and construction stop during the storm.', costs: {}, note: 'Dose ×0.5; no science or materials for half a day', points: shields >= 2 ? 40 : 30,
        apply: () => { em.mit = { factor: 0.5, shelter: true }; } },
      { id: 'waterwall', icon: '💧', label: 'Build a water wall', desc: 'Stack water containers around the crew. Work inside continues, and 80% of the water is put back afterwards.', costs: { water: 60, mat: 10 }, note: 'Dose ×0.4; 48 L returned after the storm', points: 25,
        apply: () => { em.mit = { factor: 0.4, waterBack: 48 }; } },
      { id: 'work', icon: '🛠️', label: 'Keep working outside', desc: 'Two astronauts finish outside jobs during the storm, so construction does not stop. The other two shelter inside.', costs: {}, note: `2 crew get the full unshielded dose (~${dose} mSv)${dose > 250 ? ': over NASA\'s 250 mSv storm limit, so they get sick' : ''}, and it eats into their 600 mSv career limit`, points: -10,
        apply: () => { const out = e.crew.filter((c) => c.status === 'active').sort(() => Math.random() - 0.5).slice(0, 2).map((c) => c.name); em.mit = { factor: 1, workOutside: true, outside: out }; } },
    ];
    em.success = () => e.crew.every((c) => c.status !== 'active' || (c.stormDose || 0) < 250) && !em.lostCrew; // NASA's 250 mSv per-event limit
  }

  // scale points with the threat level; work out which choices are affordable
  em.choices.forEach((c) => {
    c.points = Math.round(c.points * mult);
    if (c.available === undefined) c.available = true;
    const R = e.res, k = c.costs;
    const lacks = [];
    if (k.mat && R.mat < k.mat) lacks.push('materials');
    if (k.water && R.water < k.water) lacks.push('water');
    if (k.o2 && R.o2 < k.o2 + 2) lacks.push('oxygen');
    if (k.battery && R.battery < k.battery) lacks.push('stored energy');
    if (k.health && e.crewActive() === 0) lacks.push('crew');
    if (lacks.length && c.available) { c.available = false; c.why = `Not enough ${lacks.join(' and ')}`; }
  });
  // If nothing is affordable, offer a free improvised option (with a weaker effect) instead of a free repair.
  if (!em.choices.some((c) => c.available)) {
    const fallback = {
      o2fail: { id: 'makedo', icon: '⏳', label: 'Make do for now', desc: 'No materials for a fix. The crew rests to breathe less while you gather materials.', note: 'Generator stays OFF until repaired from its info panel', apply: () => {} },
      waterleak: { id: 'buckets', icon: '🪣', label: 'Catch the drips', desc: 'No materials for a repair, so the crew collects what water it can.', note: 'Leak continues at half rate for 6 days', apply: () => { em.leakRate *= 0.5; } },
    }[type] || { id: 'endure', icon: '⏳', label: 'Endure it', desc: 'There is nothing you can afford to do right now.', note: 'No fix', apply: () => {} };
    em.choices.push({ ...fallback, costs: {}, points: 0, available: true });
  }
  return em;
}

export function payCosts(e, k) {
  if (k.mat) e.res.mat -= k.mat;
  if (k.water) e.res.water -= k.water;
  if (k.o2) e.res.o2 -= k.o2;
  if (k.battery) e.res.battery = Math.max(0, e.res.battery - k.battery);
}
