import * as THREE from 'three';
import { createContext, useContext, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { solarTex } from './terrain.js';

export const EARTH_POS = new THREE.Vector3(-900, 120, -760);

// ---------- materials ----------
export function makeMats(planetId) {
  const S = (o) => new THREE.MeshStandardMaterial(o);
  const mars = planetId === 'mars';
  return {
    white: S({ color: 0xe8edf2, roughness: 0.55, metalness: 0.15 }),
    grey: S({ color: 0x8b949e, roughness: 0.6, metalness: 0.5 }),
    dark: S({ color: 0x2a3038, roughness: 0.5, metalness: 0.6 }),
    gold: S({ color: 0xd9a441, roughness: 0.28, metalness: 0.95 }),
    accent: S({ color: mars ? 0xff7a3d : 0x3ec5ff, roughness: 0.5, emissive: mars ? 0x401000 : 0x002a40 }),
    window: S({ color: 0x332a10, emissive: 0xffc96b, emissiveIntensity: 1.3, roughness: 0.3 }),
    cyanGlow: S({ color: 0x113344, emissive: 0x4fe3ff, emissiveIntensity: 1.4 }),
    solar: S({ map: solarTex(), roughness: 0.3, metalness: 0.5 }),
    tankBlue: S({ color: 0x8cc8ff, roughness: 0.35, metalness: 0.4 }),
    plant: S({ color: 0x2fa84f, roughness: 0.8, emissive: 0x0b3315 }),
    grow: S({ color: 0x441133, emissive: 0xff4fd8, emissiveIntensity: 1.6 }),
    glass: new THREE.MeshStandardMaterial({ color: 0xd8f0ff, roughness: 0.08, metalness: 0.1, transparent: true, opacity: 0.3, depthWrite: false, emissive: 0x220a22 }),
    berm: S({ color: mars ? 0x9b5b3c : 0x8e8e8a, roughness: 1 }),
    bermDark: S({ color: mars ? 0x7c4630 : 0x727270, roughness: 1 }),
    foundation: S({ color: mars ? 0x7a4a34 : 0x6a6a68, roughness: 0.95 }),
    reactorGlow: S({ color: 0x442200, emissive: 0xff8a2a, emissiveIntensity: 1.5 }),
    radiator: new THREE.MeshStandardMaterial({ color: 0xcfd6de, roughness: 0.35, metalness: 0.7, side: THREE.DoubleSide }),
    dish: new THREE.MeshStandardMaterial({ color: 0xf2f4f6, roughness: 0.35, metalness: 0.3, side: THREE.DoubleSide }),
    yellow: S({ color: 0xffd400, roughness: 0.5 }),
    led: new THREE.MeshBasicMaterial({ color: 0xff3b3b }),
    ghGlow: new THREE.MeshBasicMaterial({ color: 0xff4fd8, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false }),
  };
}
export const MatCtx = createContext(null);
const useM = () => useContext(MatCtx);
export function ghostMats(mat) { return new Proxy({}, { get: () => mat }); }

// ---------- primitives ----------
const Box = ({ a, m, p, r }) => { const M = useM(); return <mesh material={M[m]} position={p} rotation={r}><boxGeometry args={a} /></mesh>; };
const Cyl = ({ a, m, p, r, s = 20 }) => { const M = useM(); return <mesh material={M[m]} position={p} rotation={r}><cylinderGeometry args={[a[0], a[1], a[2], s]} /></mesh>; };
const Sph = ({ a, m, p, r }) => { const M = useM(); return <mesh material={M[m]} position={p} rotation={r}><sphereGeometry args={a} /></mesh>; };
const Cap = ({ a, m, p, r }) => { const M = useM(); return <mesh material={M[m]} position={p} rotation={r}><capsuleGeometry args={a} /></mesh>; };
const Tor = ({ a, m, p, r }) => { const M = useM(); return <mesh material={M[m]} position={p} rotation={r}><torusGeometry args={a} /></mesh>; };

const useActive = (b, engine) => () => (b && engine && engine.isActive(b) ? 1 : 0);

// ---------- models ----------
function Habitat({ b, engine }) {
  const beacon = useRef();
  useFrame(({ clock }) => { if (beacon.current) beacon.current.visible = Math.sin(clock.elapsedTime * 4) > 0; });
  return (
    <group>
      <Box a={[5.6, 0.25, 5.6]} m="foundation" p={[0, 0.12, 0]} />
      {[[-1.9, -1.1], [1.9, -1.1], [-1.9, 1.1], [1.9, 1.1]].map(([x, z], k) => <Cyl key={k} a={[0.12, 0.18, 0.8]} m="grey" p={[x, 0.6, z]} s={8} />)}
      <Cap a={[1.45, 2.4, 8, 28]} m="white" p={[0, 2.05, 0]} r={[0, 0, Math.PI / 2]} />
      {[-0.8, 0.8].map((x) => <Tor key={x} a={[1.47, 0.08, 8, 40]} m="accent" p={[x, 2.05, 0]} r={[0, Math.PI / 2, 0]} />)}
      {[-1.4, -0.45, 0.45, 1.4].map((x) => (
        <group key={x}>
          <Box a={[0.38, 0.28, 0.06]} m="window" p={[x, 2.45, 1.32]} r={[-0.35, 0, 0]} />
          <Box a={[0.38, 0.28, 0.06]} m="window" p={[x, 2.45, -1.32]} r={[0.35, 0, 0]} />
        </group>
      ))}
      <Cyl a={[0.55, 0.55, 1.0]} m="grey" p={[0, 1.55, 1.75]} r={[Math.PI / 2, 0, 0]} />
      <Cyl a={[0.4, 0.4, 0.06]} m="dark" p={[0, 1.55, 2.27]} r={[Math.PI / 2, 0, 0]} />
      <Box a={[1.2, 0.08, 1.0]} m="grey" p={[0, 0.95, 2.5]} />
      <Cyl a={[0.75, 0.75, 0.3]} m="grey" p={[0, 3.45, 0]} />
      <mesh material={useM().glass} position={[0, 3.6, 0]}><sphereGeometry args={[0.7, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2]} /></mesh>
      <Cyl a={[0.04, 0.04, 1.6]} m="grey" p={[2.2, 3.6, 0]} s={6} />
      <mesh ref={beacon} material={useM().led} position={[2.2, 4.45, 0]}><sphereGeometry args={[0.12, 8, 6]} /></mesh>
      <Box a={[1.4, 0.06, 0.8]} m="solar" p={[-2.2, 3.4, 0]} r={[0, 0, 0.3]} />
    </group>
  );
}

function Lander() {
  return (
    <group>
      <Cyl a={[0.7, 1.15, 1.4]} m="gold" p={[0, 1.5, 0]} s={8} />
      <Cyl a={[0.45, 0.7, 0.8]} m="white" p={[0, 2.6, 0]} s={16} />
      <Cyl a={[0.12, 0.45, 0.25]} m="grey" p={[0, 3.1, 0]} s={16} />
      <Cyl a={[0.35, 0.55, 0.5]} m="dark" p={[0, 0.6, 0]} s={16} />
      {[0, 1, 2, 3].map((k) => {
        const a = k * Math.PI / 2 + Math.PI / 4;
        return (
          <group key={k}>
            <Cyl a={[0.05, 0.05, 1.6]} m="grey" p={[Math.cos(a) * 1.15, 0.75, Math.sin(a) * 1.15]} r={[-Math.sin(a) * 0.5, 0, Math.cos(a) * 0.5]} s={6} />
            <Cyl a={[0.22, 0.25, 0.06]} m="grey" p={[Math.cos(a) * 1.5, 0.03, Math.sin(a) * 1.5]} s={12} />
          </group>
        );
      })}
      <Box a={[0.5, 0.32, 0.02]} m="accent" p={[0.5, 2.6, 0.62]} r={[0, 0.3, 0]} />
    </group>
  );
}

function Solar({ b, engine, planetId }) {
  const yaw = useRef(), pitch = useRef();
  const tall = planetId === 'moon';
  useFrame((_, dt) => {
    if (!engine || !yaw.current) return;
    const [x, , z] = engine.env.sunDir;
    const target = Math.atan2(x, z);
    let d = target - yaw.current.rotation.y; d = ((d + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
    yaw.current.rotation.y += d * Math.min(1, dt * 0.8);
    pitch.current.rotation.x = tall ? -(Math.PI / 2 - 0.08) : -Math.max(0.15, Math.PI / 2 - Math.max(0.1, engine.env.el)) * 0.9;
  });
  const h = tall ? 1.9 : 1.3;
  const M = useM();
  return (
    <group>
      <Cyl a={[0.35, 0.45, 0.2]} m="grey" p={[0, 0.1, 0]} s={12} />
      <Cyl a={[0.07, 0.07, h]} m="grey" p={[0, h / 2, 0]} s={8} />
      <group ref={yaw} position={[0, h, 0]}>
        <group ref={pitch}>
          <mesh material={[M.grey, M.grey, M.solar, M.dark, M.grey, M.grey]}><boxGeometry args={[tall ? 1.9 : 2.7, 0.06, tall ? 2.6 : 1.8]} /></mesh>
        </group>
      </group>
    </group>
  );
}

function Battery({ engine }) {
  const bar = useRef();
  const mat = useRef();
  useFrame(() => {
    if (!engine || !bar.current) return;
    const f = Math.max(0.02, engine.stats.cap ? engine.res.battery / engine.stats.cap : 0);
    bar.current.scale.x = f; bar.current.position.x = -0.75 * (1 - f);
    mat.current.color.setHSL(0.33 * f, 0.9, 0.55);
  });
  return (
    <group>
      <Box a={[2.2, 1.0, 1.3]} m="white" p={[0, 0.6, 0]} />
      <Box a={[2.25, 0.12, 1.35]} m="dark" p={[0, 0.08, 0]} />
      {[-2, -1, 0, 1, 2].map((k) => <Box key={k} a={[0.05, 0.85, 1.32]} m="grey" p={[k * 0.42, 0.6, 0]} />)}
      <Box a={[1.6, 0.18, 0.04]} m="dark" p={[0, 0.85, 0.67]} />
      <mesh ref={bar} position={[0, 0.85, 0.68]}><boxGeometry args={[1.5, 0.12, 0.05]} /><meshBasicMaterial ref={mat} color="#3dff8a" /></mesh>
    </group>
  );
}

function Reactor({ b, engine }) {
  const M = useM();
  const active = useActive(b, engine);
  useFrame(({ clock }) => { if (engine) M.reactorGlow.emissiveIntensity = 1.2 + Math.sin(clock.elapsedTime * 3) * 0.4 * active(); });
  return (
    <group>
      <Cyl a={[0.9, 1.1, 0.4]} m="dark" p={[0, 0.2, 0]} />
      <Cyl a={[0.92, 0.92, 0.06]} m="yellow" p={[0, 0.42, 0]} />
      <Cyl a={[0.45, 0.5, 1.3]} m="grey" p={[0, 1.05, 0]} />
      <Cyl a={[0.47, 0.47, 0.18]} m="reactorGlow" p={[0, 1.25, 0]} />
      <group position={[0, 1.7, 0]}>
        {Array.from({ length: 8 }, (_, k) => {
          const a = (k / 8) * Math.PI * 2;
          return <mesh key={k} material={M.radiator} position={[Math.cos(a) * 0.75, 0.35, Math.sin(a) * 0.75]} rotation={[0, -a, 0.35]}><planeGeometry args={[1.4, 1.1]} /></mesh>;
        })}
      </group>
      <Cyl a={[0.12, 0.12, 0.6]} m="gold" p={[0, 2.4, 0]} s={10} />
    </group>
  );
}

function Oxygen({ b, engine, planetId }) {
  const fan = useRef(); const active = useActive(b, engine);
  useFrame((_, dt) => { if (fan.current) fan.current.rotation.y += dt * 10 * active(); });
  return (
    <group>
      <Box a={[2.1, 0.7, 1.4]} m={planetId === 'mars' ? 'gold' : 'white'} p={[0, 0.45, 0]} />
      <Box a={[2.15, 0.1, 1.45]} m="dark" p={[0, 0.05, 0]} />
      {[-0.55, 0.05].map((x) => <Cap key={x} a={[0.28, 0.9, 6, 16]} m="tankBlue" p={[x, 1.55, -0.2]} />)}
      <Cyl a={[0.05, 0.05, 1.3]} m="grey" p={[-0.25, 2.3, -0.2]} r={[0, 0, Math.PI / 2]} s={6} />
      <group position={[0.7, 0.85, 0.3]}>
        <Cyl a={[0.38, 0.38, 0.08]} m="dark" p={[0, 0, 0]} s={16} />
        <group ref={fan} position={[0, 0.06, 0]}>
          {[0, 1, 2, 3].map((k) => <Box key={k} a={[0.62, 0.02, 0.1]} m="grey" r={[0, k * Math.PI / 4, 0]} />)}
        </group>
      </group>
      <Box a={[0.25, 0.25, 0.04]} m="cyanGlow" p={[-0.5, 0.5, 0.71]} />
    </group>
  );
}

function IceMiner({ b, engine }) {
  const drill = useRef(); const active = useActive(b, engine);
  useFrame(({ clock }, dt) => {
    if (!drill.current) return;
    const a = active();
    drill.current.rotation.y += dt * 6 * a;
    drill.current.position.y = a ? Math.sin(clock.elapsedTime * 2) * 0.15 - 0.1 : 0;
  });
  return (
    <group>
      {[0, 1, 2].map((k) => {
        const a = (k / 3) * Math.PI * 2;
        return <Cyl key={k} a={[0.06, 0.08, 3.0]} m="grey" p={[Math.cos(a) * 0.6, 1.4, Math.sin(a) * 0.6]} r={[-Math.sin(a) * 0.4, 0, Math.cos(a) * 0.4]} s={6} />;
      })}
      <Box a={[0.5, 0.35, 0.5]} m="accent" p={[0, 2.85, 0]} />
      <group ref={drill}>
        <Cyl a={[0.12, 0.12, 2.2]} m="grey" p={[0, 1.5, 0]} s={10} />
        <mesh material={useM().dark} position={[0, 0.3, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.2, 0.45, 8]} /></mesh>
        {[0, 1, 2, 3, 4, 5].map((k) => <Box key={k} a={[0.36, 0.03, 0.08]} m="dark" p={[0, 0.7 + k * 0.25, 0]} r={[0, k * 0.6, 0]} />)}
      </group>
      <Cyl a={[0.45, 0.45, 1.0]} m="tankBlue" p={[1.0, 0.5, 0.5]} s={16} />
      <Box a={[0.9, 0.6, 0.7]} m="white" p={[-0.9, 0.3, 0.6]} />
      <Box a={[0.6, 0.15, 0.4]} m="cyanGlow" p={[-0.9, 0.65, 0.6]} />
    </group>
  );
}

function Recycler({ b, engine }) {
  const ring = useRef(); const active = useActive(b, engine);
  useFrame((_, dt) => { if (ring.current) ring.current.rotation.z += dt * 3 * active(); });
  const M = useM();
  return (
    <group>
      <Box a={[1.8, 0.9, 1.2]} m="white" p={[0, 0.5, 0]} />
      <Box a={[1.85, 0.1, 1.25]} m="accent" p={[0, 0.95, 0]} />
      {[-0.55, 0.05, 0.65].map((x) => <Sph key={x} a={[0.32, 16, 12]} m="tankBlue" p={[x, 1.35, -0.1]} />)}
      {[-0.25, 0.35].map((x) => <Cyl key={x} a={[0.05, 0.05, 0.4]} m="grey" p={[x, 1.35, -0.1]} r={[0, 0, Math.PI / 2]} s={6} />)}
      <mesh ref={ring} material={M.cyanGlow} position={[-0.4, 0.55, 0.62]}><torusGeometry args={[0.25, 0.05, 8, 20]} /></mesh>
    </group>
  );
}

function Greenhouse({ b, engine }) {
  const M = useM();
  const glow = useRef();
  const active = useActive(b, engine);
  useFrame(() => { if (glow.current && engine) glow.current.material.opacity = (0.08 + (1 - engine.env.day) * 0.18) * (active() ? 1 : 0.2); });
  return (
    <group>
      <Cyl a={[1.4, 1.45, 0.3]} m="white" p={[0, 0.15, 0]} s={28} />
      {[-2, -1, 0, 1, 2].map((r) => (
        <group key={r}>
          <Box a={[0.25, 0.25, 2.0 - Math.abs(r) * 0.35]} m="dark" p={[r * 0.45, 0.42, 0]} />
          <Box a={[0.22, 0.32, 1.9 - Math.abs(r) * 0.35]} m="plant" p={[r * 0.45, 0.68, 0]} />
          <Box a={[0.08, 0.04, 1.8 - Math.abs(r) * 0.35]} m="grow" p={[r * 0.45, 1.25 - Math.abs(r) * 0.12, 0]} />
        </group>
      ))}
      <mesh material={M.glass} position={[0, 0.3, 0]} renderOrder={2}><sphereGeometry args={[1.4, 28, 14, 0, Math.PI * 2, 0, Math.PI / 2]} /></mesh>
      {[0, 1, 2, 3].map((k) => <mesh key={k} material={M.grey} position={[0, 0.3, 0]} rotation={[0, k * Math.PI / 4, 0]}><torusGeometry args={[1.41, 0.025, 6, 32, Math.PI]} /></mesh>)}
      <mesh ref={glow} position={[0, 0.3, 0]}><sphereGeometry args={[1.3, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2]} /><meshBasicMaterial color="#ff4fd8" transparent opacity={0.12} blending={THREE.AdditiveBlending} depthWrite={false} /></mesh>
    </group>
  );
}

function Shield() {
  return <group>{[0, 1, 2, 3, 4].map((k) => <Box key={k} a={[2.9 - k * 0.22, 0.26, 2.9 - k * 0.22]} m={k % 2 ? 'bermDark' : 'berm'} p={[0, 0.13 + k * 0.26, 0]} />)}</group>;
}

function Fabricator({ b, engine }) {
  const base = useRef(), s1 = useRef(), s2 = useRef(); const active = useActive(b, engine);
  useFrame(({ clock }) => {
    if (!base.current) return;
    const t = clock.elapsedTime, s = active();
    base.current.rotation.y = Math.sin(t * 0.9) * 1.2 * s;
    s1.current.rotation.z = 0.4 + Math.sin(t * 1.3) * 0.3 * s;
    s2.current.rotation.z = 0.9 + Math.sin(t * 1.7) * 0.4 * s;
  });
  return (
    <group>
      <Box a={[2.2, 1.1, 1.0]} m="grey" p={[0, 0.55, -0.6]} />
      <Box a={[1.6, 0.35, 0.04]} m="window" p={[0, 0.7, -0.09]} />
      <Box a={[1.4, 0.1, 1.2]} m="dark" p={[0.3, 0.05, 0.6]} />
      {[0, 1, 2, 3, 4].map((k) => <Box key={k} a={[0.35, 0.18, 0.2]} m="berm" p={[-0.6 + (k % 3) * 0.38, 0.19 + Math.floor(k / 3) * 0.19, 0.95]} />)}
      <group ref={base} position={[0.6, 0.1, 0.5]}>
        <Cyl a={[0.22, 0.28, 0.25]} m="accent" p={[0, 0.12, 0]} s={12} />
        <group ref={s1} position={[0, 0.25, 0]}>
          <Box a={[0.14, 1.0, 0.14]} m="white" p={[0, 0.5, 0]} />
          <group ref={s2} position={[0, 1.0, 0]}>
            <Box a={[0.12, 0.8, 0.12]} m="white" p={[0, 0.4, 0]} />
            <Cyl a={[0.04, 0.08, 0.2]} m="dark" p={[0, 0.85, 0]} s={8} />
          </group>
        </group>
      </group>
    </group>
  );
}

function Lab({ b, engine }) {
  const mast = useRef(); const active = useActive(b, engine);
  const M = useM();
  useFrame((_, dt) => { if (mast.current) mast.current.rotation.y += dt * 0.6 * active(); });
  return (
    <group>
      <Box a={[2.4, 1.3, 1.6]} m="white" p={[0, 0.75, 0]} />
      <Box a={[2.45, 0.12, 1.65]} m="accent" p={[0, 1.2, 0]} />
      {[-1, 0, 1].map((k) => <Box key={k} a={[0.45, 0.3, 0.04]} m="cyanGlow" p={[k * 0.7, 0.85, 0.81]} />)}
      <mesh material={M.glass} position={[-0.5, 1.4, 0]}><sphereGeometry args={[0.5, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2]} /></mesh>
      <group ref={mast} position={[0.7, 1.4, -0.3]}>
        <Cyl a={[0.04, 0.04, 0.9]} m="grey" p={[0, 0.45, 0]} s={6} />
        <mesh material={M.dish} position={[0, 0.95, 0]} rotation={[-1.1, 0, 0]}><sphereGeometry args={[0.35, 16, 8, 0, Math.PI * 2, 0, 0.7]} /></mesh>
      </group>
    </group>
  );
}

function Comms({ b, engine, planetId }) {
  const yaw = useRef(), pitch = useRef(); const active = useActive(b, engine);
  const M = useM();
  useFrame((_, dt) => {
    if (!yaw.current || !engine) return;
    if (planetId === 'moon') {
      const [x, , z] = engine.worldPos(b);
      const d = EARTH_POS.clone().sub(new THREE.Vector3(x, 1.75, z)).normalize();
      yaw.current.rotation.y = Math.atan2(d.x, d.z);
      pitch.current.rotation.x = Math.PI / 2 - Math.asin(d.y);
    } else { yaw.current.rotation.y += dt * 0.15 * active(); pitch.current.rotation.x = 0.7; }
  });
  return (
    <group>
      <Cyl a={[0.5, 0.65, 0.3]} m="grey" p={[0, 0.15, 0]} s={16} />
      <Cyl a={[0.1, 0.12, 1.4]} m="grey" p={[0, 1.0, 0]} s={8} />
      <group ref={yaw} position={[0, 1.75, 0]}>
        <group ref={pitch}>
          <mesh material={M.dish} position={[0, 1.5, 0]} rotation={[Math.PI, 0, 0]}><sphereGeometry args={[1.5, 28, 10, 0, Math.PI * 2, 0, 0.62]} /></mesh>
          <Cyl a={[0.03, 0.03, 1.0]} m="grey" p={[0, 0.5, 0]} s={6} />
          <Cyl a={[0.1, 0.06, 0.18]} m="gold" p={[0, 1.0, 0]} s={8} />
        </group>
      </group>
    </group>
  );
}

const MODELS = { habitat: Habitat, lander: Lander, solar: Solar, battery: Battery, reactor: Reactor, oxygen: Oxygen, ice: IceMiner, recycler: Recycler, greenhouse: Greenhouse, shield: Shield, fabricator: Fabricator, lab: Lab, comms: Comms };

export function Model({ type, ...props }) {
  const C = MODELS[type];
  return C ? <C {...props} /> : null;
}

// Small cargo lander used for resupply drops
export function CargoCraft() {
  return (
    <group>
      <Cyl a={[0.6, 1.0, 1.6]} m="white" p={[0, 1.4, 0]} s={12} />
      <Cyl a={[0.1, 0.6, 0.6]} m="gold" p={[0, 2.5, 0]} s={12} />
      <Box a={[1.2, 0.5, 1.2]} m="gold" p={[0, 0.6, 0]} />
      {[0, 1, 2, 3].map((k) => { const a = k * Math.PI / 2; return <Cyl key={k} a={[0.05, 0.05, 1.2]} m="grey" p={[Math.cos(a) * 0.9, 0.45, Math.sin(a) * 0.9]} r={[-Math.sin(a) * 0.4, 0, Math.cos(a) * 0.4]} s={6} />; })}
    </group>
  );
}
