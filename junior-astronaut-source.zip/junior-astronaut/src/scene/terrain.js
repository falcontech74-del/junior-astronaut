import * as THREE from 'three';
import { smooth, angDiff, moonMassifAz } from '../engine.js';
import { PLANETS } from '../data.js';

export function makeRng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function hash2(x, z) { const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453; return s - Math.floor(s); }
function vnoise(x, z) {
  const xi = Math.floor(x), zi = Math.floor(z), xf = x - xi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = zf * zf * (3 - 2 * zf);
  const a = hash2(xi, zi), b = hash2(xi + 1, zi), c = hash2(xi, zi + 1), d = hash2(xi + 1, zi + 1);
  return (a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v) * 2 - 1;
}
export function fbm(x, z, oct = 5) {
  let f = 0, amp = 0.5, fr = 1;
  for (let i = 0; i < oct; i++) { f += amp * vnoise(x * fr, z * fr); fr *= 2.03; amp *= 0.5; }
  return f;
}

// Procedural planet surface: flat landing zone in the middle, craters, dunes / highlands further out.
export function makeLand(planetId) {
  const massifAz = moonMassifAz(PLANETS.moon);
  const rng = makeRng(planetId === 'mars' ? 11 : 23);
  const craters = [];
  const nC = planetId === 'moon' ? 46 : 14;
  for (let k = 0; k < nC; k++) {
    const a = rng() * Math.PI * 2, d = 46 + rng() * 210;
    const r = 3 + rng() ** 2 * (planetId === 'moon' ? 26 : 30);
    craters.push({ x: Math.cos(a) * d, z: Math.sin(a) * d, r, depth: r * 0.28, rim: r * 0.1 });
  }
  // a few small craters just outside the base for realism
  for (let k = 0; k < (planetId === 'moon' ? 8 : 4); k++) {
    const a = rng() * Math.PI * 2, d = 38 + rng() * 12;
    const r = 2 + rng() * 3;
    craters.push({ x: Math.cos(a) * d, z: Math.sin(a) * d, r, depth: r * 0.3, rim: r * 0.12, keep: true });
  }
  const psr = planetId === 'moon' ? { x: 58, z: -40, r: 24 } : { x: 72, z: 48, r: 22 };
  craters.push({ ...psr, depth: planetId === 'moon' ? 16 : 8, rim: 3.2, keep: true });

  const height = (x, z) => {
    const r = Math.hypot(x, z);
    const f = smooth(33, 70, r);
    let h = fbm(x * 0.012, z * 0.012, 5) * (planetId === 'mars' ? 22 : 14) * f;
    h += fbm(x * 0.08 + 9, z * 0.08, 3) * 1.4 * (0.08 + f);
    if (planetId === 'mars') {
      h += smooth(140, 260, r) * (fbm(x * 0.006 + 3, z * 0.006, 4) * 70 + 30);
      h += Math.sin(x * 0.35 + fbm(x * 0.03, z * 0.03, 2) * 6) * 0.25 * f;
    } else {
      h += smooth(160, 300, r) * (fbm(x * 0.005 + 7, z * 0.005, 4) * 30 + 8);
      // distant massif that hides the low polar Sun for part of each lunar day
      const d = Math.abs(angDiff(Math.atan2(x, z), massifAz));
      h += smooth(0.95, 0.45, d) * smooth(110, 230, r) * (110 + fbm(x * 0.02, z * 0.02, 3) * 40);
    }
    for (const c of craters) {
      const d = Math.hypot(x - c.x, z - c.z) / c.r;
      if (d < 1.6) {
        let ch = 0;
        if (d < 1) ch += c.depth * (d * d - 1);
        ch += c.rim * Math.exp(-(((d - 1) / 0.22) ** 2));
        h += ch * (c.keep ? 1 : f);
      }
    }
    if (r < 33) h *= r > 31 ? smooth(31, 33, r) : 0; // perfectly flat build zone
    return h;
  };
  return { height, craters, psr, rng };
}

export function terrainGeometry(planetId, land, mobile) {
  const size = 640, seg = mobile ? 170 : 230;
  const geo = new THREE.PlaneGeometry(size, size, seg, seg);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const base = planetId === 'mars'
    ? [new THREE.Color(0xa45a35), new THREE.Color(0xc98654), new THREE.Color(0x6e3a22)]
    : [new THREE.Color(0x8a8a88), new THREE.Color(0xb3b2ae), new THREE.Color(0x585856)];
  const pad = planetId === 'mars' ? new THREE.Color(0x9a5636) : new THREE.Color(0x7f7f7c);
  const shadowFloor = new THREE.Color(0x2a3036);
  const tmp = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const h = land.height(x, z);
    pos.setY(i, h);
    const n = fbm(x * 0.05 + 40, z * 0.05, 4) * 0.5 + 0.5;
    tmp.copy(base[0]).lerp(base[1], n);
    tmp.lerp(base[2], Math.max(0, Math.min(1, -h / 10)) * 0.8);
    const r = Math.hypot(x, z);
    if (r < 34) tmp.lerp(pad, 0.45 * (1 - smooth(26, 34, r)));
    if (planetId === 'moon') {
      const dp = Math.hypot(x - land.psr.x, z - land.psr.z) / land.psr.r;
      if (dp < 0.9) tmp.lerp(shadowFloor, 0.85 * (1 - dp / 0.9) + 0.1);
    }
    const j = (hash2(x * 3.1, z * 2.7) - 0.5) * 0.06;
    colors[i * 3] = tmp.r + j; colors[i * 3 + 1] = tmp.g + j; colors[i * 3 + 2] = tmp.b + j;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  return geo;
}

// ---------- canvas textures ----------
export function canvasTex(w, h, draw) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}
export const solarTex = () => canvasTex(256, 160, (g, w, h) => {
  g.fillStyle = '#0d1a3a'; g.fillRect(0, 0, w, h);
  const cw = w / 8, ch = h / 5;
  for (let i = 0; i < 8; i++) for (let j = 0; j < 5; j++) {
    const grd = g.createLinearGradient(i * cw, j * ch, (i + 1) * cw, (j + 1) * ch);
    grd.addColorStop(0, '#2a52b0'); grd.addColorStop(1, '#0f2560');
    g.fillStyle = grd; g.fillRect(i * cw + 2, j * ch + 2, cw - 4, ch - 4);
    g.fillStyle = 'rgba(200,220,255,0.25)'; g.fillRect(i * cw + 2, j * ch + ch / 2, cw - 4, 1);
  }
});
export const earthTex = () => canvasTex(512, 256, (g, w, h) => {
  const img = g.createImageData(w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const lat = Math.abs(y / h - 0.5) * 2;
    const n = fbm(x / 40, y / 40, 5) + 0.1 * Math.cos(lat * 3);
    const cl = fbm(x / 22 + 50, y / 14 + 9, 4);
    const k = (y * w + x) * 4;
    let r = 27, gg = 79, b = 156;
    if (n > 0.08) { r = 70 + n * 120; gg = 110 + n * 60; b = 60; if (lat > 0.25 && lat < 0.55) { r = 170; gg = 140; b = 90; } }
    if (lat > 0.85) { r = gg = b = 240; }
    if (cl > 0.18) { const a = Math.min(1, (cl - 0.18) * 4); r += (250 - r) * a; gg += (250 - gg) * a; b += (255 - b) * a; }
    img.data[k] = r; img.data[k + 1] = gg; img.data[k + 2] = b; img.data[k + 3] = 255;
  }
  g.putImageData(img, 0, 0);
});
export const glowTex = (inner, outer) => canvasTex(128, 128, (g, w) => {
  const grd = g.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2);
  grd.addColorStop(0, inner); grd.addColorStop(0.25, inner); grd.addColorStop(1, outer);
  g.fillStyle = grd; g.fillRect(0, 0, w, w);
});
export const iceTex = () => canvasTex(128, 128, (g, w, h) => {
  g.fillStyle = '#b9d8ee'; g.fillRect(0, 0, w, h);
  const r = makeRng(5);
  for (let i = 0; i < 60; i++) {
    g.fillStyle = `rgba(${230 + r() * 25},245,255,${0.3 + r() * 0.5})`;
    g.beginPath(); g.ellipse(r() * w, r() * h, 3 + r() * 12, 2 + r() * 6, r() * 3, 0, 7); g.fill();
  }
  g.strokeStyle = 'rgba(255,255,255,0.7)'; g.lineWidth = 3; g.strokeRect(2, 2, w - 4, h - 4);
});
