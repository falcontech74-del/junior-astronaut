import * as THREE from 'three';
import { useEffect, useLayoutEffect, useMemo, useRef, useSyncExternalStore } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Stars, Grid, Billboard, Edges, Sparkles, AdaptiveDpr, PerformanceMonitor } from '@react-three/drei';
import { Settings } from '../settings.js';
import { GRID, TILE, HALF, HAB, LANDING_PAD, tileToWorld, smooth } from '../engine.js';
import { BUILDINGS } from '../data.js';
import { Sound } from '../bus.js';
import { makeLand, terrainGeometry, earthTex, glowTex, iceTex, hash2, canvasTex } from './terrain.js';
import { makeMats, MatCtx, ghostMats, Model, CargoCraft, EARTH_POS } from './models.jsx';

const isMobile = () => Math.min(window.innerWidth, window.innerHeight) < 700;

export default function World({ engine, onReady }) {
  const mobile = useMemo(isMobile, []);
  const gfx = useMemo(() => Settings.gfx(), []); // graphics preset (Settings → Graphics quality)
  return (
    <Canvas
      shadows={{ type: THREE.PCFShadowMap }}
      dpr={[gfx.dpr[0], Math.min(gfx.dpr[1], mobile ? 1.6 : 2)]}
      gl={{ antialias: gfx.antialias, powerPreference: 'high-performance' }}
      onCreated={() => { if (onReady) requestAnimationFrame(() => requestAnimationFrame(onReady)); }}
      camera={{ position: [24, 22, 30], fov: window.innerWidth / window.innerHeight < 0.8 ? 62 : 50, near: 0.5, far: 3000 }}
      onPointerMissed={(e) => { if (e.type === 'click' && !engine.ui.buildType) engine.select(null); }}
      style={{ position: 'fixed', inset: 0, touchAction: 'none' }}
    >
      <Scene engine={engine} mobile={mobile} gfx={gfx} />
    </Canvas>
  );
}

function Scene({ engine, mobile, gfx }) {
  const { setDpr } = useThree();
  useSyncExternalStore(engine.subscribe, engine.getVersion);
  const planetId = engine.planet.id;
  const mats = useMemo(() => makeMats(planetId), [planetId]);
  const land = useMemo(() => makeLand(planetId), [planetId]);
  return (
    <MatCtx.Provider value={mats}>
      <EngineDriver engine={engine} />
      <CameraRig engine={engine} land={land} />
      <Atmosphere engine={engine} gfx={gfx} />
      <Ground engine={engine} land={land} mobile={mobile} gfx={gfx} />
      <BuildGrid engine={engine} />
      <InteractionPlane engine={engine} />
      {[...engine.buildings.values()].map((b) => <Building key={b.id} b={b} engine={engine} />)}
      <Ghost engine={engine} />
      <SelectRing engine={engine} />
      <Astronauts engine={engine} />
      <DustStorm engine={engine} mobile={mobile || gfx.name === 'low'} />
      {gfx.sparkles && planetId === 'mars' && <Sparkles count={60} scale={[70, 6, 70]} position={[0, 3, 0]} size={2.2} speed={0.25} color="#e7b58a" opacity={0.35} noise={1.5} />}
      {engine.effects.map((e) => <Effect key={e.id} e={e} engine={engine} />)}
      <AdaptiveDpr pixelated />
      {/* lower the resolution automatically if the frame rate stays low (slow laptops, phones) */}
      <PerformanceMonitor onDecline={() => setDpr(gfx.dpr[0])} onIncline={() => setDpr(Math.min(window.devicePixelRatio || 1, gfx.dpr[1]))} flipflops={3} />
    </MatCtx.Provider>
  );
}

function EngineDriver({ engine }) {
  const { camera, gl } = useThree();
  useEffect(() => {
    if (!window.__ja) return;
    // test hook: project a tile to screen coordinates
    window.__ja.camera = camera;
    window.__ja.tileToScreen = (i, j) => {
      const p = new THREE.Vector3(...tileToWorld(i, j)).project(camera);
      const r = gl.domElement.getBoundingClientRect();
      return [r.left + (p.x + 1) / 2 * r.width, r.top + (1 - p.y) / 2 * r.height];
    };
  }, [camera, gl]);
  useFrame((_, dt) => { engine.tick(Math.min(dt, 0.1)); });
  return null;
}

// ---------- camera: orbit / zoom / pan + shake ----------
function CameraRig({ engine, land }) {
  const controls = useRef();
  const offset = useRef(new THREE.Vector3());
  const { camera } = useThree();
  useFrame(() => { camera.position.sub(offset.current); offset.current.set(0, 0, 0); }, -2);
  useFrame((_, dt) => {
    const c = controls.current; if (!c) return;
    c.target.x = THREE.MathUtils.clamp(c.target.x, -48, 48);
    c.target.z = THREE.MathUtils.clamp(c.target.z, -48, 48);
    c.target.y = 0;
    const gh = land.height(camera.position.x, camera.position.z);
    if (camera.position.y < gh + 2) camera.position.y = gh + 2;
    if (engine.shake > 0) {
      offset.current.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(engine.shake * 0.9);
      camera.position.add(offset.current);
      engine.shake = Math.max(0, engine.shake - dt * 1.2);
    }
  });
  useEffect(() => { if (window.__ja) window.__ja.controls = controls.current; });
  // cinematic landing fly-in: from high above down to the default view (any touch/drag ends it)
  const intro = useRef({ t0: performance.now(), on: !(window.__ja && window.__ja.noIntro) });
  useEffect(() => {
    const c = controls.current; if (!c) return;
    const stop = () => { intro.current.on = false; };
    c.addEventListener('start', stop);
    return () => c.removeEventListener('start', stop);
  }, []);
  useFrame(() => {
    const I = intro.current; if (!I.on || !controls.current) return;
    const k = Math.min(1, (performance.now() - I.t0) / 2400), e = 1 - Math.pow(1 - k, 3);
    camera.position.set(THREE.MathUtils.lerp(-40, 24, e), THREE.MathUtils.lerp(85, 22, e), THREE.MathUtils.lerp(75, 30, e));
    if (k >= 1) I.on = false;
  }, -1);
  // When the player picks the Ice Miner, glide the camera so the nearest free ice deposit is in view
  // (on phones the deposits can start off-screen, and an Ice Miner can only go on ice).
  const glide = useRef({ last: null, on: false, t0: 0, from: new THREE.Vector3(), d: new THREE.Vector3() });
  useEffect(() => {
    const c = controls.current; if (!c) return;
    const stop = () => { glide.current.on = false; };
    c.addEventListener('start', stop);
    return () => c.removeEventListener('start', stop);
  }, []);
  useFrame(() => {
    const G = glide.current, c = controls.current; if (!c) return;
    const bt = engine.ui.buildType;
    if (bt !== G.last) {
      G.last = bt;
      if (bt === 'ice') {
        const free = engine.iceTiles.filter(([i, j]) => engine.occ[i][j] == null);
        if (free.length) {
          const [hx, , hz] = tileToWorld(6, 6);
          const pts = free.map(([i, j]) => tileToWorld(i, j)).sort((a, b) => Math.hypot(a[0] - hx, a[2] - hz) - Math.hypot(b[0] - hx, b[2] - hz));
          const v = new THREE.Vector3(pts[0][0], 0, pts[0][2]).project(camera);
          if (Math.abs(v.x) > 0.7 || v.y < -0.35 || v.y > 0.45) {   // not comfortably visible (edges are covered by panels)
            const goal = new THREE.Vector3(pts[0][0] * 0.75 + hx * 0.25, 0, pts[0][2] * 0.75 + hz * 0.25);
            G.from.copy(c.target); G.d.copy(goal).sub(c.target); G.t0 = performance.now(); G.on = true;
          }
        }
      }
    }
    if (!G.on) return;
    const k = Math.min(1, (performance.now() - G.t0) / 700), e = 1 - Math.pow(1 - k, 3);
    const next = G.from.clone().addScaledVector(G.d, e), step = next.clone().sub(c.target);
    c.target.add(step); camera.position.add(step);
    if (k >= 1) G.on = false;
  });
  return (
    <OrbitControls ref={controls} makeDefault enableDamping dampingFactor={0.08} enablePan screenSpacePanning={false}
      minDistance={10} maxDistance={120} maxPolarAngle={1.38} target={[0, 0, 0]} regress
      touches={{ ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }} />
  );
}

// ---------- sky, sun, stars, fog, lights ----------
const skyVert = 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }';
const skyFrag = `uniform vec3 topColor, horizonColor, glowColor, sunDir; uniform float glowStrength, sunSize; varying vec3 vDir;
void main(){ vec3 d = normalize(vDir); float h = max(d.y, 0.0);
  vec3 col = mix(horizonColor, topColor, pow(h, 0.45));
  if (d.y < 0.0) col = horizonColor * 0.7;
  float s = max(dot(d, normalize(sunDir)), 0.0);
  col += glowColor * pow(s, 6.0) * glowStrength + glowColor * pow(s, 60.0) * glowStrength * 0.8;
  col += vec3(1.0, 0.97, 0.9) * smoothstep(sunSize, sunSize + 0.00012, s) * 3.0;
  gl_FragColor = vec4(col, 1.0); }`;

function Atmosphere({ engine, gfx }) {
  const planetId = engine.planet.id;
  const mars = planetId === 'mars';
  const { scene, camera, gl, controls } = useThree();
  const fill = useRef(), sky = useRef(), sun = useRef(), hemi = useRef(), amb = useRef(), sunSprite = useRef(), stars = useRef(), phobos = useRef(), deimos = useRef(), earth = useRef();
  const uniforms = useMemo(() => ({
    topColor: { value: new THREE.Color() }, horizonColor: { value: new THREE.Color() }, glowColor: { value: new THREE.Color() },
    sunDir: { value: new THREE.Vector3(0, 1, 0) }, glowStrength: { value: 0 }, sunSize: { value: mars ? 0.99975 : 0.99985 },
  }), [mars]);
  const tex = useMemo(() => ({ glow: glowTex('rgba(255,250,235,1)', 'rgba(255,200,120,0)'), earth: mars ? null : earthTex() }), [mars]);
  const C = useMemo(() => ({
    dayTop: new THREE.Color(0xb98a62), stormTop: new THREE.Color(0x6b4a3a), dayHor: new THREE.Color(0xe2b48a), stormHor: new THREE.Color(0xb07a50),
    nightTop: new THREE.Color(0x05060c), nightHor: new THREE.Color(0x1a1016), blue: new THREE.Color(0x5f9bff), warm: new THREE.Color(0xffd2a0), red: new THREE.Color(0xff9a5a),
    tmp: new THREE.Color(), tmp2: new THREE.Color(),
  }), []);
  useEffect(() => {
    scene.fog = new THREE.FogExp2(0x000000, mars ? 0.0028 : 0);
    if (sun.current) scene.add(sun.current.target);
    return () => { scene.fog = null; };
  }, [scene, mars]);

  useFrame(({ clock }) => {
    const env = engine.env, storm = engine.stormIntensity();
    const sd = new THREE.Vector3(...env.sunDir);
    const target = controls ? controls.target : new THREE.Vector3();
    sky.current.position.copy(camera.position);
    if (stars.current) stars.current.position.copy(camera.position);
    sun.current.position.copy(sd).multiplyScalar(120).add(target);
    sun.current.target.position.copy(target);
    sunSprite.current.position.copy(sd).multiplyScalar(1350).add(camera.position);
    uniforms.sunDir.value.copy(sd);
    const sinEl = Math.sin(env.el), day = env.day;
    if (mars) {
      const low = 1 - smooth(0.05, 0.5, Math.sin(Math.max(env.el, 0)));
      uniforms.topColor.value.copy(C.nightTop).lerp(C.tmp.copy(C.dayTop).lerp(C.stormTop, storm * 0.6), day);
      uniforms.horizonColor.value.copy(C.nightHor).lerp(C.tmp2.copy(C.dayHor).lerp(C.stormHor, storm * 0.5), day);
      uniforms.glowColor.value.set(0xffe2b8).lerp(C.blue, low); // blue Martian sunsets
      uniforms.glowStrength.value = (0.5 + low * 1.3) * smooth(-0.15, 0.05, sinEl) * (1 - storm * 0.7);
      scene.fog.color.copy(uniforms.horizonColor.value);
      scene.fog.density = 0.0022 + storm * 0.016;
      if (stars.current) stars.current.visible = day < 0.45 && storm < 0.5;
      sun.current.color.copy(C.warm).lerp(C.red, low);
      sun.current.intensity = 2.6 * day * (1 - storm * 0.75);
      if (fill.current) fill.current.intensity = 0.35 * day * (1 - storm * 0.5);
      hemi.current.color.set(0xe8b890); hemi.current.groundColor.set(0x5a2a18);
      hemi.current.intensity = 0.3 + 0.6 * day * (1 - storm * 0.3);
      amb.current.color.set(0x6a7ab0); amb.current.intensity = 0.4 * (1 - day) + 0.06;
      sunSprite.current.material.opacity = (1 - storm * 0.8) * smooth(-0.1, 0.05, sinEl);
      gl.toneMappingExposure = 1.0 + (1 - day) * 0.5;
      const t = engine.t;
      const a1 = t * Math.PI * 2 * 3.2, a2 = t * Math.PI * 2 * 0.8 + 1;
      phobos.current.position.set(Math.cos(a1) * 900, 300 + Math.sin(a1) * 250, Math.sin(a1) * 500);
      deimos.current.position.set(Math.cos(a2) * 1000, 420 + Math.sin(a2) * 200, Math.sin(a2) * 700);
    } else {
      uniforms.topColor.value.set(0x000000); uniforms.horizonColor.value.set(0x020203);
      uniforms.glowColor.value.set(0xffffff); uniforms.glowStrength.value = 0.05 * day;
      sun.current.color.set(0xfff8ee);
      sun.current.intensity = 3.6 * day;
      hemi.current.color.set(0x9aa4b4); hemi.current.groundColor.set(0x202020);
      hemi.current.intensity = 0.12 + 0.25 * day;
      amb.current.color.set(0x9db4e6); amb.current.intensity = 0.3 + (1 - day) * 0.3; // earthshine
      sunSprite.current.material.opacity = smooth(-0.05, 0.03, sinEl);
      gl.toneMappingExposure = 1.05 + (1 - day) * 0.35;
      if (earth.current) earth.current.rotation.y = clock.elapsedTime * 0.05;
    }
  });

  return (
    <>
      <mesh ref={sky} renderOrder={-10} frustumCulled={false}>
        <sphereGeometry args={[1500, 32, 16]} />
        <shaderMaterial uniforms={uniforms} vertexShader={skyVert} fragmentShader={skyFrag} side={THREE.BackSide} depthWrite={false} fog={false} />
      </mesh>
      <group ref={stars}><Stars radius={900} depth={300} count={Math.round((mars ? 3000 : 5000) * (gfx.stars === 1 ? 1 : 0.4))} factor={mars ? 14 : 18} saturation={0.3} fade speed={0.3} /></group>
      <sprite ref={sunSprite} scale={mars ? 110 : 70}>
        <spriteMaterial map={tex.glow} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} transparent />
      </sprite>
      <directionalLight ref={sun} castShadow intensity={3}
        shadow-mapSize={[isMobile() ? 1024 : gfx.shadowMap, isMobile() ? 1024 : gfx.shadowMap]} shadow-bias={-0.0006} shadow-normalBias={0.04}
        shadow-camera-left={-36} shadow-camera-right={36} shadow-camera-top={36} shadow-camera-bottom={-36} shadow-camera-near={1} shadow-camera-far={260} />
      <hemisphereLight ref={hemi} intensity={0.6} />
      {/* fill light: Mars = warm sky bounce opposite the Sun; Moon = blue Earthshine from Earth's direction */}
      <directionalLight ref={fill} position={mars ? [-40, 30, -30] : EARTH_POS} intensity={mars ? 0.35 : 0.3} color={mars ? '#ffc49a' : '#9fc4ff'} />
      <ambientLight ref={amb} intensity={0.2} />
      {mars ? (
        <>
          <mesh ref={phobos} scale={[1.3, 1, 1]}><dodecahedronGeometry args={[9, 1]} /><meshStandardMaterial color="#8a7a6a" roughness={1} flatShading /></mesh>
          <mesh ref={deimos}><dodecahedronGeometry args={[4, 1]} /><meshStandardMaterial color="#8a7a6a" roughness={1} flatShading /></mesh>
        </>
      ) : (
        <mesh ref={earth} position={EARTH_POS} rotation={[0, 0, 0.4]}>
          <sphereGeometry args={[26, 48, 32]} />
          <meshStandardMaterial map={tex.earth} roughness={0.6} emissive="#0a1630" emissiveIntensity={0.5} fog={false} />
        </mesh>
      )}
    </>
  );
}

// ---------- ground: terrain, rocks, pad, ice ----------
function Ground({ engine, land, mobile, gfx }) {
  const planetId = engine.planet.id;
  const geo = useMemo(() => terrainGeometry(planetId, land, mobile), [planetId, land, mobile]);
  const rocks = useRef();
  const N = mobile ? 260 : 420;
  useLayoutEffect(() => {
    const rng = land.rng, m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), p = new THREE.Vector3();
    for (let k = 0; k < N; k++) {
      const a = rng() * Math.PI * 2, d = 34 + rng() ** 1.4 * 230;
      const x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (Math.hypot(x - LANDING_PAD[0], z - LANDING_PAD[2]) < 6) { m4.makeScale(0, 0, 0); rocks.current.setMatrixAt(k, m4); continue; }
      const sc = 0.25 + rng() ** 3 * 3.2;
      p.set(x, land.height(x, z) + sc * 0.2, z);
      e.set(rng() * 3, rng() * 3, rng() * 3); q.setFromEuler(e);
      s.set(sc * (0.8 + rng() * 0.6), sc * (0.5 + rng() * 0.4), sc * (0.8 + rng() * 0.6));
      m4.compose(p, q, s); rocks.current.setMatrixAt(k, m4);
    }
    rocks.current.instanceMatrix.needsUpdate = true;
  }, [land, N]);
  const ice = useMemo(() => iceTex(), []);
  const pebbles = useMemo(() => {
    // small pebbles scattered between tiles for texture
    const out = [];
    for (let k = 0; k < 60; k++) { const x = (hash2(k, 1) - 0.5) * 60, z = (hash2(k, 2) - 0.5) * 60; out.push([x, z, 0.06 + hash2(k, 3) * 0.12]); }
    return out;
  }, []);
  const mars = planetId === 'mars';
  return (
    <>
      <mesh geometry={geo} receiveShadow><meshStandardMaterial vertexColors roughness={0.97} metalness={0} /></mesh>
      <instancedMesh ref={rocks} args={[null, null, N]} castShadow receiveShadow>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color={mars ? '#6b3a26' : '#6d6d6a'} roughness={0.95} flatShading />
      </instancedMesh>
      {pebbles.map(([x, z, s], k) => <mesh key={k} position={[x, s * 0.4, z]} scale={s} castShadow><dodecahedronGeometry args={[1, 0]} /><meshStandardMaterial color={mars ? '#7a4129' : '#77776f'} flatShading /></mesh>)}
      {/* landing pad */}
      <group position={LANDING_PAD}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]} receiveShadow><circleGeometry args={[4.2, 40]} /><meshStandardMaterial color={mars ? '#6a3c28' : '#5d5d5b'} roughness={0.9} /></mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]}><ringGeometry args={[3.4, 3.7, 40]} /><meshBasicMaterial color="#ffd23f" transparent opacity={0.7} /></mesh>
        <mesh rotation={[-Math.PI / 2, 0, Math.PI / 4]} position={[0, 0.05, 0]}><ringGeometry args={[1.0, 1.3, 4, 1]} /><meshBasicMaterial color="#ffd23f" transparent opacity={0.7} /></mesh>
      </group>
      {/* ice deposits */}
      {engine.iceTiles.map(([i, j]) => {
        const [x, , z] = tileToWorld(i, j);
        return (
          <group key={`${i},${j}`} position={[x, 0, z]}>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]} receiveShadow><planeGeometry args={[TILE * 0.94, TILE * 0.94]} /><meshStandardMaterial map={ice} roughness={0.25} metalness={0.1} emissive="#16324a" emissiveIntensity={0.6} /></mesh>
            {[0, 1, 2].map((k) => <mesh key={k} position={[(hash2(i * 7 + k, j) - 0.5) * 2.2, 0.12, (hash2(i, j * 5 + k) - 0.5) * 2.2]} rotation={[k, k * 2, 0]}><octahedronGeometry args={[0.15 + hash2(i + k, j) * 0.2, 0]} /><meshStandardMaterial color="#e8f6ff" roughness={0.1} metalness={0.2} emissive="#1a3a55" /></mesh>)}
          </group>
        );
      })}
      {gfx.sparkles && <IceSparkles engine={engine} />}
    </>
  );
}

function IceSparkles({ engine }) {
  const xs = engine.iceTiles.map(([i, j]) => tileToWorld(i, j));
  const cx = xs.reduce((a, p) => a + p[0], 0) / xs.length, cz = xs.reduce((a, p) => a + p[2], 0) / xs.length;
  return <Sparkles position={[cx, 0.8, cz]} count={40} scale={[12, 1.5, 12]} size={3} speed={0.3} color="#bfe8ff" opacity={0.8} />;
}

function BuildGrid({ engine }) {
  const on = !!engine.ui.buildType;
  return (
    <Grid position={[0, 0.035, 0]} args={[GRID * TILE, GRID * TILE]} cellSize={TILE} cellThickness={on ? 1.1 : 0.6}
      cellColor={on ? '#ffffff' : '#c8c8c8'} sectionSize={GRID * TILE} sectionThickness={0} sectionColor={engine.planet.accent}
      fadeDistance={on ? 400 : 140} fadeStrength={1} infiniteGrid={false} />
  );
}

// ---------- input ----------
function tileAt(point) {
  const i = Math.floor((point.x + HALF) / TILE), j = Math.floor((point.z + HALF) / TILE);
  return i >= 0 && j >= 0 && i < GRID && j < GRID ? [i, j] : null;
}
function tapTile(engine, tile, pointerType) {
  if (!tile) return;
  if (engine.ui.buildType) {
    const g = engine.ui.ghost;
    const same = g && g[0] === tile[0] && g[1] === tile[1];
    if (pointerType === 'mouse' || same) engine.place(tile[0], tile[1]);
    else { Sound.click(); engine.setGhost(tile); }
    return;
  }
  const id = engine.occ[tile[0]][tile[1]];
  if (id != null) Sound.click();
  engine.select(id);
}

function InteractionPlane({ engine }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}
      onPointerMove={(e) => { if (engine.ui.buildType && e.pointerType === 'mouse') engine.setGhost(tileAt(e.point)); }}
      onClick={(e) => { if (e.delta > 8) return; e.stopPropagation(); tapTile(engine, tileAt(e.point), e.pointerType); }}>
      <planeGeometry args={[GRID * TILE, GRID * TILE]} />
      <meshBasicMaterial visible={false} />
    </mesh>
  );
}

// ---------- buildings ----------
const ICONS = { power: ['⚡', '#e67e22'], damage: ['🔧', '#e74c3c'], off: ['⏸', '#7f8c8d'], water: ['💧', '#2e86de'] };
const iconCache = {};
function iconTex(kind) {
  if (!iconCache[kind]) {
    const [emoji, bg] = ICONS[kind];
    iconCache[kind] = canvasTex(96, 96, (g) => {
      g.fillStyle = bg; g.beginPath(); g.arc(48, 48, 44, 0, 7); g.fill();
      g.strokeStyle = 'rgba(255,255,255,0.95)'; g.lineWidth = 5; g.stroke();
      g.font = '48px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
      g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff'; g.fillText(emoji, 48, 52);
    });
  }
  return iconCache[kind];
}

function Building({ b, engine }) {
  const outer = useRef(), inner = useRef(), icon = useRef(), prog = useRef(), iconKind = useRef(null);
  const pos = engine.worldPos(b);
  const planetId = engine.planet.id;
  useLayoutEffect(() => { inner.current.traverse((o) => { if (o.isMesh && o.material && !o.material.transparent) { o.castShadow = true; o.receiveShadow = true; } }); }, []);
  useFrame(() => {
    if (!inner.current) return;
    if (!b.built) {
      inner.current.scale.set(1, Math.max(0.02, b.progress), 1);
      if (prog.current) { const f = Math.max(0.02, b.progress); prog.current.scale.x = f; prog.current.position.x = -0.85 * (1 - f); }
    }
    else {
      const k = (performance.now() - b.popAt) / 400;
      const s = k < 1 ? 1 + Math.sin(k * Math.PI) * 0.12 : 1;
      inner.current.scale.set(s, s, s);
    }
    // status icon
    let kind = null;
    if (b.built && b.type !== 'lander') {
      const consumer = BUILDINGS[b.type] && BUILDINGS[b.type].power < 0;
      if (b.cond < 60) kind = 'damage';
      else if (!b.on) kind = 'off';
      else if ((consumer && engine.stats.ratio < 0.95) || (b.type === 'habitat' && engine.stats.habRatio < 0.95)) kind = 'power';
      else if (b.type === 'oxygen' && engine.stats.flags.o2WaterShort) kind = 'water';
    }
    const sp = icon.current;
    if (sp) {
      if (iconKind.current !== kind) { iconKind.current = kind; sp.visible = !!kind; if (kind) { sp.material.map = iconTex(kind); sp.material.needsUpdate = true; } }
      if (kind) sp.position.y = (b.type === 'habitat' ? 5.4 : 4.4) + Math.sin(performance.now() / 300) * 0.12;
    }
  });
  const onClick = (e) => {
    if (e.delta > 8) return;
    // In build mode let the click pass through to the ground, so the tile under the cursor is used
    // (a tall building in front of a free tile must not block placing there).
    if (engine.ui.buildType) return;
    e.stopPropagation();
    Sound.click(); engine.select(b.id);
  };
  return (
    <group ref={outer} position={pos} onClick={onClick}
      onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = 'pointer'; }}
      onPointerOut={() => { document.body.style.cursor = ''; }}>
      <group ref={inner}><Model type={b.type} b={b} engine={engine} planetId={planetId} /></group>
      {!b.built && (
        <mesh position={[0, 1.5, 0]}>
          <boxGeometry args={[TILE * 0.85, 3, TILE * 0.85, 2, 3, 2]} />
          <meshBasicMaterial transparent opacity={0.04} color="#ffc23d" depthWrite={false} />
          <Edges color="#ffc23d" />
        </mesh>
      )}
      {!b.built && (
        <Billboard position={[0, 3.6, 0]}>
          <mesh renderOrder={20}><planeGeometry args={[1.9, 0.26]} /><meshBasicMaterial color="#000000" transparent opacity={0.65} depthTest={false} /></mesh>
          <mesh ref={prog} renderOrder={21} position={[0, 0, 0.01]}><planeGeometry args={[1.7, 0.14]} /><meshBasicMaterial color="#ffc23d" depthTest={false} transparent /></mesh>
        </Billboard>
      )}
      <sprite ref={icon} visible={false} scale={1.3} position={[0, 4.4, 0]} renderOrder={22}>
        <spriteMaterial depthTest={false} transparent />
      </sprite>
    </group>
  );
}


function Ghost({ engine }) {
  const { buildType, ghost } = engine.ui;
  const valid = buildType && ghost ? engine.canPlace(buildType, ghost[0], ghost[1]).ok : false;
  const mat = useMemo(() => new THREE.MeshStandardMaterial({ color: 0x3dff8a, transparent: true, opacity: 0.45, emissive: 0x0c4024, depthWrite: false }), []);
  const mats = useMemo(() => ghostMats(mat), [mat]);
  useFrame(({ clock }) => { mat.opacity = 0.35 + Math.sin(clock.elapsedTime * 6) * 0.1; });
  useEffect(() => { mat.color.set(valid ? 0x3dff8a : 0xff4d4d); mat.emissive.set(valid ? 0x0c4024 : 0x400c0c); }, [valid, mat]);
  if (!buildType) return null;
  const danger = buildType === 'reactor';
  const dangerSize = (HAB.i1 - HAB.i0 + 1 + 6) * TILE;
  return (
    <>
      {danger && <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.06, 0]}><planeGeometry args={[dangerSize, dangerSize]} /><meshBasicMaterial color="#ff3b3b" transparent opacity={0.16} depthWrite={false} /></mesh>}
      {ghost && (
        <group position={tileToWorld(ghost[0], ghost[1])}>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.07, 0]}><planeGeometry args={[TILE * 0.96, TILE * 0.96]} /><meshBasicMaterial color={valid ? '#3dff8a' : '#ff4d4d'} transparent opacity={0.35} depthWrite={false} /></mesh>
          <MatCtx.Provider value={mats}><Model type={buildType} planetId={engine.planet.id} /></MatCtx.Provider>
        </group>
      )}
    </>
  );
}

function SelectRing({ engine }) {
  const ref = useRef();
  const b = engine.ui.selected != null ? engine.buildings.get(engine.ui.selected) : null;
  useFrame(({ clock }) => { if (ref.current) ref.current.material.opacity = 0.6 + Math.sin(clock.elapsedTime * 5) * 0.3; });
  if (!b) return null;
  const p = engine.worldPos(b);
  const r = b.size === 2 ? 3.6 : 1.75;
  return <mesh ref={ref} rotation={[-Math.PI / 2, 0, 0]} position={[p[0], 0.08, p[2]]}><ringGeometry args={[r, r + 0.22, 48]} /><meshBasicMaterial color="#5ad1ff" transparent depthWrite={false} /></mesh>;
}

// ---------- astronauts (hop height depends on gravity) ----------
function Astronaut({ color, innerRef }) {
  const legs = [useRef(), useRef()];
  innerRef.legs = legs;
  return (
    <group ref={(g) => { innerRef.mesh = g; }} scale={1.15}>
      <mesh position={[0, 0.5, 0]} castShadow><capsuleGeometry args={[0.24, 0.4, 4, 12]} /><meshStandardMaterial color="#f4f4f0" roughness={0.75} /></mesh>
      <mesh position={[0, 1.0, 0]} castShadow><sphereGeometry args={[0.22, 16, 12]} /><meshStandardMaterial color="#f4f4f0" roughness={0.75} /></mesh>
      <mesh position={[0, 1.0, 0.06]}><sphereGeometry args={[0.18, 16, 10, -Math.PI / 2.4, Math.PI / 1.2, Math.PI / 4, Math.PI / 2.4]} /><meshStandardMaterial color="#ffb300" roughness={0.1} metalness={1} emissive="#331a00" /></mesh>
      <mesh position={[0, 0.62, -0.25]} castShadow><boxGeometry args={[0.36, 0.42, 0.18]} /><meshStandardMaterial color="#f4f4f0" roughness={0.75} /></mesh>
      <mesh position={[0, 0.6, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[0.25, 0.04, 6, 16]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.25} /></mesh>
      <mesh ref={legs[0]} position={[-0.1, 0.18, 0]} castShadow><capsuleGeometry args={[0.09, 0.22, 4, 8]} /><meshStandardMaterial color="#f4f4f0" roughness={0.75} /></mesh>
      <mesh ref={legs[1]} position={[0.1, 0.18, 0]} castShadow><capsuleGeometry args={[0.09, 0.22, 4, 8]} /><meshStandardMaterial color="#f4f4f0" roughness={0.75} /></mesh>
    </group>
  );
}

function Astronauts({ engine }) {
  const state = useMemo(() => engine.crew.map((c, k) => ({ target: new THREE.Vector3(), phase: k, wait: k * 0.8, inside: false, placed: false })), [engine]);
  const refs = useMemo(() => engine.crew.map(() => ({})), [engine]);
  const homeDoor = useMemo(() => new THREE.Vector3(0, 0, 3.6), []);
  useFrame((_, dtRaw) => {
    const running = engine.speed > 0 && !engine.over;
    const dt = running ? Math.min(dtRaw, 0.1) * Math.min(engine.speed, 2) : 0;
    const g = engine.planet.gravity;
    const hop = 0.085 * (9.81 / g), omega = 7.5 * Math.sqrt(g / 9.81), speed = engine.planet.id === 'moon' ? 1.7 : 2.1;
    const outsideOK = !engine.spe && engine.env.day > 0.35 && engine.stormIntensity() < 0.5 && !engine.over;
    const targets = [];
    engine.buildings.forEach((b) => { if (b.built && b.type !== 'shield') { const p = engine.worldPos(b); targets.push(p); } });
    engine.crew.forEach((c, k) => {
      const a = state[k], m = refs[k].mesh; if (!m) return;
      if (!a.placed) { m.position.set((k - 1.5) * 0.9, 0, homeDoor.z + 0.6); a.target.copy(m.position); a.placed = true; }
      if (c.status !== 'active') { m.visible = false; return; }
      if (!outsideOK) {
        if (a.inside) { m.visible = false; return; }
        a.target.copy(homeDoor);
      } else if (a.inside) { a.inside = false; m.position.copy(homeDoor); a.wait = Math.random() * 2; a.target.copy(homeDoor); }
      m.visible = true;
      const to = a.target.clone().sub(m.position); to.y = 0;
      const d = to.length();
      if (d > 0.15) {
        to.normalize();
        m.position.addScaledVector(to, Math.min(d, speed * dt));
        a.phase += dt * omega;
        m.position.y = Math.abs(Math.sin(a.phase)) * hop;
        const yaw = Math.atan2(to.x, to.z);
        m.rotation.y += (((yaw - m.rotation.y + Math.PI * 3) % (Math.PI * 2)) - Math.PI) * Math.min(1, dt * 8);
        const L = refs[k].legs; if (L[0].current) { L[0].current.rotation.x = Math.sin(a.phase * 2) * 0.4; L[1].current.rotation.x = -L[0].current.rotation.x; }
      } else {
        m.position.y = Math.max(0, m.position.y - dt * 2);
        if (!outsideOK) { a.inside = true; m.visible = false; return; }
        a.wait -= dt;
        if (a.wait <= 0 && targets.length) {
          const t = targets[Math.floor(Math.random() * targets.length)];
          const ang = Math.random() * Math.PI * 2, r = 2.3;
          a.target.set(t[0] + Math.cos(ang) * r, 0, t[2] + Math.sin(ang) * r);
          a.wait = 1.5 + Math.random() * 3.5;
        }
      }
    });
  });
  return <>{engine.crew.map((c, k) => <Astronaut key={k} color={c.color} innerRef={refs[k]} />)}</>;
}

// ---------- weather & effects ----------
function DustStorm({ engine, mobile }) {
  const pts = useRef();
  const N = mobile ? 1200 : 2400;
  const { positions, tex } = useMemo(() => {
    const p = new Float32Array(N * 3);
    for (let k = 0; k < N; k++) { p[k * 3] = (Math.random() - 0.5) * 160; p[k * 3 + 1] = Math.random() * 30; p[k * 3 + 2] = (Math.random() - 0.5) * 160; }
    return { positions: p, tex: glowTex('rgba(255,255,255,1)', 'rgba(255,255,255,0)') };
  }, [N]);
  const { controls } = useThree();
  useFrame(({ clock }, dt) => {
    const moon = engine.planet.id === 'moon';
    const s = moon ? engine.lunarDust() : engine.stormIntensity();
    const P = pts.current; if (!P) return;
    P.visible = s > 0.01; P.material.opacity = Math.min(0.75, s * 0.85);
    if (moon) P.material.color.set('#9a9a96');
    if (!P.visible) return;
    const arr = P.geometry.attributes.position.array; const c = controls ? controls.target : { x: 0, z: 0 };
    const now = clock.elapsedTime;
    for (let k = 0; k < arr.length; k += 3) {
      if (moon) { arr[k] += Math.sin(now * 0.7 + k) * dt * 2; arr[k + 1] = Math.max(0.1, arr[k + 1] - dt * 1.5); if (arr[k + 1] <= 0.1) arr[k + 1] = 6 * Math.random(); } // no wind: dust floats and settles
      else { arr[k] += dt * (14 + (k % 7)); arr[k + 2] += dt * 4; arr[k + 1] += Math.sin(now + k) * dt * 0.5; }
      if (arr[k] > c.x + 80) arr[k] -= 160; if (arr[k + 2] > c.z + 80) arr[k + 2] -= 160;
    }
    P.geometry.attributes.position.needsUpdate = true;
  });
  return (
    <points ref={pts} frustumCulled={false} visible={false}>
      <bufferGeometry><bufferAttribute attach="attributes-position" args={[positions, 3]} /></bufferGeometry>
      <pointsMaterial color="#d09a6a" size={1.1} map={tex} transparent opacity={0} depthWrite={false} />
    </points>
  );
}

function Effect({ e, engine }) {
  if (e.kind === 'burst') return <Burst e={e} engine={engine} />;
  if (e.kind === 'meteor') return <Meteor e={e} engine={engine} />;
  if (e.kind === 'lander') return <Lander e={e} engine={engine} />;
  return null;
}

const dotTex = { t: null, get() { if (!this.t) this.t = glowTex('rgba(255,255,255,1)', 'rgba(255,255,255,0)'); return this.t; } };

function Burst({ e, engine, n = 40 }) {
  const pts = useRef();
  const { pos, vel } = useMemo(() => {
    const p = new Float32Array(n * 3), v = [];
    for (let k = 0; k < n; k++) { p[k * 3] = e.pos[0]; p[k * 3 + 1] = 1; p[k * 3 + 2] = e.pos[2]; v.push([(Math.random() - 0.5) * 6, 2 + Math.random() * 5, (Math.random() - 0.5) * 6]); }
    return { pos: p, vel: v };
  }, [e, n]);
  useFrame((_, dt) => {
    const age = (performance.now() - e.born) / 1000;
    if (age > 1.6) { engine.removeEffect(e.id); return; }
    const g = engine.planet.gravity, arr = pts.current.geometry.attributes.position.array;
    for (let k = 0; k < n; k++) { vel[k][1] -= g * dt; arr[k * 3] += vel[k][0] * dt; arr[k * 3 + 1] = Math.max(0.05, arr[k * 3 + 1] + vel[k][1] * dt); arr[k * 3 + 2] += vel[k][2] * dt; }
    pts.current.geometry.attributes.position.needsUpdate = true;
    pts.current.material.opacity = 1 - age / 1.6;
  });
  return (
    <points ref={pts} frustumCulled={false}>
      <bufferGeometry><bufferAttribute attach="attributes-position" args={[pos, 3]} /></bufferGeometry>
      <pointsMaterial color={e.color || '#3dff8a'} size={0.6} map={dotTex.get()} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

function Meteor({ e, engine }) {
  const head = useRef(), light = useRef(), ring = useRef(), line = useRef();
  const target = useMemo(() => new THREE.Vector3(e.pos[0], 1.5, e.pos[2]), [e]);
  const start = useMemo(() => target.clone().add(new THREE.Vector3(60, 90, -40)), [target]);
  const geo = useMemo(() => new THREE.BufferGeometry().setFromPoints([start, start]), [start]);
  const done = useRef(false);
  useFrame(() => {
    const age = (performance.now() - e.born) / 1000, dur = 0.9;
    const k = Math.min(1, age / dur);
    const p = start.clone().lerp(target, k);
    head.current.position.copy(p);
    geo.setFromPoints([start.clone().lerp(target, Math.max(0, k - 0.25)), p]);
    if (k >= 1 && !done.current) { done.current = true; head.current.visible = false; line.current.visible = false; e.onDone && e.onDone(); engine.addEffect('burst', e.pos, { color: '#ffa040' }); }
    if (done.current) {
      const f = Math.max(0, 1 - (age - dur) / 0.8);
      light.current.intensity = 60 * f; ring.current.scale.setScalar(1 + (1 - f) * 14); ring.current.material.opacity = f;
      if (age > dur + 1) engine.removeEffect(e.id);
    }
  });
  return (
    <>
      <mesh ref={head}><sphereGeometry args={[0.5, 8, 6]} /><meshBasicMaterial color="#ffe0a0" /></mesh>
      <line ref={line} geometry={geo}><lineBasicMaterial color="#ffc070" /></line>
      <pointLight ref={light} position={[e.pos[0], 2, e.pos[2]]} color="#ffaa55" intensity={0} distance={30} decay={2} />
      <mesh ref={ring} rotation={[-Math.PI / 2, 0, 0]} position={[e.pos[0], 0.2, e.pos[2]]}><ringGeometry args={[0.2, 0.6, 32]} /><meshBasicMaterial color="#ffd090" transparent opacity={0} side={THREE.DoubleSide} depthWrite={false} /></mesh>
    </>
  );
}

function Lander({ e, engine }) {
  const g = useRef(), flame = useRef(), light = useRef();
  const landed = useRef(false);
  useFrame(() => {
    const age = (performance.now() - e.born) / 1000, dur = 5;
    if (age < dur) {
      const k = age / dur, ease = 1 - Math.pow(1 - k, 2.4);
      g.current.position.y = 70 * (1 - ease);
      flame.current.scale.set(1, 0.7 + Math.random() * 0.5, 1);
    } else if (!landed.current) {
      landed.current = true; g.current.position.y = 0; flame.current.visible = false; light.current.intensity = 0;
      e.onDone && e.onDone();
      engine.addEffect('burst', LANDING_PAD, { color: engine.planet.id === 'mars' ? '#d09a6a' : '#bbbbbb' });
    }
    if (age > 12) g.current.scale.setScalar(Math.max(0.01, 1 - (age - 12) / 1.5));
    if (age > 13.5) engine.removeEffect(e.id);
  });
  return (
    <group ref={g} position={[LANDING_PAD[0], 70, LANDING_PAD[2]]}>
      <CargoCraft />
      <mesh ref={flame} position={[0, -1.0, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.45, 2.6, 12, 1, true]} /><meshBasicMaterial color="#ffb35c" transparent opacity={0.85} blending={THREE.AdditiveBlending} depthWrite={false} /></mesh>
      <pointLight ref={light} position={[0, -0.5, 0]} color="#ffa860" intensity={40} distance={25} decay={2} />
    </group>
  );
}
