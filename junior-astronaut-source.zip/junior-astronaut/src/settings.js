// Player settings (saved in this browser) + procedural background music (Web Audio, no files).
import { Sound } from './bus.js';

const KEY = 'ja-settings';
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } };
const subs = new Set();

// quality: 'auto' picks 'low' on phones / small or low-core devices, otherwise 'high'
export const lowEnd = () => {
  const small = Math.min(window.innerWidth, window.innerHeight) < 700;
  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory || 8;
  return small || cores <= 4 || mem <= 4;
};

export const Settings = {
  sfx: true, music: true, musicVol: 0.35, quality: 'auto', tutorialDone: false, version: 0,
  ...load(),
  subscribe(fn) { subs.add(fn); return () => subs.delete(fn); },
  getVersion() { return Settings.version; },
  set(patch) {
    Object.assign(Settings, patch); Settings.version++;
    try { const { sfx, music, musicVol, quality, tutorialDone } = Settings; localStorage.setItem(KEY, JSON.stringify({ sfx, music, musicVol, quality, tutorialDone })); } catch (e) { /* storage may be unavailable */ }
    Sound.on = Settings.sfx;
    if ('music' in patch || 'musicVol' in patch) Music.sync();
    subs.forEach((f) => f());
  },
  // resolved graphics preset
  gfx() {
    const q = Settings.quality === 'auto' ? (lowEnd() ? 'low' : 'high') : Settings.quality;
    return q === 'low'
      ? { name: 'low', dpr: [0.8, 1.25], shadows: true, shadowMap: 1024, stars: 1500, particles: 0.5, sparkles: false, antialias: false }
      : { name: 'high', dpr: [1, 2], shadows: true, shadowMap: 2048, stars: 1, particles: 1, sparkles: true, antialias: true };
  },
};
Sound.on = Settings.sfx;

// ---------- ambient music: slow pad chords + a sparse bell melody, all synthesised ----------
const CHORDS = { // root-position voicings (Hz) — calm, spacey progression
  mars: [[110, 164.8, 220, 261.6, 329.6], [87.3, 130.8, 174.6, 220, 261.6], [98, 146.8, 196, 246.9, 293.7], [82.4, 123.5, 164.8, 196, 246.9]],
  moon: [[98, 146.8, 196, 233.1, 293.7], [77.8, 116.5, 155.6, 196, 233.1], [87.3, 130.8, 174.6, 220, 261.6], [73.4, 110, 146.8, 174.6, 220]],
};
export const Music = {
  playing: false, mood: 'mars', node: null, timer: null, step: 0,
  setMood(m) { this.mood = m === 'moon' ? 'moon' : 'mars'; },
  // called on any user gesture so browsers allow audio
  unlock() { Sound.init(); this.sync(); },
  sync() {
    const want = Settings.music && Sound.ctx && Sound.ctx.state !== 'closed';
    if (want && !this.playing) this.start();
    else if (!want && this.playing) this.stop();
    if (this.node) { try { this.node.gain.setTargetAtTime(Settings.musicVol * 0.22, Sound.ctx.currentTime, 0.4); } catch (e) { /* ignore */ } }
  },
  start() {
    const ctx = Sound.ctx; if (!ctx) return;
    try {
      const master = ctx.createGain(); master.gain.value = 0;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1100; lp.Q.value = 0.4;
      const delay = ctx.createDelay(2); delay.delayTime.value = 0.55;
      const fb = ctx.createGain(); fb.gain.value = 0.35;
      lp.connect(master); lp.connect(delay); delay.connect(fb); fb.connect(delay); delay.connect(master);
      master.connect(ctx.destination);
      master.gain.setTargetAtTime(Settings.musicVol * 0.22, ctx.currentTime, 1.5);
      this.node = master; this.bus = lp; this.playing = true; this.step = 0;
      const tick = () => this.chord();
      tick(); this.timer = setInterval(tick, 8000);
    } catch (e) { this.playing = false; }
  },
  stop() {
    clearInterval(this.timer); this.timer = null; this.playing = false;
    const n = this.node, ctx = Sound.ctx; this.node = null;
    if (n && ctx) { try { n.gain.setTargetAtTime(0, ctx.currentTime, 0.5); setTimeout(() => n.disconnect(), 3000); } catch (e) { /* ignore */ } }
  },
  chord() {
    const ctx = Sound.ctx; if (!ctx || !this.bus) return;
    const ch = CHORDS[this.mood][this.step++ % 4], t = ctx.currentTime;
    ch.forEach((f, k) => {
      [0, 3].forEach((det) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = k === 0 ? 'sine' : 'triangle'; o.frequency.value = f; o.detune.value = det ? 6 : -4;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(k === 0 ? 0.16 : 0.07, t + 3); g.gain.linearRampToValueAtTime(0.0001, t + 9.5);
        o.connect(g).connect(this.bus); o.start(t); o.stop(t + 10);
      });
    });
    // two soft bell notes from the chord, an octave up
    [1.5, 4.5].forEach((d) => {
      if (Math.random() < 0.35) return;
      const f = ch[1 + Math.floor(Math.random() * 4)] * 4, o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0, t + d); g.gain.linearRampToValueAtTime(0.035, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 2.5);
      o.connect(g).connect(this.bus); o.start(t + d); o.stop(t + d + 2.6);
    });
  },
};
