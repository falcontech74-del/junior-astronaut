// Safety net for the loading screen: the app removes #loading itself when the 3D scene is ready.
// If that never happens (e.g. an unexpected error), hide the loader 4 s after the page has loaded
// so the player is never stuck on a spinner.
window.addEventListener('load', function () {
  setTimeout(function () {
    var l = document.getElementById('loading');
    if (l) { l.classList.add('done'); setTimeout(function () { if (l.parentNode) l.remove(); }, 600); }
  }, 4000);
});
