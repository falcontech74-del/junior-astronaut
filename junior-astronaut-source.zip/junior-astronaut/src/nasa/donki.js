// NASA CCMC DONKI (Space Weather Database Of Notifications, Knowledge, Information) integration.
// API docs: https://ccmc.gsfc.nasa.gov/DONKI/api/  (OpenAPI v2.0, server https://ccmc.gsfc.nasa.gov/DONKI-API)
// GET /get/FLR, /get/CME, /get/SEP with startDate / endDate (yyyy-MM-dd), at most a 60-day window per request.
// Only real DONKI records are used. If the live API cannot be reached, the game falls back to an archived
// snapshot of real DONKI records (donki-archive.js) and always labels it as archived, never as live.
import { DONKI_ARCHIVE } from './donki-archive.js';

export const DONKI_LINKS = {
  tool: 'https://ccmc.gsfc.nasa.gov/tools/DONKI/',
  app: 'https://ccmc.gsfc.nasa.gov/DONKI/',
  docs: 'https://ccmc.gsfc.nasa.gov/DONKI/api/',
  guide: 'https://ccmc.gsfc.nasa.gov/DONKI/guide/',
  api: 'https://ccmc.gsfc.nasa.gov/DONKI-API/get/',
};
const DAY = 864e5;
const ymd = (d) => d.toISOString().slice(0, 10);
export const queryUrl = (type, start, end) => `${DONKI_LINKS.api}${type}?startDate=${start}&endDate=${end}`;

// ---------- normalisers (keep only the fields the game shows) ----------
const ids = (x) => (x.linkedEvents || []).map((l) => l.activityID).filter(Boolean);
export const normFLR = (x) => ({ kind: 'FLR', id: x.flrID, begin: x.beginTime, time: x.peakTime || x.beginTime, cls: x.classType || null, loc: x.sourceLocation || null, ar: x.activeRegionNum || null, inst: (x.instruments || []).map((i) => i.displayName).join(', '), link: x.link, linked: ids(x) });
export const normCME = (x) => {
  const an = x.cmeAnalyses || [];
  const a = an.find((v) => v.isMostAccurate) || an[0] || null;
  return { kind: 'CME', id: x.activityID, time: x.startTime, speed: a && a.speed != null ? Math.round(a.speed) : null, halfAngle: a ? a.halfAngle : null, type: a ? a.type : null, loc: x.sourceLocation || null, link: x.link, linked: ids(x) };
};
export const normSEP = (x) => ({ kind: 'SEP', id: x.sepID, time: x.eventTime, inst: (x.instruments || []).map((i) => i.displayName).join(', '), link: x.link, linked: ids(x) });

// time encoded in a DONKI activity id, e.g. "2026-09-05T15:04:00-FLR-001"
export const idTime = (id) => { const m = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})/.exec(id || ''); return m ? m[1] + 'Z' : null; };
const ms = (t) => (t ? Date.parse(t) : NaN);

// strength of an SEP event, judged from which real detectors recorded it.
// The dose factor is a GAME rule (simulated), not a NASA measurement.
export const STRENGTH = {
  strong: { label: 'Strong', why: 'GOES recorded protons above 100 MeV', factor: 1.25 },
  moderate: { label: 'Moderate', why: 'GOES recorded protons above 10 MeV', factor: 1 },
  minor: { label: 'Minor', why: 'seen by deep-space probes or models only, not by GOES at Earth', factor: 0.8 },
};

// Group SEP detections that share the same parent flare / CME into one "solar storm".
export function clusterSEP(seps, flares, cmes) {
  const F = new Map(flares.map((f) => [f.id, f])), C = new Map(cmes.map((c) => [c.id, c]));
  // union-find: SEP detections that share any parent flare/CME belong to the same storm
  const up = new Map();
  const find = (a) => { while (up.get(a) !== a) { up.set(a, up.get(up.get(a))); a = up.get(a); } return a; };
  const join = (a, b) => { [a, b].forEach((x) => { if (!up.has(x)) up.set(x, x); }); up.set(find(a), find(b)); };
  const par = new Map(seps.map((s) => [s.id, s.linked.filter((i) => /-(FLR|CME)-/.test(i))]));
  for (const s of seps) { join(s.id, s.id); par.get(s.id).forEach((p) => join(s.id, p)); }
  const groups = new Map();
  for (const s of seps) {
    const key = find(s.id);
    if (!groups.has(key)) groups.set(key, { seps: [], parents: new Set() });
    const g = groups.get(key); g.seps.push(s); par.get(s.id).forEach((p) => g.parents.add(p));
  }
  const out = [];
  for (const g of groups.values()) {
    g.key = [...g.parents].sort()[0] || g.seps[0].id;
    g.seps.sort((a, b) => ms(a.time) - ms(b.time));
    const pl = [...g.parents].sort();
    const flrId = pl.find((p) => p.includes('-FLR-')), cmeId = pl.find((p) => p.includes('-CME-'));
    const fl = flrId ? (F.get(flrId) || { id: flrId, time: idTime(flrId), begin: idTime(flrId), cls: null, link: null }) : null;
    const cm = cmeId ? (C.get(cmeId) || { id: cmeId, time: idTime(cmeId), speed: null, link: null }) : null;
    const detectors = [...new Set(g.seps.map((s) => s.inst))];
    const goes100 = detectors.some((d) => /GOES/.test(d) && />100 MeV/.test(d));
    const goes10 = detectors.some((d) => /GOES/.test(d) && />10 MeV/.test(d));
    const strength = goes100 ? 'strong' : goes10 ? 'moderate' : 'minor';
    const first = g.seps[0];
    // first real instrument detection (REleASE "MODEL" entries are forecasts, not measurements)
    const firstObs = g.seps.find((s) => !/^MODEL/.test(s.inst)) || first;
    const startT = Math.min(...[fl && ms(fl.begin || fl.time), cm && ms(cm.time)].filter((v) => v > 0));
    const warnMin = Number.isFinite(startT) && ms(firstObs.time) >= startT ? Math.round((ms(firstObs.time) - startT) / 60000) : null;
    const src = g.seps.every((s) => s.src === 'live') ? 'live' : 'archived';
    out.push({ id: g.key, time: first.time, firstObs: firstObs.time, firstInst: firstObs.inst, seps: g.seps, detectors, strength, flare: fl, cme: cm, warnMin, src, link: firstObs.link });
  }
  return out.sort((a, b) => ms(b.time) - ms(a.time));
}

// ---------- store ----------
const listeners = new Set();
export const NasaData = {
  status: 'idle', // idle | loading | live | archived
  version: 0,
  data: null, // { mode, fetchedAt, flares, cmes, seps, clusters, queries, error, archivedAt }
  used: new Set(),
  subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  getVersion() { return NasaData.version; },
  _set(patch) { Object.assign(NasaData, patch); NasaData.version++; listeners.forEach((f) => f()); },
  // next real SEP storm for a radiation emergency (newest first, no repeats until all used)
  nextStorm() {
    const d = NasaData.data || archivedData('API not contacted yet');
    const pool = d.clusters;
    if (!pool.length) return null;
    let c = pool.find((x) => !NasaData.used.has(x.id));
    if (!c) { NasaData.used.clear(); c = pool[0]; }
    NasaData.used.add(c.id);
    return c;
  },
};

export function archivedData(reason) {
  const tag = (a) => a.map((x) => ({ ...x, src: 'archived' }));
  const flares = tag(DONKI_ARCHIVE.flares), cmes = tag(DONKI_ARCHIVE.cmes), seps = tag(DONKI_ARCHIVE.seps);
  return { mode: 'archived', error: reason, archivedAt: DONKI_ARCHIVE.retrievedAt, fetchedAt: null, flares, cmes, seps, clusters: clusterSEP(seps, flares, cmes), queries: DONKI_ARCHIVE.queries };
}

async function getJSON(type, start, end, signal, fetchFn) {
  const url = queryUrl(type, start, end);
  const r = await fetchFn(url, { signal, headers: { Accept: 'application/json' } });
  if (!r.ok) throw new Error(`${type}: HTTP ${r.status}`);
  const j = await r.json();
  if (!Array.isArray(j)) throw new Error(`${type}: unexpected response`);
  return { url, rows: j };
}

// Load real DONKI data. Never throws: on any failure it falls back to the archived snapshot.
export async function loadDonki({ now = new Date(), timeoutMs = 20000, fetchFn = (u, o) => fetch(u, o), lookbackWindows = 5 } = {}) {
  if (NasaData.status === 'loading') return NasaData.data;
  NasaData._set({ status: 'loading' });
  const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  let timer;
  const deadline = new Promise((_, reject) => { timer = setTimeout(() => { if (ctl) ctl.abort(); const e = new Error('timeout'); e.name = 'AbortError'; reject(e); }, timeoutMs); });
  try {
    return await Promise.race([deadline, liveLoad(now, ctl, fetchFn, lookbackWindows)]);
  } catch (err) {
    const reason = err && err.name === 'AbortError' ? `no answer within ${Math.round(timeoutMs / 1000)} s` : (err && err.message) || 'network error';
    const data = archivedData(reason);
    NasaData._set({ status: 'archived', data });
    return data;
  } finally { clearTimeout(timer); }
}

async function liveLoad(now, ctl, fetchFn, lookbackWindows) {
  {
    const end = ymd(now), start = ymd(new Date(now.getTime() - 59 * DAY));
    const [f, c, s] = await Promise.all(['FLR', 'CME', 'SEP'].map((t) => getJSON(t, start, end, ctl && ctl.signal, fetchFn)));
    const queries = [f.url, c.url, s.url];
    const live = (a) => a.map((x) => ({ ...x, src: 'live' }));
    const flares = live(f.rows.map(normFLR)), cmes = live(c.rows.map(normCME)), seps = live(s.rows.map(normSEP));
    const recentSeps = seps.length;
    // SEP events are rarer than flares: look further back (still live requests) to find real storms
    let e0 = new Date(now.getTime() - 60 * DAY);
    for (let k = 0; k < lookbackWindows && clusterSEP(seps, flares, cmes).length < 3; k++) {
      const s0 = new Date(e0.getTime() - 59 * DAY);
      const r = await getJSON('SEP', ymd(s0), ymd(e0), ctl && ctl.signal, fetchFn);
      queries.push(r.url);
      if (r.rows.length) {
        seps.push(...live(r.rows.map(normSEP)));
        // flare classes and CME speeds of the parents of those storms
        const want = new Set(r.rows.flatMap((x) => ids(x)));
        const [fr, cr] = await Promise.all(['FLR', 'CME'].map((t) => getJSON(t, ymd(s0), ymd(e0), ctl && ctl.signal, fetchFn)));
        queries.push(fr.url, cr.url);
        flares.push(...live(fr.rows.map(normFLR).filter((x) => want.has(x.id))));
        cmes.push(...live(cr.rows.map(normCME).filter((x) => want.has(x.id))));
      }
      e0 = new Date(s0.getTime() - DAY);
    }
    let clusters = clusterSEP(seps, flares, cmes);
    let note = null;
    if (!clusters.length) { clusters = archivedData('').clusters; note = 'No SEP events in the live search window, so radiation alerts use archived real NASA SEP records.'; }
    const data = { mode: 'live', fetchedAt: new Date().toISOString(), window: [start, end], recentSeps, flares, cmes, seps, clusters, queries, note, error: null };
    if (ctl && ctl.signal.aborted) throw Object.assign(new Error('timeout'), { name: 'AbortError' });
    NasaData._set({ status: 'live', data });
    return data;
  }
}

// readable UTC date/time
export const fmtUTC = (t, withTime = true) => {
  if (!t) return '—';
  const d = new Date(t); if (isNaN(d)) return t;
  const s = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
  return withTime ? `${s}, ${d.toISOString().slice(11, 16)} UTC` : s;
};
export const DONKI_ARCHIVE_DATE = DONKI_ARCHIVE.retrievedAt;
