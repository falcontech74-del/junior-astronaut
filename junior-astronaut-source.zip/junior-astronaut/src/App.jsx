import { useEffect, useLayoutEffect, useMemo, useReducer, useRef, useState, useSyncExternalStore } from 'react';
import { PLANETS, BUILDINGS, BUILD_ORDER, CODEX, MISSION_DAYS, DURATIONS, THREAT, threatLevel, TRADEOFFS, SCIENCE_TABLE, SECONDS_PER_DAY } from './data.js';
import { Engine, clamp, STORE_CAP } from './engine.js';
import { Modals as _M } from './bus.js';
import { Sound, Toasts, Modals } from './bus.js';
import World from './scene/World.jsx';
import * as Learning from './learning.js';
import * as Nasa from './nasa/donki.js';
import { Settings, Music } from './settings.js';
import { SettingsBody, openSettings, LaunchCurtain, Tutorial, DemoPanel, setupDemo, CreditsPanel } from './Extras.jsx';
const { NasaData, loadDonki, DONKI_LINKS, STRENGTH, fmtUTC } = Nasa;
const useNasa = () => useSyncExternalStore(NasaData.subscribe, NasaData.getVersion);
const { SYSTEMS, FACTS, GRADES, RANKS } = Learning;

const fmt = (v, d = 0) => (Math.round(v * 10 ** d) / 10 ** d).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
const useCompact = () => {
  const isC = () => window.innerWidth <= 900 || window.innerHeight <= 500;
  const [c, setC] = useState(isC());
  useEffect(() => { const f = () => setC(isC()); window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, []);
  return c;
};
const useTick = (ms) => { const [, f] = useReducer((x) => x + 1, 0); useEffect(() => { const id = setInterval(f, ms); return () => clearInterval(id); }, [ms]); };
const useEngine = (engine) => useSyncExternalStore(engine.subscribe, engine.getVersion);

// =================== App ===================
export default function App() {
  const [screen, setScreen] = useState({ name: 'title' });
  const [days, setDaysState] = useState(() => { try { const v = +localStorage.getItem('ja-days'); return [30, 60, 90].includes(v) ? v : MISSION_DAYS; } catch (e) { return MISSION_DAYS; } });
  const setDays = (d) => { setDaysState(d); try { localStorage.setItem('ja-days', String(d)); } catch (e) { /* storage may be unavailable */ } };
  const start = (planet, d = days, opts = {}) => { Modals.clear(); Toasts.clear(); setScreen({ name: 'game', planet, days: d, key: Date.now(), opts }); };
  const toTitle = () => { Modals.clear(); Toasts.clear(); setScreen({ name: 'title' }); };
  useEffect(() => { window.__ja = Object.assign(window.__ja || {}, { start, toTitle, Engine, Modals: _M, learning: Learning, nasa: Nasa, music: Music, settings: Settings }); });
  useEffect(() => { if (NasaData.status === 'idle') loadDonki(); }, []);
  // boot screen fades out once the app is on screen; music may only start after a user gesture
  useEffect(() => {
    const boot = document.getElementById('loading');
    if (boot) { boot.classList.add('done'); setTimeout(() => boot.remove(), 600); }
    const unlock = () => Music.unlock();
    window.addEventListener('pointerdown', unlock); window.addEventListener('keydown', unlock);
    return () => { window.removeEventListener('pointerdown', unlock); window.removeEventListener('keydown', unlock); };
  }, []); // real NASA DONKI space-weather data (falls back to archived records)
  useEffect(() => { document.body.dataset.planet = screen.planet || 'mars'; document.documentElement.style.setProperty('--accent', PLANETS[screen.planet || 'mars'].accent); }, [screen]);
  return (
    <>
      {screen.name === 'title' && <Title onLaunch={start} days={days} setDays={setDays} />}
      {screen.name === 'game' && <Game key={screen.key} planetId={screen.planet} days={screen.days} opts={screen.opts || {}} onRestart={start} onTitle={toTitle} />}
      <ModalHost />
    </>
  );
}

// =================== Title screen ===================
function Title({ onLaunch, days, setDays }) {
  const shadow = useMemo(() => Array.from({ length: 220 }, () => `${Math.random() * 100}vw ${Math.random() * 100}vh 0 ${Math.random() < 0.1 ? 1 : 0}px rgba(255,255,255,${0.3 + Math.random() * 0.7})`).join(','), []);
  return (
    <div id="title">
      <div id="starfield" style={{ boxShadow: shadow }} />
      <div className="t-wrap">
        <div className="logo">
          <div className="badge">3D SPACE COLONY SIMULATOR</div>
          <NasaBadge />
          <h1>JUNIOR<br />ASTRONAUT</h1>
          <p>Land a crew of four on another world. Build power, air, water and food systems from local resources, and keep everyone alive for 30, 60 or 90 days using real space science.</p>
        </div>
        <nav className="main-menu" id="main-menu" aria-label="Main menu">
          <button className="mm-btn primary" data-mm="play" onClick={() => { Sound.init(); Sound.click(); document.getElementById('dest').scrollIntoView({ behavior: 'smooth' }); }}>🚀 Start a mission</button>
          <button className="mm-btn" data-mm="tutorial" onClick={() => { Sound.init(); Sound.good(); onLaunch('mars', 30, { tutorial: true }); }}>🎓 Tutorial</button>
          <button className="mm-btn" data-mm="demo" onClick={() => { Sound.init(); Sound.good(); onLaunch('mars', 90, { demo: true }); }}>🎬 Demo mode</button>
          <button className="mm-btn" data-mm="sources" onClick={() => { Sound.init(); Sound.click(); openSources(); }}>🛰️ NASA data & credits</button>
          <button className="mm-btn" data-mm="settings" onClick={() => { Sound.init(); Sound.click(); openSettings(); }}>⚙️ Settings</button>
        </nav>
        <div className="mission-len">
          <div className="ml-title">MISSION LENGTH</div>
          <div className="ml-opts" role="radiogroup" aria-label="Mission length">
            {DURATIONS.map((d) => (
              <button key={d.days} role="radio" aria-checked={days === d.days} data-days={d.days} className={`ml-opt ${days === d.days ? 'on' : ''}`} onClick={() => { Sound.init(); Sound.click(); setDays(d.days); }}>
                <b>{d.days} Days</b><span>{d.label}</span>
              </button>
            ))}
          </div>
          <div className="ml-note">{DURATIONS.find((d) => d.days === days).note} About {Math.round(days * SECONDS_PER_DAY / 60)} min at 1× speed, {Math.round(days * SECONDS_PER_DAY / 60 / 8 * 10) / 10} min at 8×.</div>
        </div>
        <div id="dest">
          {['mars', 'moon'].map((id) => {
            const P = PLANETS[id];
            return (
              <div key={id} className={`dest ${id}`}>
                <div className={`globe ${id}`} />
                <div className="dest-body">
                  <h3>{P.name}</h3>
                  <div className="site">📍 {P.site}</div>
                  <table><tbody>{P.stats.map(([a, b]) => <tr key={a}><td>{a}</td><td>{b}</td></tr>)}</tbody></table>
                  <p className="chal">⚠ {P.challenge}</p>
                  <button className="btn primary launch" data-planet={id} onClick={() => { Sound.init(); Sound.good(); onLaunch(id, days); }}>
                    Launch to {id === 'mars' ? 'Mars' : 'the Moon'} · {days} days ▸
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="howto">
          <div><span>🏗️</span><b>Build</b>Pick a module from the bar and tap a tile. Every module runs on real physics and chemistry.</div>
          <div><span>⚖️</span><b>Balance</b>Watch oxygen, water, food and power. The chips warn you before anything runs out.</div>
          <div><span>⚠️</span><b>Survive</b>Dust storms, solar flares, meteorites, quakes and long freezing nights will test your base.</div>
          <div><span>📘</span><b>Learn</b>Unlock Science Codex entries and answer Mission Control challenges for bonus supplies.</div>
        </div>
        <div className="t-hb"><button className="btn" id="title-handbook" onClick={() => { Sound.init(); Sound.click(); openHandbook(); }}>📖 Mission Handbook: real science vs game rules</button></div>
        <div className="t-foot">Drag to orbit · pinch / scroll to zoom · two-finger drag or right-drag to pan · works on phones, tablets and computers</div>
      </div>
    </div>
  );
}

// =================== Game ===================
function Game({ planetId, days, opts, onRestart, onTitle }) {
  const engine = useMemo(() => { const e = new Engine(planetId, days); if (opts.demo) setupDemo(e); return e; }, [planetId, days]);
  const [ready, setReady] = useState(false);
  const [tut, setTut] = useState(false);
  useEffect(() => { Music.setMood(planetId); }, [planetId]);
  useEffect(() => { window.__ja.engine = engine; return () => { if (window.__ja && window.__ja.engine === engine) window.__ja.engine = null; }; }, [engine]);
  const openCodex = (key) => Modals.open({ icon: '📘', title: 'Science Codex', wide: true, custom: 'codex', engine, focus: key, buttons: [{ label: 'Close', primary: true }] });
  engine.onOpenCodex = openCodex;

  // briefing
  useEffect(() => {
    const P = engine.planet;
    const afterBriefing = () => {
      if (opts.demo) { engine.setSpeed(2); return; }
      if (opts.tutorial || !Settings.tutorialDone) { setTut(true); return; }
      Toasts.push('⭐ Next step: build an <b>Oxygen Generator</b> or a second <b>Solar Array</b>. Watch the chips at the top!', 'info', null, 8000);
    };
    const t = setTimeout(async () => {
      if (opts.demo) {
        await Modals.open({ icon: '🎬', title: 'Hackathon demo mode', wide: true,
          body: `<p>A complete <b>${P.name}</b> base is already running: solar arrays, batteries, a fission reactor, oxygen generators, ice miners, a water recycler, greenhouses, radiation shields, a lab and a comms dish.</p><p>Use the <b>DEMO MODE</b> panel to show each feature in order: the base tour, life-support science, an emergency with engineering choices, a radiation alert built from <b>real NASA DONKI data</b>, the data sources, the final mission report, and the Moon version.</p><p class="small muted">Random emergencies are switched off in demo mode, so nothing interrupts the presentation. Everything else is the real game.</p>`,
          buttons: [{ label: 'Start the demo ▸', primary: true }] });
        afterBriefing();
        return;
      }
      await Modals.open({
        icon: P.id === 'mars' ? '🔴' : '🌙', title: `Welcome to ${P.name}, Commander`, wide: true,
        body: `<p>Your crew of 4 has landed at <b>${P.site}</b>: ${P.siteNote.toLowerCase()}. The habitat, one solar array and one greenhouse are already set up, but supplies from Earth will last only about a week. This is a <b>${engine.days}-${P.dayUnit.toLowerCase()} ${(DURATIONS.find((d) => d.days === engine.days) || {}).label || 'mission'}</b>: to succeed, the crew must survive all ${engine.days} ${P.dayUnit.toLowerCase()}s by <b>living off the land</b>.</p>
        ${engine.days > 30 ? `<p><b>Threat levels:</b> the mission gets harder over time. From Day 20, 45 and 70, equipment wears out faster and emergencies (air leaks, crop disease, illness, battery faults${P.id === 'mars' ? ', a global dust storm' : ', more impacts'}) become more frequent. Keep repairing! Checkpoints on ${engine.milestones.map((m) => `Day ${m}`).join(' and ')} bring bonus supplies.</p>` : ''}
        <div class="brief-grid"><div><span>🫁</span><b>Oxygen</b><small>0.84 kg per astronaut per day</small></div><div><span>💧</span><b>Water</b><small>3.5 L each per day (recycle it!)</small></div><div><span>🥫</span><b>Food</b><small>1.2 kg each per day</small></div><div><span>⚡</span><b>Power</b><small>Keeps everything running</small></div></div>
        <p><b>Emergencies:</b> dust, oxygen-generator failures, water leaks, battery failures and radiation alerts will interrupt the mission. Each one gives you 2–3 choices with different costs: smart decisions earn 🏅 mission points.</p>
        <p><b>How to play:</b> pick a building from the bar at the bottom, then tap a tile to place it. Drag to rotate, pinch or scroll to zoom, and two-finger drag (or right-drag) to pan. Tap any building to inspect, repair or switch it off. The ⭐ card is the next thing to build.</p>
        <p class="fact">📘 ${P.challenge}</p>`,
        buttons: [{ label: 'Begin mission ▸', primary: true }],
      });
      afterBriefing();
    }, 500);
    return () => clearTimeout(t);
  }, [engine]);

  // keyboard + pause when hidden
  useEffect(() => {
    const onKey = (e) => {
      if (Modals.isOpen()) return;
      if (e.code === 'Space') { e.preventDefault(); engine.setSpeed(engine.speed ? 0 : engine.prevSpeed || 1); }
      if (e.key === '1') engine.setSpeed(1); if (e.key === '2') engine.setSpeed(2); if (e.key === '3') engine.setSpeed(4); if (e.key === '4') engine.setSpeed(8);
      if (e.key === 'Escape') { engine.cancelBuild(); engine.select(null); }
    };
    const onVis = () => { if (document.hidden && engine.speed) { engine.prevSpeed = engine.speed; engine.setSpeed(0); } };
    window.addEventListener('keydown', onKey); document.addEventListener('visibilitychange', onVis);
    return () => { window.removeEventListener('keydown', onKey); document.removeEventListener('visibilitychange', onVis); document.body.style.cursor = ''; };
  }, [engine]);

  const menu = async () => {
    Sound.click();
    const v = await Modals.open({ icon: '⏸', title: 'Mission paused', body: `<p class="muted">${engine.planet.name} · ${engine.planet.dayUnit} ${Math.floor(engine.t) + 1}</p><p class="small">Shortcuts: <b>Space</b> pause · <b>1/2/3/4</b> speed (1×, 2×, 4×, 8×) · <b>Esc</b> cancel build</p>`, buttons: [{ label: '▶ Resume', primary: true, value: 'r' }, { label: '🔬 Life-support science', value: 'sci' }, { label: '🛰️ NASA data sources', value: 'src' }, { label: '📖 Mission Handbook', value: 'hb' }, { label: '⚙️ Settings', value: 'set' }, { label: '↻ Restart mission', value: 'restart' }, { label: '⌂ Change destination', value: 'title' }] });
    if (v === 'hb') openHandbook();
    if (v === 'sci') openSystems(engine);
    if (v === 'src') openSources();
    if (v === 'set') openSettings({ replay: () => setTut(true) });
    if (v === 'restart') onRestart(engine.planet.id, engine.days);
    if (v === 'title') onTitle();
  };

  return (
    <>
      <div id="scene"><World engine={engine} onReady={() => setReady(true)} /></div>
      <EndWatcher engine={engine} onRestart={onRestart} onTitle={onTitle} />
      <HUD engine={engine} onMenu={menu} openCodex={openCodex} />
      {tut && <Tutorial engine={engine} onDone={() => { setTut(false); Toasts.push('🎓 Tutorial complete. ⭐ Next: a second <b>Solar Array</b> or a <b>Water Recycler</b>.', 'good', null, 7000); }} />}
      {opts.demo && <DemoPanel engine={engine} actions={{
        tour: () => { const c = window.__ja.controls; if (c) { c.autoRotate = true; c.autoRotateSpeed = 1.2; setTimeout(() => { c.autoRotate = false; }, 14000); } },
        science: () => openSystems(engine, 'o2'),
        dust: () => engine.triggerEmergency('dust'),
        radiation: () => engine.triggerEmergency('radiation'),
        sources: () => openSources(),
        report: () => { engine.events = []; Modals.clear(); engine.t = Math.max(engine.t, engine.days - 0.02); engine.setSpeed(1); },
        moon: () => onRestart(engine.planet.id === 'mars' ? 'moon' : 'mars', engine.days, { demo: true, demoStep: 6 }),
      }} startAt={opts.demoStep || 0} />}
      <LaunchCurtain planet={engine.planet} ready={ready} />
    </>
  );
}

// ---------- STEM final report (HTML strings for the end-of-mission modal) ----------
const RANK_NEXT = {
  cadet: 'Survive the whole mission to earn <b>Bronze</b>.',
  bronze: 'For <b>Silver</b>: complete the mission with a score of 70+ and at least 3 crew.',
  silver: 'For <b>Gold</b>: complete the mission with a score of 85+ and all 4 crew home safe.',
  gold: 'The highest rank. Mission Control is proud of you!',
};
function stemReport(engine, r) {
  const st = r.stem, K = RANKS[st.rank];
  return `<div class="rank ${st.rank}" id="rank" data-rank="${st.rank}" style="--rk:${K.color}">
      <div class="rk-medal">${K.icon}</div>
      <div class="rk-t"><small>Astronaut rank</small><b>${K.name}</b><span>Survival score <b id="surv-score">${st.total}</b> / 100</span></div>
    </div>
    <p class="rk-next small muted center">${RANK_NEXT[st.rank]}</p>`;
}
function stemSections(engine, r) {
  const st = r.stem, RP = engine.report, R = engine.res;
  const bar = (p) => `<div class="sc-row"><span>${p.label}</span><i class="sc-bar"><i style="width:${(p.value / p.max) * 100}%"></i></i><b>${Math.round(p.value)} / ${p.max}</b><small>${p.detail}</small></div>`;
  const crew = engine.crew.map((c) => `<div class="rp-crew ${c.status}"><span><b>${c.name}</b> <small>${c.role}</small></span><span>${c.status === 'active' ? `❤ ${Math.round(c.health)}%` : c.status === 'lost' ? '🕯️ lost' : '🚀 evacuated'}</span><span>☢ ${Math.round(c.dose)} mSv</span></div>`).join('');
  const res = [['🫁 Oxygen', 'o2', 'kg', 1], ['💧 Water', 'water', 'L', 0], ['🥫 Food', 'food', 'kg', 0]].map(([l, k, u, d]) => `<div><span>${l}</span><b>${fmt(R[k], d)} ${u} left <small>· lowest ${fmt(RP.minRes[k], d)} · made ${fmt(RP.made[k], 0)} ${u}</small></b></div>`).join('');
  const g = st.grades, graded = engine.decisions.filter((d) => d.grade);
  const log = graded.length ? `<div class="rp-decisions">${graded.map((d) => `<div class="rp-dec ${d.grade}"><span>${GRADES[d.grade].icon}</span><span>Day ${d.day} · ${d.icon || ''} ${d.title.replace('!', '')}</span><b>${d.choice}</b></div>`).join('')}</div>` : '<p class="small muted">No emergency decisions were needed.</p>';
  return `<div class="rp-h">🧮 Survival score breakdown</div><div class="scorecard">${Object.values(st.parts).map(bar).join('')}</div>
    <div class="rp-h">👩‍🚀 Crew survival & health</div><p class="rp-surv" id="crew-survival">${engine.crewActive() === 4 ? '🎉 All 4 astronauts are home safe.' : `${engine.crewActive()} of 4 astronauts finished the mission${engine.crew.some((c) => c.status === 'evacuated') ? ' (evacuated crew are alive but left early)' : ''}.`}</p><div class="report crewrep">${crew}</div>
    <div class="rp-h">📦 Resources</div><div class="report">${res}
      <div><span>♻️ Water recycled</span><b>${fmt(RP.recycledL, 0)} L</b></div>
      <div><span>⚡ Energy generated</span><b>${fmt(RP.energyKWh, 0)} kWh</b></div>
      <div><span>Time without shortages</span><b>${Math.round(st.noShort * 100)}%</b></div></div>
    <div class="rp-h">⚙️ Engineering performance</div><div class="report">
      <div><span>Decision quality</span><b>${Math.round(st.quality * 100)}% · ✅ ${g.best} 👍 ${g.good} ⚠️ ${g.risky} ❌ ${g.poor}</b></div>
      <div><span>Power fully available</span><b>${Math.round(st.uptime * 100)}% of the time</b></div>
      <div><span>Average equipment condition</span><b>${Math.round(st.avgCond)}%</b></div>
      <div><span>Buildings at the end</span><b>${[...engine.buildings.values()].filter((b) => b.built && b.type !== 'habitat' && b.type !== 'lander').length}</b></div></div>
    ${log}
    ${learnSection(engine, g, graded)}`;
}

function learnSection(engine, g, graded) {
  const P = engine.planet, RP = engine.report;
  const qz = engine.quizCount ? Math.round((100 * engine.quizScore) / engine.quizCount) : null;
  const ex = RP.explainers ? RP.explainers.size : 0;
  const storms = graded.filter((d) => d.nasa);
  const topics = [...engine.codex].filter((k) => CODEX[k]).map((k) => `<span class="lt">${CODEX[k].icon || '📘'} ${CODEX[k].title.split(' — ')[0]}</span>`).join('');
  return `<div class="rp-h">🎓 STEM learning results</div><div class="report learnrep" id="learn-results">
      <div><span>📘 Science Codex entries unlocked</span><b>${engine.codex.size} / ${Object.keys(CODEX).length}</b></div>
      <div><span>🧠 Mission Control quiz</span><b>${engine.quizCount ? `${engine.quizScore} / ${engine.quizCount} correct (${qz}%)` : 'no questions answered'}</b></div>
      <div><span>💡 ${P.id === 'mars' ? 'Mars' : 'Moon'} facts discovered</span><b>${engine.factsSeen.length} / ${FACTS[P.id].length}</b></div>
      <div><span>🔬 Life-support topics explored</span><b>${ex} / 5</b></div>
      <div><span>🧑‍🏫 Engineering decisions explained</span><b>${graded.length} (✅ ${g.best} best · 👍 ${g.good} good)</b></div>
      <div><span>🛰️ Real NASA solar storms faced</span><b>${storms.length ? storms.map((d) => `${fmtUTC(d.nasa.time, false)} (${STRENGTH[d.nasa.strength].label.toLowerCase()}, ${d.nasa.src})`).join(' · ') : 'none this mission'}</b></div>
    </div>
    ${topics ? `<div class="learn-topics"><small>Science topics you met:</small>${topics}</div>` : ''}`;
}

function EndWatcher({ engine, onRestart, onTitle }) {
  useEngine(engine);
  useEffect(() => {
    if (!engine.result || engine._endShown) return;
    engine._endShown = true;
    const r = engine.result, P = engine.planet;
    Modals.open({
      icon: r.win ? '🏆' : '💀', title: r.win ? 'Mission Complete!' : 'Mission Failed', wide: true, dismissable: false, kind: r.win ? 'good' : 'danger',
      body: `${stemReport(engine, r)}
        <div class="stars">${[1, 2, 3].map((k) => `<span class="${k <= r.stars ? 'on' : ''}">★</span>`).join('')}</div>
        <p class="center">${r.win ? `Your colony on ${P.name} survived all ${engine.days} ${P.dayUnit.toLowerCase()}s.` : `The base was lost on ${P.dayUnit} ${Math.floor(engine.t) + 1} of ${engine.days}.`}</p>
        ${stemSections(engine, r)}
        <div class="rp-h">📋 Mission log</div>
        <div class="report">
          <div><span>Mission</span><b>${engine.days} days · ${(DURATIONS.find((d) => d.days === engine.days) || {}).label || ''}</b></div>
          <div><span>Days survived</span><b>${Math.floor(r.daysDone)} / ${engine.days}</b></div>
          <div><span>Highest threat level</span><b>${THREAT[r.level].short} · ${THREAT[r.level].name}</b></div>
          <div><span>Crew home safe</span><b>${r.alive} / 4</b></div><div><span>Lowest crew health</span><b>${Math.round(engine.report.minHealth)}%</b></div>
          <div><span>Emergencies survived</span><b>${engine.report.emergencies}</b></div><div><span>Emergency decisions handled well</span><b>${engine.report.emResolved} / ${engine.report.emResolved + engine.report.emFailed}</b></div>
          <div><span>🏅 Mission points</span><b>${engine.points}</b></div><div><span>Repairs made</span><b>${engine.repairs}</b></div>
          <div><span>Science collected</span><b>${r.sci} / ${r.sciGoal} goal</b></div>
          <div><span>Goals completed</span><b>${engine.objDone.size} / ${engine.objectives.length}</b></div><div><span>Quiz answers</span><b>${engine.quizScore} / ${engine.quizCount}</b></div>
          <div><span>Average radiation dose</span><b>${fmt(r.avgDose, 0)} mSv</b></div><div><span>Codex entries found</span><b>${engine.codex.size} / ${Object.keys(CODEX).length}</b></div>
          <div class="total"><span>Mission score</span><b>${r.score.toLocaleString()}</b></div>
        </div><p class="fact">📘 For comparison: a person on Earth receives ~3 mSv per year, and NASA's career limit for astronauts is 600 mSv.</p>`,
      buttons: [{ label: '↻ Fly again', value: 'again', primary: true }, { label: P.id === 'mars' ? '🌙 Try the Moon' : '🔴 Try Mars', value: 'other' }, { label: '⌂ Title', value: 'title' }],
    }).then((v) => { if (v === 'again') onRestart(P.id, engine.days); else if (v === 'other') onRestart(P.id === 'mars' ? 'moon' : 'mars', engine.days); else onTitle(); });
  });

  return null;
}

// =================== HUD ===================
function HUD({ engine, onMenu, openCodex }) {
  useTick(200);
  useEngine(engine);
  const compact = useCompact();
  // on phones the critical-alert pill sits just below the goals/crew panels instead of on top of them
  const alertRef = useRef();
  useLayoutEffect(() => {
    const el = alertRef.current; if (!el) return;
    if (!compact || window.innerHeight <= 500) { el.style.top = ''; return; }
    const low = Math.max(...['#objectives', '#crew'].map((q) => { const n = document.querySelector(q); return n ? n.getBoundingClientRect().bottom : 0; }));
    el.style.top = `${Math.round(low + 6)}px`;
  });
  const [soundOn, setSoundOn] = useState(Sound.on);
  const [musicOn, setMusicOn] = useState(Settings.music);
  const [objOpen, setObjOpen] = useState(!compact);
  const [crewOpen, setCrewOpen] = useState(false);
  const [powerOpen, setPowerOpen] = useState(false);
  const P = engine.planet, R = engine.res, S = engine.stats, env = engine.env, rr = engine.rates;
  const D = engine.days;
  const day = Math.min(Math.floor(engine.t) + 1, D);
  const tLvl = threatLevel(engine.t), T = THREAT[tLvl];
  const phase = engine.t % 1, hh = Math.floor(phase * 24), mm = Math.floor((phase * 24 - hh) * 60);
  const storm = engine.stormIntensity();
  const temp = P.id === 'mars'
    ? P.tempMin + (P.tempMax - P.tempMin) * ((Math.sin((phase - 0.35) * Math.PI * 2) + 1) / 2) * (1 - storm * 0.3)
    : P.tempMin + (P.tempMax - P.tempMin) * env.sunFactor;
  let light = engine.spe ? '☢️ Solar storm' : engine.storm ? '🌪️ Dust storm' : P.id === 'moon' ? (env.sunFactor > 0.5 ? '☀️ Sun circling horizon' : '🌑 Sun behind massif') : env.day > 0.5 ? '☀️ Day' : '🌙 Night';
  if (compact) light = light.split(' ')[0];
  const clockZone = P.id === 'mars' ? 'LMST' : 'UTC';

  const daysLeft = (v, r) => (r < -0.01 ? v / -r : Infinity);
  const sub = (r, v) => {
    const dl = daysLeft(v, r);
    const rate = `${r >= 0 ? '+' : '−'}${fmt(Math.abs(r), 1)}/d`;
    const left = <b>{dl < 1 ? '<1' : Math.floor(dl)}d left</b>;
    if (compact) return dl < 99 ? left : rate;
    return dl < 99 ? <>{rate} · {left}</> : rate;
  };
  const lvl = (v, r) => { const dl = daysLeft(v, r); return v <= 0 || dl < 2 ? 'crit' : dl < 5 ? 'warn' : ''; };
  const net = S.prod - S.demand, bp = S.cap ? R.battery / S.cap : 0;
  const alive = engine.crewActive();
  const avgH = engine.crew.filter((c) => c.status === 'active').reduce((a, c) => a + c.health, 0) / Math.max(1, alive);
  // plain-language power advice (shown when the ⚡ gauge is tapped): what actually helps right now
  const pAdvice = engine.powerAdvice();
  const F = S.flags; const alerts = [];
  if (F.noO2) alerts.push('NO OXYGEN: crew suffocating!');
  if (F.noWater) alerts.push('NO WATER');
  if (F.noFood) alerts.push('NO FOOD');
  if (F.leak) alerts.push('AIR LEAK: repair the habitat!');
  alerts.push(...engine.activeAlerts());
  if (F.cold) alerts.push('POWER FAILURE: life support failing');
  else if (S.ratio < 0.99) alerts.push(`Power shortage: life support first, others at ${Math.round(S.ratio * 100)}%`);

  const chips = [
    { id: 'o2', ic: '🫁', lab: `Oxygen (tank holds ${STORE_CAP.o2} kg). Tap for the science`, v: `${fmt(R.o2, 1)} kg`, s: R.o2 >= STORE_CAP.o2 - 0.5 ? 'tank full' : sub(rr.o2, R.o2), l: lvl(R.o2, rr.o2), onClick: () => { Sound.click(); openSystems(engine, 'o2'); } },
    { id: 'water', ic: '💧', lab: `Water (tanks hold ${STORE_CAP.water} L). Tap for the science`, v: `${fmt(R.water, 0)} L`, s: R.water >= STORE_CAP.water - 1 ? 'tanks full' : sub(rr.water, R.water), l: lvl(R.water, rr.water), onClick: () => { Sound.click(); openSystems(engine, 'water'); } },
    { id: 'food', ic: '🥫', lab: `Food (pantry holds ${STORE_CAP.food} kg). Tap for the science`, v: `${fmt(R.food, 0)} kg`, s: R.food >= STORE_CAP.food - 1 ? 'pantry full' : sub(rr.food, R.food), l: lvl(R.food, rr.food), onClick: () => { Sound.click(); openSystems(engine, 'food'); } },
    { id: 'power', ic: '⚡', lab: 'Energy', v: `${net >= 0 ? '+' : '−'}${fmt(Math.abs(net), 1)} kW`, s: compact ? `🔋 ${Math.round(bp * 100)}%` : `🔋 ${Math.round(bp * 100)}% · ${fmt(R.battery, 0)}/${fmt(S.cap, 0)} kWh`, l: S.ratio < 0.99 ? 'crit' : net < 0 && bp < 0.25 ? 'warn' : '', onClick: () => setPowerOpen((o) => !o) },
    { id: 'crew', ic: '👩‍🚀', lab: 'Crew health', v: `${Math.round(avgH)}%`, s: `${alive}/4 active`, l: avgH < 30 || alive < 4 ? 'crit' : avgH < 70 ? 'warn' : '', onClick: () => setCrewOpen((o) => !o) },
    { id: 'mat', ic: '🧱', lab: 'Materials', v: `${fmt(R.mat, 0)} kg`, s: compact ? <>🔬 {fmt(R.science, 0)} · <span id="pts-mini">🏅 {engine.points}</span></> : rr.mat > 0.5 ? `+${fmt(rr.mat, 0)}/d` : 'building supplies', l: '' },
  ];
  if (!compact) {
    chips.push({ id: 'sci', ic: '🔬', lab: 'Science', v: fmt(R.science, 0), s: rr.science > 0.1 ? `+${fmt(rr.science, 1)}/d` : 'build a lab', l: '' });
    chips.push({ id: 'pts', ic: '🏅', lab: 'Mission points (emergency decisions)', v: `${engine.points}`, s: `${engine.decisions.length} decision${engine.decisions.length === 1 ? '' : 's'}`, l: '' });
  }

  return (
    <div id="hud" className={engine.speed === 0 ? 'paused' : ''}>
      <div id="rad-overlay" className={engine.spe ? 'show' : ''} aria-hidden="true" />
      <header id="topbar">
        <div className="pill mission"><span className="pdot" /><div className="mtext"><b>{P.name.toUpperCase()}</b><small>{P.site} · {D}-day mission</small></div></div>
        <div className="pill clock">
          <b><span className={`threat t${tLvl}`} title={`Threat level ${T.short}: ${T.name}`}>{compact ? T.short : `THREAT ${T.short}`}</span>{compact ? P.dayUnit.toUpperCase() : P.id === 'moon' ? 'EARTH DAY' : 'SOL'} {day} / {D}</b>
          <small title={P.id === 'mars' ? 'Local Mean Solar Time (a Mars hour is 1.03 Earth hours)' : 'Earth time (UTC). At the lunar pole the Sun circles the horizon once every 29.5 days'}>{String(hh).padStart(2, '0')}:{String(mm).padStart(2, '0')} {compact ? '' : clockZone} · {light} · ≈{Math.round(temp)} °C</small>
          <div id="mission-track">
            <div id="mission-progress" style={{ width: `${clamp(engine.t / D, 0, 1) * 100}%` }} />
            {engine.milestones.map((m) => <i key={m} className={`mtick ${engine.t >= m ? 'done' : ''}`} style={{ left: `${(m / D) * 100}%` }} />)}
          </div>
        </div>
        <div className="pill" id="speed">
          {[[0, '⏸', 'Pause (Space)'], [1, '▶', 'Normal speed'], [2, '▶▶', '2× speed'], [4, '⏩', '4× speed'], [8, '8×', '8× speed']].map(([s, l, t]) => (
            <button key={s} data-s={s} title={t} className={engine.speed === s ? 'on' : ''} onClick={() => { Sound.click(); engine.setSpeed(s); }}>{l}</button>
          ))}
        </div>
        <div className="pill tools">
          {!compact && <button id="btn-science" title="Life-support science" onClick={() => { Sound.click(); openSystems(engine); }}>🔬</button>}
          <button id="btn-codex" title="Science Codex" className={performance.now() - (engine.codexPing || -1e9) < 3000 ? 'ping' : ''} onClick={() => { Sound.click(); openCodex(); }}>📘</button>
          <button id="btn-sound" title="Sound effects" onClick={() => { Sound.init(); Settings.set({ sfx: !Settings.sfx }); setSoundOn(Settings.sfx); }}>{soundOn ? '🔊' : '🔇'}</button>
          <button id="btn-music" title="Background music" className={musicOn ? '' : 'off'} onClick={() => { Sound.init(); Settings.set({ music: !Settings.music }); setMusicOn(Settings.music); }}>🎵</button>
          <button id="btn-menu" title="Menu" onClick={onMenu}>☰</button>
        </div>
      </header>

      <div id="resources" className={compact ? 'compact' : ''}>
        {chips.map((c) => (
          <div key={c.id} id={`r-${c.id}`} className={`pill chip ${c.onClick ? 'tap' : ''} ${c.id === 'power' && powerOpen ? 'expand' : ''}`} data-level={c.l} onClick={c.onClick} title={c.lab}>
            <span className="ic">{c.ic}</span>
            <span className="v">{c.v}</span>
            <span className="s">{c.s}</span>
            {c.id === 'power' && powerOpen && <span id="power-detail">Making {fmt(S.prod, 1)} kW · Using {fmt(S.demand, 1)} kW{pAdvice && <em id="power-advice"> · {pAdvice}</em>} <button id="power-learn" className="learn-link" onClick={(e) => { e.stopPropagation(); Sound.click(); openSystems(engine, 'energy'); }}>🔬 Why?</button></span>}
          </div>
        ))}
      </div>
      <div id="alertbar" ref={alertRef} className={alerts.length ? 'show' : ''}>{alerts.join(' · ')}</div>

      <Objectives engine={engine} open={objOpen} setOpen={setObjOpen} />
      <CrewPanel engine={engine} open={crewOpen} setOpen={setCrewOpen} />
      <ToastStack />
      <InfoPanel engine={engine} openCodex={openCodex} />
      <BuildBar engine={engine} compact={compact} />
    </div>
  );
}

function Objectives({ engine, open, setOpen }) {
  const sug = engine.suggestion();
  let cur = null;
  const items = engine.objectives.map((o) => {
    const done = engine.objDone.has(o.id);
    const text = typeof o.text === 'function' ? o.text(engine.planet, engine) : o.text;
    if (!done && !cur) cur = { ...o, text };
    return { ...o, text, done };
  });
  return (
    <aside className={`panel side ${open ? '' : 'collapsed'}`} id="objectives">
      <div className="sh" onClick={() => { Sound.click(); setOpen(!open); }}>🎯 <span className="sh-long">MISSION </span>GOALS <span className="cnt">{engine.objDone.size}/{engine.objectives.length}</span><span className="chev">▾</span></div>
      <div id="obj-current">{cur ? <><b>{cur.title}:</b> {cur.text}</> : <><b>All goals done!</b> Survive to {engine.planet.dayUnit} {engine.days}</>}</div>
      {sug && (sug.repair != null
        ? <button id="hint-why" className="hint-repair" onClick={() => { Sound.click(); engine.select(sug.repair); }}>🔧 <b>Now:</b> {sug.why}</button>
        : <div id="hint-why">⭐ <b>Now:</b> {sug.why}</div>)}
      <ul id="obj-list">
        {items.map((o) => (
          <li key={o.id} className={o.done ? 'done' : cur && cur.id === o.id ? 'cur' : ''}>
            <span className="ck">{o.done ? '✔' : '○'}</span><div><b>{o.title}</b><small>{o.text}{o.reward ? ` · +${o.reward}` : ''}</small></div>
          </li>
        ))}
        {engine.milestones.map((m) => <li key={m} className={engine.milestonesDone.has(m) ? 'done' : ''}><span className="ck">{engine.milestonesDone.has(m) ? '✔' : '🚩'}</span><div><b>Checkpoint: Day {m}</b><small>Reach Day {m} · +150</small></div></li>)}
        <li className={engine.t >= engine.days ? 'done' : ''}><span className="ck">🏁</span><div><b>Mission complete</b><small>Keep the crew alive until the end of {engine.planet.dayUnit} {engine.days}</small></div></li>
      </ul>
    </aside>
  );
}

function CrewPanel({ engine, open, setOpen }) {
  const alive = engine.crewActive();
  const avg = engine.crew.filter((c) => c.status === 'active').reduce((a, c) => a + c.health, 0) / Math.max(1, alive);
  return (
    <aside className={`panel side ${open ? '' : 'collapsed'}`} id="crew">
      <div className="sh" onClick={() => { Sound.click(); setOpen(!open); }}>👩‍🚀 CREW <span className="cnt">{alive}/4 · ❤ {Math.round(avg)}%</span><span className="chev">▾</span></div>
      <ul id="crew-list">
        {engine.crew.map((c) => (
          <li key={c.name} className={c.status !== 'active' ? 'gone' : ''}>
            <span className="dot" style={{ background: c.color }} />
            <div className="cw">
              <div className="cn"><b>{c.name}</b><span className="dose">{c.status === 'active' ? `${fmt(c.dose, 0)} mSv` : c.status === 'lost' ? 'LOST' : 'EVACUATED'}</span></div>
              <small>{c.role} · {c.perk}</small>
              <div className="hb"><i style={{ width: `${c.health}%`, background: c.health > 60 ? '#3dff8a' : c.health > 30 ? '#ffc23d' : '#ff4d4d' }} /></div>
            </div>
          </li>
        ))}
      </ul>
      {open && <button id="crew-learn" className="learn-link block" onClick={() => { Sound.click(); openSystems(engine, 'radiation'); }}>☢️ How does radiation affect the crew?</button>}
    </aside>
  );
}

function ToastStack() {
  const list = useSyncExternalStore(Toasts.subscribe, () => Toasts.list);
  return (
    <div id="toasts">
      {list.map((t) => (
        <div key={t.id} className={`toast ${t.kind} ${t.onClick ? 'clickable' : ''}`} onClick={t.onClick ? () => { t.onClick(); Toasts.remove(t.id); } : undefined} dangerouslySetInnerHTML={{ __html: t.html }} />
      ))}
    </div>
  );
}

function InfoPanel({ engine, openCodex }) {
  const b = engine.ui.selected != null ? engine.buildings.get(engine.ui.selected) : null;
  if (!b) return null;
  const P = engine.planet, S = engine.stats;
  let icon, name, desc; const stats = [], actions = [];
  if (b.type === 'habitat') {
    icon = '🏠'; name = 'Habitat'; desc = 'Home for 4 astronauts: air, heat and pressure. Life support uses 2 kW and always gets power first. During solar storms the crew shelter here.';
    stats.push(['Condition', `${Math.round(b.cond)}%${b.cond < 50 ? ' ⚠ LEAKING AIR' : ''}`], ['Crew inside', `${engine.crewActive()} / 4`], ['Shields touching', `${engine.habitatShields()} ${engine.habitatShields() >= 2 ? '✅ storm shelter' : '(need 2)'}`], ['Life support', '2 kW, powered first', 'game'], ['Pressure', '101 kPa inside', 'real'], ['Outside', P.id === 'mars' ? '≈0.6 kPa, 95% CO₂' : 'near vacuum', 'real'], ['Surface radiation', `${P.radiationPerDay} mSv/day`, 'real']);
    if (b.cond < 100) { const c = engine.repairCost(b); actions.push(['repair', `🔧 Repair · ${c} kg`, engine.res.mat < c || !!engine.spe]); }
  } else if (b.type === 'lander') {
    icon = '🛬'; name = 'Lander'; desc = 'Your ride down from orbit. Its batteries give the base 50 kWh of storage to start with.';
    stats.push(['Battery', `${50 - engine.landerCapLoss} / 50 kWh${engine.landerCapLoss ? ' (damaged)' : ''}`, 'game'], ['Gravity here', `${P.gravity} m/s² (${P.gravityG} g)`, 'real']);
    if (engine.landerCapLoss) { const c = Math.round(40 * (engine.hasRole('Engineer') ? 0.6 : 1)); actions.push(['repairlander', `🔧 Repair battery · ${c} kg`, engine.res.mat < c]); }
  } else {
    const d = BUILDINGS[b.type]; icon = d.icon; name = d.name; desc = d.desc(P);
    if (!b.built) stats.push(['Construction', `${Math.round(b.progress * 100)}%${engine.spe ? ' (paused: solar storm)' : ''}`]);
    else {
      const eff = engine.bEff(b) * S.ratio;
      const status = !b.on ? '⏸ Switched off' : b.cond <= 0 ? '💥 Broken' : S.ratio < 0.95 && d.power < 0 ? `⚡ Low power (${Math.round(S.ratio * 100)}%)` : b.cond < 100 ? `🔧 Damaged (${Math.round(b.cond)}%)` : '✅ Working';
      stats.push(['Status', status], ['Condition', `${Math.round(b.cond)}%`]);
      if (b.type === 'solar') {
        stats.push(['Output now', `${fmt(engine.solarOutput(b), 1)} kW / ${P.id === 'mars' ? 7.4 : 17} kW peak`]);
        if (P.id === 'mars' || b.dust < 1) stats.push(['Panel cleanliness', `${Math.round(b.dust * 100)}%`, 'game']);
        stats.push(['Sunlight × area × efficiency', `${P.irradiance} W/m² × 50 m² × 25%`, 'real']);
      }
      if (d.power) stats.push([d.power > 0 ? 'Power made' : 'Power used', `${Math.abs(d.power)} kW`, b.type === 'reactor' ? 'real' : 'game']);
      if (b.type === 'battery') stats.push(['Base storage', `${fmt(engine.res.battery, 0)} / ${fmt(S.cap, 0)} kWh`, 'game']);
      if (b.type === 'oxygen') stats.push(['Making', `${fmt(4 * eff, 1)} kg O₂/day`, 'game'], ['Crew need (0.84 kg each)', `${fmt(0.84 * engine.crewActive(), 2)} kg/day`, 'real'], ['Method', P.id === 'mars' ? '2 CO₂ → 2 CO + O₂' : '2 H₂O → 2 H₂ + O₂', 'real']);
      if (b.type === 'ice') stats.push(['Making', `${fmt(20 * eff * (engine.hasRole('Geologist') ? 1.25 : 1), 1)} L water/day`, 'game']);
      if (b.type === 'greenhouse') stats.push(['Making', `${fmt(2.6 * eff * (engine.hasRole('Botanist') ? 1.25 : 1), 1)} kg food + ${fmt(0.4 * eff, 1)} kg O₂/day`, 'game'], ['Uses', '2 L water/day', 'game']);
      if (b.type === 'fabricator') stats.push(['Making', `${fmt(50 * eff, 0)} kg materials/day`, 'game']);
      if (b.type === 'lab') stats.push(['Science', `${fmt(10 * eff, 1)} points/day`, 'game']);
      if (b.type === 'comms') stats.push(['Next cargo', engine.nextResupply ? `${P.dayUnit} ${Math.floor(engine.nextResupply) + 1}` : '—', 'game'], ['Signal delay', P.id === 'mars' ? '3–22 min' : '1.3 s', 'real']);
      if (b.type === 'shield') stats.push(['Protecting', 'buildings on the 8 tiles around it', 'game']);
      if (b.type === 'recycler') stats.push(['Water recovered', '90% for up to 4 crew', 'game'], ['ISS record (2023)', '98%', 'real']);
      if (d.power !== 0 || ['solar', 'battery'].includes(b.type)) actions.push(['toggle', b.on ? '⏸ Switch off' : '▶ Switch on']);
      if (b.cond < 100) { const c = engine.repairCost(b); actions.push(['repair', `🔧 Repair · ${c} kg`, engine.res.mat < c || !!engine.spe]); }
      if (b.type === 'solar' && b.dust < 0.97) actions.push(['clean', '🧹 Clean all panels (EVA)', !engine.canEVA()]);
    }
    actions.push(['recycle', `♻ Recycle +${Math.floor(d.cost * (b.built ? 0.5 : 1))}`]);
  }
  const codexKey = CODEX[b.type] ? b.type : b.type === 'habitat' ? 'radiation' : b.type === 'lander' ? 'gravity' : null;
  const act = (k) => {
    Sound.click();
    if (k === 'toggle') engine.toggle(b);
    if (k === 'repair') engine.repair(b);
    if (k === 'repairlander') engine.repairLander();
    if (k === 'clean') engine.clean();
    if (k === 'recycle') engine.recycle(b);
    if (k === 'learn') openCodex(codexKey);
  };
  return (
    <div id="info" className="panel">
      <div className="info-head"><span className="ii">{icon}</span><div><b>{name}</b><small>{desc}</small></div><button className="x" onClick={() => engine.select(null)}>✕</button></div>
      <div className="info-stats">{stats.map(([a, v, tag]) => <div key={a}><span>{a}</span><b>{v}{tag && <em className={`tag ${tag}`}>{tag === 'real' ? 'REAL' : 'GAME'}</em>}</b></div>)}</div>
      {TRADEOFFS[b.type] && <div className="tradeoff"><b>⚖ Trade-off:</b> {TRADEOFFS[b.type]}</div>}
      <div className="info-actions">
        {actions.map(([k, l, dis]) => <button key={k} className={`btn sm ${k === 'repair' ? 'primary' : ''}`} disabled={!!dis} onClick={() => act(k)}>{l}</button>)}
        {codexKey && engine.codex.has(codexKey) && <button className="btn sm ghost" onClick={() => act('learn')}>📘 Learn</button>}
      </div>
    </div>
  );
}

function BuildBar({ engine, compact }) {
  const R = engine.res;
  const next = engine.objectives.find((o) => !engine.objDone.has(o.id));
  const hintMap = { solar: 'solar', oxygen: 'oxygen', ice: 'ice', recycler: 'recycler', greenhouse: 'greenhouse', night: engine.planet.id === 'mars' ? 'battery' : 'reactor', shield: 'shield', lab: 'lab', comms: 'comms' };
  const sug = engine.suggestion();
  const hint = sug && sug.type ? sug.type : next ? hintMap[next.id] : null;
  const type = engine.ui.buildType, ghost = engine.ui.ghost;
  const touch = matchMedia('(pointer: coarse)').matches;
  const v = type && ghost ? engine.canPlace(type, ghost[0], ghost[1]) : null;
  const d = type ? BUILDINGS[type] : null;
  return (
    <div id="buildbar">
      {d && (
        <div id="build-hint" className="panel show">
          <div className="bh-main">
            <span className="bh-icon">{d.icon}</span>
            <div>
              <b>{d.name}</b> <span className="muted">· {d.cost} kg · {d.power ? `${d.power > 0 ? '+' : ''}${d.power} kW · ` : ''}{d.buildHours} h to build</span>
              <div className="bh-desc">{d.desc(engine.planet)}</div>
              {!compact && <div className="bh-desc trade">⚖ {TRADEOFFS[type]}</div>}
              <div className={`bh-why ${v ? (v.ok ? 'ok' : 'bad') : ''}`}>
                {!v ? (type === 'ice' ? (touch ? 'Tap a blue ice tile to preview, then tap ✓ Build' : 'Click a blue ice tile to build') : touch ? 'Tap a tile to preview, then tap ✓ Build' : 'Click a tile to build') : v.ok ? (v.why || (touch ? 'Looks good! Tap ✓ Build or tap the tile again' : 'Click to build here')) : `✗ ${v.why}`}
              </div>
            </div>
          </div>
          <div className="bh-btns">
            <button className="btn primary" id="bh-ok" disabled={!v || !v.ok} onClick={() => ghost && engine.place(ghost[0], ghost[1])}>✓ Build</button>
            <button className="btn" id="bh-x" onClick={() => { Sound.click(); engine.cancelBuild(); }}>✕</button>
          </div>
        </div>
      )}
      <div id="build-list" className="panel">
        {BUILD_ORDER.map((t) => {
          const b = BUILDINGS[t];
          return (
            <button key={t} data-type={t} title={hint === t && sug ? `⭐ ${sug.why}` : `${b.name}: ${b.short}`}
              className={`bcard ${type === t ? 'sel' : ''} ${hint === t ? 'hint' : ''} ${R.mat < b.cost ? 'poor' : ''}`}
              onClick={() => { Sound.init(); Sound.click(); engine.startBuild(t); }}>
              <span className="bi">{b.icon}</span><span className="bn">{b.name}</span><span className="bc">🧱 {b.cost}</span>
              {!compact && <span className="bs">{b.short}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// =================== Mission Handbook ===================
export const openSystems = (engine, tab = 'o2') => Modals.open({ icon: '🔬', title: 'Life-Support Science', wide: true, custom: 'systems', engine, tab, buttons: [{ label: 'Close', primary: true }] });
export const openHandbook = () => Modals.open({ icon: '📖', title: 'Mission Handbook', wide: true, custom: 'handbook', buttons: [{ label: 'Close', primary: true }] });

const MARS_VS_MOON = [
  ['Sunlight → solar array', '590 W/m² → 7.4 kW peak', '1361 W/m² → 17 kW peak'],
  ['Day / night', 'Every sol (24 h 39 min): ~12 h night', 'Sun circles the horizon; 6-day dark spell every 29.5 days (Days 13–19, 43–49, 72–78)'],
  ['Best power plan', 'Solar + batteries, cleaned panels', 'Fission reactor + solar'],
  ['Dust', 'Settles on panels (−1.2%/sol), storms cut sunlight up to ~76%, a global storm on long missions; dust devils clean panels', 'No wind; charged dust drifts onto panels after each dark spell'],
  ['Oxygen source', 'MOXIE-style: CO₂ from the air (no water used)', 'Electrolysis of ice water (4.5 L per 4 kg O₂)'],
  ['Radiation', '0.67 mSv/day; solar storms every ~3 weeks, 55–80 mSv unshielded (the air stops most solar protons)', '1.37 mSv/day; solar storms every ~2 weeks, 350–455 mSv unshielded (no air)'],
  ['Impacts', 'A meteorite every ~4 weeks (most burn up in the air)', 'Micrometeoroid strikes every 4–7 days (no air)'],
  ['Quakes', 'Marsquake (InSight detected 1,300+)', 'Moonquake (Apollo seismometers)'],
  ['Gravity', '3.71 m/s²: medium hops', '1.62 m/s²: big, slow hops'],
  ['Temperature', '≈ −30 °C day / −80 °C night', '≈ −40 °C sunlit, ≈ −170 °C in darkness'],
  ['Sky & air', 'Butterscotch sky, blue sunsets, haze', 'Black sky, stars, Earth overhead, no haze'],
  ['Cargo from Earth', 'Every 15 sols (imagined orbital depot; real windows ~26 months)', 'Every 6 days'],
  ['Radio delay', '3–22 minutes', '1.3 seconds'],
];

function HandbookBody() {
  const [tab, setTab] = useState('units');
  const tabs = [['units', 'Real vs game'], ['trade', 'Trade-offs'], ['worlds', 'Mars vs Moon']];
  return (
    <div className="m-body handbook">
      <div className="hb-tabs">{tabs.map(([k, l]) => <button key={k} className={`btn sm ${tab === k ? 'primary' : ''}`} onClick={() => { Sound.click(); setTab(k); }}>{l}</button>)}</div>
      {tab === 'units' && (
        <>
          <p className="muted small">Values marked <em className="tag real">REAL</em> come from real measurements or physics. Values marked <em className="tag game">GAME</em> are simplified or compressed so a 90-day mission fits in about 36 minutes (4.5 minutes at 8×). One game day = {SECONDS_PER_DAY} real seconds at 1× speed.</p>
          <div className="hb-table">{SCIENCE_TABLE.map(([q, real, game, kind]) => (
            <div key={q} className="hb-row"><b>{q} <em className={`tag ${kind}`}>{kind === 'real' ? 'REAL' : 'GAME'}</em></b><span><i>Real world:</i> {real}</span><span><i>In the game:</i> {game}</span></div>
          ))}</div>
        </>
      )}
      {tab === 'trade' && (
        <div className="hb-table">{BUILD_ORDER.map((t) => (
          <div key={t} className="hb-row"><b>{BUILDINGS[t].icon} {BUILDINGS[t].name}</b><span>{TRADEOFFS[t]}</span></div>
        ))}
          <div className="hb-row"><b>🧠 The big picture</b><span>Every building costs materials, power, a tile, and often water. Life support comes first (oxygen, water, food, heat). Then storage for darkness, then protection, then science. Doing science before the base is stable is the most common way to lose.</span></div>
        </div>
      )}
      {tab === 'worlds' && (
        <div className="hb-cmp">
          <div className="hb-cmp-h"><span /><b>🔴 Mars</b><b>🌙 Moon</b></div>
          {MARS_VS_MOON.map(([a, m, l]) => <div key={a} className="hb-cmp-r"><span>{a}</span><span>{m}</span><span>{l}</span></div>)}
        </div>
      )}
    </div>
  );
}

// =================== Modals ===================
function ModalHost() {
  const cur = useSyncExternalStore(Modals.subscribe, () => Modals.current);
  const card = useRef();
  useEffect(() => { if (card.current) card.current.scrollTop = 0; }, [cur]);
  if (!cur) return null;
  const { icon = '', title = '', body = '', buttons = [{ label: 'Continue', primary: true }], kind = '', dismissable = true, wide = false, custom } = cur.opts;
  return (
    <div id="modal" onClick={(e) => { if (dismissable && e.target.id === 'modal') Modals.close(-1); }}>
      <div ref={card} className={`modal-card ${kind} ${wide ? 'wide' : ''}`} data-em={custom === 'emergency' || custom === 'debrief' ? cur.opts.em.type : undefined} data-custom={custom || undefined}>
        {icon && <div className="m-icon">{icon}</div>}
        <h2>{title}</h2>
        {custom === 'emergency' ? <EmergencyBody em={cur.opts.em} engine={cur.opts.engine} /> : custom === 'codex' ? <CodexBody engine={cur.opts.engine} focus={cur.opts.focus} card={card} /> : custom === 'handbook' ? <HandbookBody /> : custom === 'sources' ? <SourcesBody tab={cur.opts.tab} /> : custom === 'settings' ? <SettingsBody extra={cur.opts.extra} /> : custom === 'systems' ? <SystemsBody engine={cur.opts.engine} tab={cur.opts.tab} /> : custom === 'debrief' ? <DebriefBody dec={cur.opts.dec} em={cur.opts.em} /> : <div className="m-body" dangerouslySetInnerHTML={{ __html: body }} />}
        <div className={`m-btns ${buttons.length > 3 ? 'stack' : ''}`}>
          {buttons.map((b, k) => <button key={k} className={`btn ${b.primary ? 'primary' : ''}`} onClick={() => { Sound.click(); Modals.close(b.value ?? k); }}>{b.label}</button>)}
        </div>
      </div>
    </div>
  );
}

const COST_LABEL = { mat: ['🧱', 'kg'], water: ['💧', 'L'], o2: ['🫁', 'kg O₂'], battery: ['🔋', 'kWh'], health: ['❤', '% health'] };
// =================== NASA DONKI space-weather data ===================
export const openSources = (tab) => Modals.open({ icon: '🛰️', title: 'NASA Data Sources & Credits', wide: true, custom: 'sources', tab, buttons: [{ label: 'Close', primary: true }] });
const NASA_STATUS = {
  idle: ['…', 'Not connected yet'],
  loading: ['⏳', 'Connecting to NASA DONKI…'],
  live: ['🟢', 'Live from NASA DONKI'],
  archived: ['🗄️', 'Archived NASA data'],
};
function NasaBadge() {
  useNasa();
  const [ic, txt] = NASA_STATUS[NasaData.status];
  return (
    <button id="nasa-badge" className={`nasa-badge ${NasaData.status}`} data-status={NasaData.status} onClick={() => { Sound.init(); Sound.click(); openSources(); }} title="Open the NASA data sources">
      <span className="nb-main">🛰️ NASA DATA INSIDE</span><span className="nb-sub">{ic} {txt}</span>
    </button>
  );
}
const srcTag = (src) => <em className={`tag ${src === 'live' ? 'live' : 'arch'}`}>{src === 'live' ? 'LIVE NASA RECORD' : 'ARCHIVED NASA RECORD'}</em>;
const FLR_WORD = { X: 'X-class (major)', M: 'M-class (medium)', C: 'C-class (small)', B: 'B-class (tiny)' };

function NasaEventCard({ ev, dose, baseDose, planet }) {
  const S = STRENGTH[ev.strength];
  const d = NasaData.data;
  const retrieved = ev.src === 'live' ? (d && d.fetchedAt ? `fetched ${fmtUTC(d.fetchedAt)}` : 'live') : `retrieved ${fmtUTC((d && d.archivedAt) || Nasa.DONKI_ARCHIVE_DATE)}`;
  return (
    <div className="nasa-card" data-src={ev.src}>
      <div className="nc-head"><b>🛰️ Real NASA event behind this alert</b>{srcTag(ev.src)}</div>
      <div className="nc-grid">
        <span>Event type</span><b>Solar Energetic Particle event (SEP)</b>
        <span>Date</span><b>{fmtUTC(ev.firstObs || ev.time)}</b>
        <span>Detected by</span><b>{ev.firstInst}{/^MODEL/.test(ev.firstInst) ? ' (model estimate)' : ''}{ev.detectors.length > 1 ? ` + ${ev.detectors.length - 1} more` : ''}</b>
        {ev.flare && <><span>Linked solar flare</span><b>{ev.flare.cls ? `${ev.flare.cls} · ${FLR_WORD[ev.flare.cls[0]] || ''}` : 'yes'} · {fmtUTC(ev.flare.begin || ev.flare.time)}</b></>}
        {ev.cme && <><span>Linked CME</span><b>{ev.cme.speed ? `${ev.cme.speed.toLocaleString()} km/s` : 'yes'} · {fmtUTC(ev.cme.time)}</b></>}
        {ev.warnMin != null && <><span>Real warning time</span><b>{ev.warnMin < 120 ? `${ev.warnMin} minutes` : `${Math.round(ev.warnMin / 60)} hours`} from the eruption to the first protons (the game gives you about 6 hours)</b></>}
        <span>Source</span><b><a href={ev.link} target="_blank" rel="noopener noreferrer">NASA CCMC DONKI ↗</a> · {retrieved}</b>
      </div>
      <details className="nc-more">
        <summary>How does this affect astronauts, and why does shielding matter?</summary>
        <p>A flare or a fast coronal mass ejection (CME) can accelerate protons to a large fraction of the speed of light. On Earth, the magnetic field and the thick air stop them. {planet.id === 'mars' ? 'Mars has no global magnetic field, but its thin CO₂ air stops most solar protons: only the most energetic reach the surface, so storms there are far weaker than in space or on the Moon.' : 'The Moon has no air and no magnetic field, so the protons arrive at full strength.'} Fast protons pass through skin and damage cells and DNA. A very large dose in a short time (about 700 mSv or more) causes radiation sickness, and every dose adds to the long-term cancer risk. NASA limits astronauts to 250 mSv per solar storm and 600 mSv in a career.</p>
        <p>Shielding works by putting <b>mass</b> between the crew and the Sun: regolith, the habitat walls or, best of all, hydrogen-rich water and plastics, which slow protons down without making as much secondary radiation as metals. Because the first protons can arrive within an hour, astronauts need a shelter they can reach quickly.</p>
        <p className="small"><b>Words on this card:</b> <b>GOES</b> are weather satellites near Earth that also count particles from the Sun. <b>MeV</b> (million electron-volts) measures a particle's energy: protons above about 100 MeV can pass through spacecraft walls. <b>SEP</b> = solar energetic particle event, a burst of fast protons from the Sun.</p>
        {planet.id === 'mars' && <p>Note: these detectors are near Earth. Mars is often on another side of the Sun, so the real storm may have hit Mars harder, more weakly or not at all. The game uses it as a real example of a storm's timing and strength.</p>}
      </details>
      <p className="nc-sim"><em className="tag game">SIMULATED</em> Strength in game: <b>{S.label}</b> ({S.why}) → crew dose ×{S.factor}: {baseDose} → <b>{dose} mSv</b> unshielded. Doses, resource costs and points are game values, not NASA measurements.</p>
    </div>
  );
}

function SourcesBody({ tab: tab0 }) {
  useNasa();
  const [tab, setTab] = useState(tab0 === 'credits' ? 'credits' : 'nasa');
  const tabs = <div className="hb-tabs" id="src-tabs">{[['nasa', '🛰️ NASA space-weather data'], ['credits', '📚 Science sources & credits']].map(([k, l]) => <button key={k} data-tab={k} className={`btn sm ${tab === k ? 'primary' : ''}`} onClick={() => { Sound.click(); setTab(k); }}>{l}</button>)}</div>;
  if (tab === 'credits') return <div className="m-body sources">{tabs}<CreditsPanel /></div>;
  const d = NasaData.data, st = NasaData.status;
  const ms = (t) => Date.parse(t) || 0;
  const flares = d ? [...d.flares].filter((f) => f.cls).sort((a, b) => ms(b.time) - ms(a.time)) : [];
  const recentFl = d ? flares.filter((f) => !d.window || f.time >= d.window[0]).slice(0, 12) : [];
  const cmes = d ? [...d.cmes].filter((c) => (c.speed || 0) >= 700).sort((a, b) => ms(b.time) - ms(a.time)).slice(0, 10) : [];
  return (
    <div className="m-body sources">
      {tabs}
      <div className={`src-status ${st}`} id="src-status" data-status={st}>
        {st === 'loading' && <p>⏳ <b>Connecting to the NASA DONKI API…</b> The game works normally while it loads.</p>}
        {st === 'live' && <p>🟢 <b>Live data from NASA.</b> Downloaded from the DONKI API at {fmtUTC(d.fetchedAt)} (events from {d.window[0]} to {d.window[1]}, plus older solar particle events). {d.recentSeps === 0 && 'No solar energetic particle events were recorded in the last 60 days; the SEP list below goes further back.'} {d.note}</p>}
        {st === 'archived' && <p>🗄️ <b>Archived NASA data, not live.</b> The live DONKI API could not be reached ({d.error}). The game is using real DONKI records that were downloaded on {fmtUTC(d.archivedAt)}.{/fetch|network/i.test(d.error) ? ' This happens when the device is offline, or when the page runs inside a host that blocks outside connections (such as the claude.ai artifact viewer).' : ''} <button className="btn sm" id="src-retry" onClick={() => { Sound.click(); loadDonki(); }}>🔄 Try live connection again</button></p>}
        {st === 'idle' && <p>Not connected yet.</p>}
      </div>
      {d && (
        <>
          <div className="src-counts"><span>☀️ <b>{d.flares.length}</b> solar flares</span><span>💨 <b>{d.cmes.length}</b> CMEs</span><span>☢️ <b>{d.seps.length}</b> SEP detections in <b>{d.clusters.length}</b> solar storms</span></div>
          <div className="rp-h">☢️ Solar energetic particle storms used for radiation alerts</div>
          <div className="src-list" id="src-seps">
            {d.clusters.map((c) => (
              <div key={c.id} className="src-row"><span className="sr-date">{fmtUTC(c.firstObs || c.time, false)}</span><span className="sr-what">SEP · {STRENGTH[c.strength].label}{c.flare && c.flare.cls ? ` · ${c.flare.cls} flare` : ''}{c.cme && c.cme.speed ? ` · CME ${c.cme.speed} km/s` : ''}</span>{srcTag(c.src)}<a href={c.link} target="_blank" rel="noopener noreferrer">DONKI ↗</a></div>
            ))}
          </div>
          <div className="rp-h">☀️ Recent solar flares</div>
          <div className="src-list" id="src-flares">
            {recentFl.map((f) => <div key={f.id} className="src-row"><span className="sr-date">{fmtUTC(f.time, false)}</span><span className="sr-what">Flare {f.cls}{f.ar ? ` · region ${f.ar}` : ''}</span>{srcTag(f.src)}<a href={f.link} target="_blank" rel="noopener noreferrer">DONKI ↗</a></div>)}
          </div>
          <div className="rp-h">💨 Fast coronal mass ejections (700+ km/s)</div>
          <div className="src-list" id="src-cmes">
            {cmes.map((c) => <div key={c.id} className="src-row"><span className="sr-date">{fmtUTC(c.time, false)}</span><span className="sr-what">CME {c.speed.toLocaleString()} km/s</span>{srcTag(c.src)}<a href={c.link} target="_blank" rel="noopener noreferrer">DONKI ↗</a></div>)}
          </div>
        </>
      )}
      <div className="rp-h">🔗 Original NASA sources</div>
      <ul className="src-links">
        <li><a href={DONKI_LINKS.tool} target="_blank" rel="noopener noreferrer">NASA CCMC: DONKI space weather database ↗</a></li>
        <li><a href={DONKI_LINKS.app} target="_blank" rel="noopener noreferrer">DONKI web app (search events) ↗</a></li>
        <li><a href={DONKI_LINKS.docs} target="_blank" rel="noopener noreferrer">DONKI API documentation ↗</a></li>
        <li><a href={DONKI_LINKS.guide} target="_blank" rel="noopener noreferrer">DONKI user guide ↗</a></li>
      </ul>
      <details className="nc-more"><summary>Exact API requests ({d ? d.queries.length : 0})</summary><ul className="src-q">{d && d.queries.map((q) => <li key={q}><a href={q} target="_blank" rel="noopener noreferrer">{q.replace('https://ccmc.gsfc.nasa.gov', '')}</a></li>)}</ul></details>
      <p className="small muted">Space weather data courtesy of NASA's Community Coordinated Modeling Center (CCMC), DONKI. DONKI data are research-grade and provided "as is"; NOAA's Space Weather Prediction Center is the official source of space weather forecasts. <b>In the game, radiation doses, resource costs and points are simulated values, not NASA measurements.</b></p>
    </div>
  );
}

function EmergencyBody({ em, engine }) {
  const T = THREAT[em.level];
  const P = engine.planet;
  return (
    <div className="m-body em">
      <div className="em-strip">⚠ EMERGENCY · {P.dayUnit} {Math.floor(em.day) + 1} · Threat {T.short} · {P.id === 'mars' ? '🔴 Mars' : '🌙 Moon'}</div>
      <p dangerouslySetInnerHTML={{ __html: em.cause }} />
      <p className="em-now"><b>Right now:</b> {em.effectNow}</p>
      {em.nasa && <NasaEventCard ev={em.nasa} dose={em.dose} baseDose={em.baseDose} planet={P} />}
      <div className="em-q">What will you do?</div>
      <div className="em-choices">
        {em.choices.map((c) => {
          const costs = Object.entries(c.costs);
          return (
            <button key={c.id} className={`em-choice ${c.available ? '' : 'off'}`} disabled={!c.available} data-choice={c.id}
              onClick={() => { Sound.click(); Modals.close(c.id); }}>
              <div className="ec-top"><span className="ec-icon">{c.icon}</span><b>{c.label}</b><span className={`ec-pts ${c.points < 0 ? 'neg' : c.points === 0 ? 'zero' : ''}`}>{c.points > 0 ? '+' : ''}{c.points} pts</span></div>
              <div className="ec-desc">{c.desc}</div>
              <div className="ec-costs">
                {costs.length ? costs.map(([k, v]) => <span key={k} className="ec-cost">{COST_LABEL[k][0]} −{v} {COST_LABEL[k][1]}</span>) : <span className="ec-cost free">Free</span>}
                <span className="ec-note">→ {c.note}</span>
              </div>
              {!c.available && <div className="ec-why">✗ {c.why}</div>}
            </button>
          );
        })}
      </div>
      <p className="fact">📘 {em.fact}</p>
    </div>
  );
}

const SYS_TABS = ['o2', 'water', 'food', 'energy', 'radiation'];
const UNIT = { o2: 'kg', water: 'L', food: 'kg' };
function SystemsBody({ engine, tab: tab0 }) {
  const [tab, setTab] = useState(SYS_TABS.includes(tab0) ? tab0 : 'o2');
  const P = engine.planet, R = engine.res, S = engine.stats, RP = engine.report;
  const sys = SYSTEMS[tab];
  useEffect(() => { if (engine.report.explainers) engine.report.explainers.add(tab); }, [tab, engine]);
  const fact = useMemo(() => { const f = FACTS[P.id]; return f[Math.floor(Math.random() * f.length)]; }, [P.id, tab]);
  let live = null;
  if (UNIT[tab]) {
    const u = UNIT[tab];
    const rows = Object.entries(engine.flows[tab] || {}).filter(([, v]) => Math.abs(v) >= 0.05).sort((a, b) => b[1] - a[1]);
    const net = rows.reduce((a, [, v]) => a + v, 0);
    const dl = net < -0.01 ? R[tab] / -net : Infinity;
    live = (
      <>
        <div className="sy-flows">
          {rows.length ? rows.map(([k, v]) => <div key={k} className={`sy-flow ${v >= 0 ? 'in' : 'out'}`}><span>{k}</span><b>{v >= 0 ? '+' : '−'}{fmt(Math.abs(v), 1)} {u}/day</b></div>) : <div className="sy-flow"><span>No flow yet: the simulation is just starting.</span></div>}
          <div className={`sy-flow net ${net >= 0 ? 'in' : 'out'}`}><span>Net balance</span><b>{net >= 0 ? '+' : '−'}{fmt(Math.abs(net), 1)} {u}/day</b></div>
        </div>
        <p className="small muted">In store: <b>{fmt(R[tab], 1)} {u}</b> of {STORE_CAP[tab]} {u}{dl < 999 ? <> · runs out in about <b>{Math.floor(dl)} days</b> at this rate</> : ' · stable or growing'}. Mission so far: made {fmt(RP.made[tab], 0)} {u}, used {fmt(RP.used[tab], 0)} {u}{tab === 'water' ? `, of which ${fmt(RP.recycledL, 0)} L came back through the recycler` : ''}.</p>
      </>
    );
  } else if (tab === 'energy') {
    const gen = [], use = [['Habitat life support (heat, air, pumps)', 2]];
    const solar = [...engine.buildings.values()].filter((b) => b.type === 'solar' && b.built);
    if (solar.length) gen.push([`Solar arrays ×${solar.length}`, solar.reduce((a, b) => a + engine.solarOutput(b), 0)]);
    const reac = [...engine.buildings.values()].filter((b) => b.type === 'reactor' && b.built);
    if (reac.length) gen.push([`Fission reactor ×${reac.length}`, reac.reduce((a, b) => a + 10 * engine.bEff(b), 0)]);
    const cnt = {};
    engine.buildings.forEach((b) => { const d = BUILDINGS[b.type]; if (d && d.power < 0 && engine.bEff(b)) cnt[b.type] = (cnt[b.type] || 0) + 1; });
    Object.entries(cnt).forEach(([t, n]) => use.push([`${BUILDINGS[t].name} ×${n}`, -BUILDINGS[t].power * n]));
    live = (
      <>
        <div className="sy-flows">
          {gen.map(([k, v]) => <div key={k} className="sy-flow in"><span>{k}</span><b>+{fmt(v, 1)} kW</b></div>)}
          {use.map(([k, v]) => <div key={k} className="sy-flow out"><span>{k}</span><b>−{fmt(v, 1)} kW</b></div>)}
          <div className={`sy-flow net ${S.prod - S.demand >= 0 ? 'in' : 'out'}`}><span>Net (extra charges the batteries)</span><b>{S.prod - S.demand >= 0 ? '+' : '−'}{fmt(Math.abs(S.prod - S.demand), 1)} kW</b></div>
        </div>
        <p className="small muted">Batteries: <b>{fmt(R.battery, 0)} / {fmt(S.cap, 0)} kWh</b>{S.demand > S.prod ? <> · at this rate they last about <b>{fmt(R.battery / (S.demand - S.prod), 1)} hours</b></> : ''}. Energy generated so far: {fmt(RP.energyKWh, 0)} kWh. Power was fully available {Math.round(100 * RP.powerOkTime / Math.max(0.01, RP.time))}% of the time.</p>
      </>
    );
  } else {
    const sh = engine.habitatShields();
    live = (
      <>
        <div className="sy-flows">
          <div className="sy-flow out"><span>Background dose on {P.name} <em className="tag real">REAL</em></span><b>{P.radiationPerDay} mSv/day</b></div>
          <div className={`sy-flow ${sh >= 2 ? 'in' : 'out'}`}><span>Shields touching the habitat</span><b>{sh} {sh >= 2 ? '(storm dose −90%)' : sh === 1 ? '(storm dose −50%)' : '(no protection)'}</b></div>
          {engine.crew.map((c) => <div key={c.name} className="sy-flow dose"><span>{c.name}{c.status !== 'active' ? ` (${c.status})` : ''}</span><i className="sy-bar"><i style={{ width: `${Math.min(100, c.dose / 6)}%`, background: c.dose > 400 ? '#ff4d4d' : c.dose > 200 ? '#ffc23d' : '#3dff8a' }} /></i><b>{fmt(c.dose, 0)} / 600 mSv</b></div>)}
        </div>
      </>
    );
  }
  return (
    <div className="m-body systems">
      <div className="hb-tabs">{SYS_TABS.map((k) => <button key={k} data-tab={k} className={`btn sm ${tab === k ? 'primary' : ''}`} onClick={() => { Sound.click(); setTab(k); }}>{SYSTEMS[k].icon} {SYSTEMS[k].title}</button>)}</div>
      <p className="sy-need"><b>{sys.icon} What the crew needs:</b> {sys.need}</p>
      <div className="sy-live"><div className="sy-h">📈 Your base right now</div>{live}</div>
      <div className="sy-sci">
        {sys.science.map(([h, t, kind]) => <div key={h} className="sy-item"><b>{h} <em className={`tag ${kind}`}>{kind === 'real' ? 'REAL' : 'GAME'}</em></b><span>{t}</span></div>)}
      </div>
      <p className="sy-tip">💡 <b>Engineer's tip:</b> {sys.tip}</p>
      <p className="fact">{P.id === 'mars' ? '🔴' : '🌕'} <b>Did you know?</b> {fact}</p>
    </div>
  );
}

const DELTA_LABEL = { o2: ['🫁', 'kg O₂'], water: ['💧', 'L'], food: ['🥫', 'kg'], mat: ['🧱', 'kg'], battery: ['🔋', 'kWh'], health: ['❤', '% crew health'] };
function DebriefBody({ dec }) {
  const G = GRADES[dec.grade];
  const deltas = Object.entries(dec.delta || {});
  return (
    <div className="m-body debrief">
      <div className={`db-verdict ${dec.grade}`}><span>{G.icon}</span><div><b>{G.label}</b><small>{dec.title.replace('!', '')} · Day {dec.day}</small></div><span className={`ec-pts ${dec.points < 0 ? 'neg' : dec.points === 0 ? 'zero' : ''}`}>{dec.points > 0 ? '+' : ''}{dec.points} pts</span></div>
      <p className="db-choice">You chose: <b>{dec.choiceIcon} {dec.choice}</b></p>
      <div className="db-sec"><div className="db-h">{dec.grade === 'best' || dec.grade === 'good' ? '✔ Why this worked' : '✘ Why this was a problem'}</div><p>{dec.why}</p></div>
      <div className="db-sec"><div className="db-h">⚙️ Engineering consequence</div><p>{dec.eng}</p></div>
      <div className="db-sec"><div className="db-h">📊 Immediate effect</div>
        <div className="ec-costs">{deltas.length ? deltas.map(([k, v]) => <span key={k} className={`ec-cost ${v > 0 ? 'free' : ''}`}>{DELTA_LABEL[k][0]} {v > 0 ? '+' : '−'}{Math.abs(v)} {DELTA_LABEL[k][1]}</span>) : <span className="ec-cost free">No resources spent</span>}<span className="ec-note">→ {dec.note}</span></div>
      </div>
      {dec.better && <div className="db-sec better"><div className="db-h">💡 A better option was</div><p><b>{dec.better.icon} {dec.better.label}</b> ({GRADES[dec.better.grade].label.toLowerCase()}): {dec.better.why}</p></div>}
    </div>
  );
}

function CodexBody({ engine, focus, card }) {
  const [open, setOpen] = useState(focus && engine.codex.has(focus) ? focus : null);
  const keys = Object.keys(CODEX);
  return (
    <div className="m-body">
      <div id="cx-detail">
        {open ? <div className="cx-d"><h3>{CODEX[open].icon} {CODEX[open].title}</h3><p>{CODEX[open].text}</p></div>
          : <p className="muted">Tap an entry to read it. Unlock more by building things and surviving events. ({engine.codex.size}/{keys.length} found)</p>}
      </div>
      <div className="cx-grid">
        {keys.map((k) => {
          const has = engine.codex.has(k);
          return (
            <button key={k} className={`cx ${has ? '' : 'locked'} ${open === k ? 'open' : ''}`} disabled={!has}
              onClick={() => { Sound.click(); setOpen(k); card.current && card.current.scrollTo({ top: 0, behavior: 'smooth' }); }}>
              <span>{has ? CODEX[k].icon : '🔒'}</span><b>{has ? CODEX[k].title : 'Locked'}</b>
            </button>
          );
        })}
      </div>
    </div>
  );
}
