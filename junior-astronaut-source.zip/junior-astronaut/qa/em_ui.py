import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
import sys
from playwright.sync_api import sync_playwright
R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)
def E(pg, js): return pg.evaluate('() => { const e = window.__ja.engine; ' + js + ' }')

SETUP = '''e.events = []; e.setSpeed(0); e.res.mat = 2000;
  const P = (t,i,j) => { e.ui.buildType = t; e.place(i,j); e.ui.buildType = null; };
  P('oxygen',9,4); P('battery',4,3); P('recycler',8,9); P('lab',9,9); P('fabricator',9,6); P('shield',5,6); P('shield',5,7);
  e.buildings.forEach(b => { if (!b.built) e.completeBuilding(b); }); e.res.mat = 1000; e.res.water = 300; e.res.o2 = 100; e.t = Math.floor(e.t) + 0.5; e.env = e.computeEnv(e.t);'''

def suite(b, planet, mobile):
    tag = f'[{planet.upper()} {"phone" if mobile else "desktop"}]'
    ctx = b.new_context(viewport={'width': 412, 'height': 860} if mobile else {'width': 1440, 'height': 900}, device_scale_factor=2 if mobile else 1, is_mobile=mobile, has_touch=mobile); ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))")
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc.gsfc.nasa.gov' not in (m.location or {}).get('url', '') else None)  # the sandbox cannot reach NASA: the failed request is expected (game falls back to archived data)
    pg.goto(URL); pg.wait_for_timeout(900)
    btn = pg.locator(f'button.launch[data-planet="{planet}"]'); btn.scroll_into_view_if_needed(); (btn.tap if mobile else btn.click)(); pg.wait_for_timeout(3000)
    ok(f'{tag} Briefing explains emergencies & mission points', 'Emergencies:' in pg.inner_text('#modal .m-body'))
    pg.locator('#modal .btn.primary').click(); pg.wait_for_timeout(300)
    E(pg, SETUP); pg.wait_for_timeout(400)
    click = (lambda loc: loc.tap()) if mobile else (lambda loc: loc.click())
    plan = [('dust', 'eva' if planet == 'moon' else 'powerplan'), ('o2fail', 'repair'), ('waterleak', 'replace' if planet == 'mars' else 'reroute'), ('batfail', 'replace'), ('radiation', 'waterwall')]
    for typ, choice in plan:
        before = E(pg, 'return { pts: e.points, mat: e.res.mat, water: e.res.water, o2: e.res.o2, bat: e.res.battery };')
        if typ == 'radiation': E(pg, "e.fireEvent({ type: 'spe_warn', dose: e.planet.id === 'mars' ? 55 : 350 });")
        else: E(pg, f"e.triggerEmergency('{typ}', {{ dur: 3, peak: 0.6 }});")
        pg.wait_for_timeout(500)
        has = pg.locator('#modal .modal-card.emergency').count() == 1
        n = pg.locator('#modal .em-choice').count()
        ok(f'{tag} {typ}: emergency alert opens with description and {n} choices', has and 2 <= n <= 4 and 'EMERGENCY' in pg.inner_text('#modal .em-strip') and len(pg.inner_text('#modal .m-body')) > 150, pg.inner_text('#modal h2'))
        ok(f'{tag} {typ}: every choice shows its costs and points', all(pg.locator('#modal .em-choice').nth(k).locator('.ec-pts').count() == 1 and pg.locator('#modal .em-choice').nth(k).locator('.ec-cost').count() >= 1 for k in range(n)))
        if typ == 'o2fail': pg.screenshot(path=ROOT + f'/qa/results/shots/EM_{planet}_{"m" if mobile else "d"}_o2.png')
        if typ == 'dust': pg.screenshot(path=ROOT + f'/qa/results/shots/EM_{planet}_{"m" if mobile else "d"}_dust.png')
        pts_card = int(pg.locator(f'#modal .em-choice[data-choice="{choice}"] .ec-pts').inner_text().replace(' pts', '').replace('+', ''))
        c = pg.locator(f'#modal .em-choice[data-choice="{choice}"]'); c.scroll_into_view_if_needed(); click(c); pg.wait_for_timeout(500)
        after = E(pg, 'return { pts: e.points, mat: e.res.mat, water: e.res.water, o2: e.res.o2, bat: e.res.battery, dec: e.decisions.length };')
        ok(f'{tag} {typ}: clicking "{choice}" closes the alert and awards {pts_card} points', pg.locator('#modal .modal-card.emergency').count() == 0 and after['pts'] - before['pts'] == pts_card, f"{before['pts']} → {after['pts']}")
        db = pg.locator('#modal .modal-card[data-custom="debrief"]')
        ok(f'{tag} {typ}: a debrief explains the decision (verdict, why, engineering consequence)', db.count() == 1 and db.locator('.db-verdict').count() == 1 and 'engineering consequence' in db.inner_text().lower() and f'{pts_card:+d}'.replace('+0', '0') in db.locator('.db-verdict .ec-pts').inner_text(), db.locator('h2').inner_text() if db.count() else 'no debrief')
        click(pg.locator('#modal .btn.primary')); pg.wait_for_timeout(300)
        ok(f'{tag} {typ}: debrief closes back to the base', pg.locator('#modal').count() == 0)
        if typ == 'o2fail': ok(f'{tag} o2fail: repair cost deducted', before['mat'] - after['mat'] > 40, f"{before['mat']:.0f} → {after['mat']:.0f}")
        if typ == 'radiation':
            ok(f'{tag} radiation: water wall used 60 L', abs((before['water'] - after['water']) - 60) < 1)
            E(pg, "e.fireEvent({ type: 'spe' });"); pg.wait_for_timeout(500)
            ok(f'{tag} radiation: red radiation glow shows during the storm', pg.locator('#rad-overlay.show').count() == 1)
            pg.screenshot(path=ROOT + f'/qa/results/shots/EM_{planet}_{"m" if mobile else "d"}_rad.png')
        if typ == 'dust' and planet == 'moon': ok(f'{tag} dust: lunar dust cloud active in 3D', E(pg, 'return e.lunarDust() > 0;'))
    # points chip / mini
    txt = pg.inner_text('#r-mat') if mobile else pg.inner_text('#r-pts')
    ok(f'{tag} HUD shows mission points', str(E(pg, 'return e.points;')) in txt, txt.replace('\n', ' '))
    # disabled choice
    E(pg, "e.res.mat = 0; e.res.water = 0; e.triggerEmergency('o2fail');"); pg.wait_for_timeout(400)
    off = pg.locator('#modal .em-choice.off'); ok(f'{tag} Unaffordable choices are greyed out with a reason', off.count() >= 2 and 'Not enough' in off.first.inner_text())
    ok(f'{tag} A free fallback choice is offered', pg.locator('#modal .em-choice[data-choice="makedo"]').count() == 1)
    click(pg.locator('#modal .em-choice[data-choice="makedo"]')); pg.wait_for_timeout(400)
    if pg.locator('#modal .btn.primary').count(): click(pg.locator('#modal .btn.primary')); pg.wait_for_timeout(300)
    ok(f'{tag} No runtime errors', not errs, errs[:3])
    ctx.close()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    for arg in sys.argv[1:]:
        pl, kind = arg.split('-'); suite(b, pl, kind == 'phone')
    b.close()
print(f'\n{sum(R)}/{len(R)} emergency UI checks passed')
