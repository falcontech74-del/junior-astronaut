// Offline unit checks for the DONKI loader (node qa/nasa_unit.mjs)
import { archivedData, clusterSEP, loadDonki, NasaData, STRENGTH, normFLR, normCME, normSEP, queryUrl } from '../src/nasa/donki.js';
import { DONKI_ARCHIVE } from '../src/nasa/donki-archive.js';
let pass = 0, fail = 0;
const ok = (n, c, d = '') => { c ? pass++ : fail++; console.log(`${c ? 'PASS' : 'FAIL'} ${n}${d !== '' ? `  [${d}]` : ''}`); };
const a = archivedData('test');
ok('Archive holds real DONKI records (33 flares, 42 CMEs, 59 SEP detections)', a.flares.length === 33 && a.cmes.length === 42 && a.seps.length === 59);
ok('Archive retrieval time recorded', DONKI_ARCHIVE.retrievedAt === '2026-11-14T15:53:59Z');
ok('Every archived record links to its DONKI page', [...a.flares, ...a.cmes, ...a.seps].every((x) => /^https:\/\/ccmc\.gsfc\.nasa\.gov\/DONKI\/view\/(FLR|CME|SEP)\/\d+\/-1$/.test(x.link)));
ok('Every archived record is labelled archived', [...a.flares, ...a.cmes, ...a.seps, ...a.clusters].every((x) => x.src === 'archived'));
ok('Archived queries are official DONKI-API URLs with ≤60-day windows', a.queries.every((q) => { const m = /DONKI-API\/get\/(FLR|CME|SEP)\?startDate=(\S+)&endDate=(\S+)/.exec(q); return m && (Date.parse(m[3]) - Date.parse(m[2])) / 864e5 <= 60; }), a.queries.length);
ok('SEP detections grouped into 12 storms', a.clusters.length === 12, a.clusters.length);
const sep5 = a.clusters.find((c) => c.id === '2026-09-05T15:04:00-FLR-001');
ok('5 Sep 2026 storm: GOES >100 MeV → strong, M1.0 flare, CME 1111 km/s, 41 min warning', sep5 && sep5.strength === 'strong' && sep5.flare.cls === 'M1.0' && sep5.cme.speed === 1111 && sep5.warnMin === 41 && sep5.seps.length === 8);
const x51 = a.clusters.find((c) => c.flare && c.flare.cls === 'X5.1');
ok('11 Nov 2025 X5.1 storm: protons logged before the flare start → no warning time claimed', x51 && x51.warnMin === null && x51.strength === 'strong');
const jun = a.clusters.find((c) => c.id === '2026-06-06T13:40:00-FLR-001');
ok('Model-only detection is "minor" and keeps its MODEL label', jun && jun.strength === 'minor' && /^MODEL/.test(jun.firstInst));
ok('Union of linked parents merges SEPs of the 14 Nov 2025 storm', a.clusters.filter((c) => c.cme && c.cme.id === '2025-11-14T08:00:00-CME-001').length === 1);
ok('Strength factors are 1.25 / 1 / 0.8', STRENGTH.strong.factor === 1.25 && STRENGTH.moderate.factor === 1 && STRENGTH.minor.factor === 0.8);
// rotation
NasaData.data = a; NasaData.used.clear();
const seq = Array.from({ length: 13 }, () => NasaData.nextStorm().id);
ok('Radiation alerts rotate through all 12 real storms before repeating (newest first)', new Set(seq.slice(0, 12)).size === 12 && seq[0] === a.clusters[0].id && seq[12] === a.clusters[0].id);
// normalisers on raw API shapes
const f = normFLR({ flrID: 'X', beginTime: 'b', peakTime: 'p', classType: 'M1.0', instruments: [{ displayName: 'GOES' }], link: 'l', linkedEvents: [{ activityID: 'Y' }] });
const c = normCME({ activityID: 'C', startTime: 't', cmeAnalyses: [{ isMostAccurate: false, speed: 100 }, { isMostAccurate: true, speed: 999.6, halfAngle: 20, type: 'C' }], linkedEvents: null });
const s = normSEP({ sepID: 'S', eventTime: 't', instruments: [{ displayName: 'GOES-P: SEISS >10 MeV' }], linkedEvents: [] });
ok('Raw DONKI fields normalised (most accurate CME analysis used)', f.cls === 'M1.0' && f.linked[0] === 'Y' && c.speed === 1000 && c.linked.length === 0 && s.inst.includes('>10 MeV'));
ok('Query URL format', queryUrl('FLR', '2026-01-01', '2026-02-01') === 'https://ccmc.gsfc.nasa.gov/DONKI-API/get/FLR?startDate=2026-01-01&endDate=2026-02-01');
// loader behaviour with fake fetch
const reset = () => { NasaData.status = 'idle'; NasaData.data = null; };
reset(); let d = await loadDonki({ fetchFn: async () => ({ ok: false, status: 500 }) });
ok('HTTP error → archived with reason', NasaData.status === 'archived' && d.mode === 'archived' && /HTTP 500/.test(d.error));
reset(); d = await loadDonki({ fetchFn: () => Promise.reject(new TypeError('Failed to fetch')) });
ok('Network/CSP block → archived with reason', NasaData.status === 'archived' && d.error === 'Failed to fetch');
reset(); d = await loadDonki({ fetchFn: () => new Promise(() => {}), timeoutMs: 300 });
ok('Hanging API → archived after the timeout', NasaData.status === 'archived' && /no answer within/.test(d.error));
reset(); d = await loadDonki({ fetchFn: async () => ({ ok: true, status: 200, json: async () => ({ error: 'x' }) }) });
ok('Non-array JSON → archived', NasaData.status === 'archived' && /unexpected response/.test(d.error));
reset(); d = await loadDonki({ fetchFn: async () => ({ ok: true, status: 200, json: async () => [] }) });
ok('Live but no SEP anywhere → live status, radiation alerts use archived storms labelled archived', NasaData.status === 'live' && d.clusters.length === 12 && d.clusters.every((x) => x.src === 'archived') && /archived/.test(d.note));
console.log(`\n${pass}/${pass + fail} passed`);
