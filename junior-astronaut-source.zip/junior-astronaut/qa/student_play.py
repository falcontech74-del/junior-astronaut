import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
# Phase 9 player test: a "student" plays complete missions through the real UI (clicks on desktop, taps on phone).
# The student only uses what is on screen: the main menu, mission-length buttons, launch buttons, the ⭐ hint card,
# red/yellow gauges, the build bar, tiles, the info panel's Repair button, pop-ups and their buttons.
# Two play styles:
#   careful: follows the ⭐ hint, reacts to red/yellow gauges, repairs worn buildings, picks the highest-points choice
#   casual : follows the ⭐ hint only, never repairs, always picks the FIRST available emergency choice
# Time is run with the 8× button; between student actions the test advances the same engine.tick() the game loop uses,
# so a 90-day mission takes about a minute instead of 4.5 minutes of software-rendered frames.
import json, random, sys, time
from playwright.sync_api import sync_playwright

R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)

ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']
E = lambda pg, js: pg.evaluate('() => { const e = window.__ja.engine; ' + js + ' }')
RESULTS = []
ACTION_FAILS = []

class Interrupted(Exception):
    pass

def tap_or_click(pg, mobile, loc, guard=False):
    # guard=True: the action is on the game screen; if a pop-up opened meanwhile (the game keeps running), stop
    if guard and pg.locator('#modal').count(): raise Interrupted()
    try:
        loc.scroll_into_view_if_needed(timeout=15000)
        loc.tap(timeout=15000) if mobile else loc.click(timeout=15000)
    except Exception:
        if guard:
            ACTION_FAILS.append(str(loc)[:120]); raise Interrupted()   # skip this turn; counted in the report
        raise

def handle_modals(pg, mobile, persona, log, rng):
    """Deal with whatever pop-up is open, the way a student would. Returns number handled."""
    n = 0
    for _ in range(12):
        if not pg.locator('#modal').count(): break
        title = pg.inner_text('#modal h2') if pg.locator('#modal h2').count() else ''
        choices = pg.locator('#modal .em-choice:not([disabled])')
        if choices.count():
            pts = [int(c.get_attribute('data-pts') or 0) for c in choices.all()] if False else None
            cards = choices.all()
            if persona == 'careful':
                vals = []
                for c in cards:
                    t = c.locator('.ec-pts').inner_text().replace('pts', '').replace('+', '').strip()
                    try: vals.append(int(t))
                    except ValueError: vals.append(0)
                pick = cards[vals.index(max(vals))]
            else:
                pick = cards[0]
            cid = pick.get_attribute('data-choice')
            has_note = pick.locator('.ec-note').count() == 1 and len(pick.locator('.ec-note').inner_text()) > 5
            log['emergencies'].append({'title': title, 'choice': cid, 'note_shown': has_note})
            tap_or_click(pg, mobile, pick)
        elif 'Mission Control Challenge' in title:
            btns = pg.locator('#modal .m-btns .btn').all()
            tap_or_click(pg, mobile, rng.choice(btns)); log['quiz'] += 1
        elif 'Mission Complete' in title or 'Mission Failed' in title or 'Mission failed' in title:
            log['end_title'] = title
            pg.screenshot(path=ROOT + f"/qa/results/shots/student_{log['id']}_end.png")
            return n + 1
        else:
            if 'Decision debrief' in title: log['debriefs'] += 1
            btn = pg.locator('#modal .m-btns .btn.primary')
            if not btn.count(): btn = pg.locator('#modal .m-btns .btn')
            tap_or_click(pg, mobile, btn.first)
        n += 1; log['modals'] += 1
        pg.wait_for_timeout(180)
    return n

def free_tile(pg, t, bad=()):
    """Tiles where the build would be valid, nearest the habitat first, that the student can actually click
    (on screen and not hidden under a panel)."""
    return pg.evaluate("""([t, bad]) => {
      const e = window.__ja.engine, out = [];
      for (let i = 0; i < 14; i++) for (let j = 0; j < 14; j++) {
        const v = e.canPlace(t, i, j); if (!v.ok || bad.includes(i + ',' + j)) continue;
        if (t !== 'ice' && e.ice.has(i + ',' + j)) continue;           // the hint says: save ice tiles for Ice Miners
        const hd = Math.max(i < 6 ? 6 - i : i > 7 ? i - 7 : 0, j < 6 ? 6 - j : j > 7 ? j - 7 : 0);
        if (t === 'shield' && hd !== 1) continue;                       // the goal says: shields must touch the habitat
        const d = Math.hypot(i - 6.5, j - 6.5); out.push([d, i, j]);
      }
      out.sort((a, b) => a[0] - b[0]);
      for (const [, i, j] of out) {
        const [x, y] = window.__ja.tileToScreen(i, j);
        if (x < 4 || y < 4 || x > innerWidth - 4 || y > innerHeight - 4) continue;
        const el = document.elementFromPoint(x, y);
        if (el && el.tagName === 'CANVAS') return [i, j, x, y];
      }
      return out.length ? [-1, out.length] : null;   // valid tiles exist but all are off-screen / under panels
    }""", [t, list(bad)])

def build(pg, mobile, t, log):
    bad = []
    for attempt in range(3):
        r = build_once(pg, mobile, t, log, bad)
        if r is not None: return r
    return False

def build_once(pg, mobile, t, log, bad):
    if not pg.locator(f'.bcard[data-type="{t}"]').count(): return False
    if 'poor' in (pg.get_attribute(f'.bcard[data-type="{t}"]', 'class') or ''): return False
    # like a student: tap the card first, let the view settle (the camera glides to ice for Ice Miners), then look
    if E(pg, 'return e.ui.buildType;') != t:
        tap_or_click(pg, mobile, pg.locator(f'.bcard[data-type="{t}"]'), guard=True); pg.wait_for_timeout(900)
    tile = free_tile(pg, t, bad)
    if tile is None: log['no_tile'].add(t); E(pg, 'e.cancelBuild();'); return False
    if tile[0] == -1:
        log['hidden_tile'].add(t); pg.screenshot(path=ROOT + f"/qa/results/shots/student_{log['id']}_hidden_{t}.png"); E(pg, 'e.cancelBuild();'); return False
    i, j, x, y = tile
    if mobile:
        pg.touchscreen.tap(x, y); pg.wait_for_timeout(250)
        if pg.locator('#bh-ok:not([disabled])').count(): tap_or_click(pg, mobile, pg.locator('#bh-ok'), guard=True)
    else:
        pg.mouse.move(x, y); pg.wait_for_timeout(80); pg.mouse.click(x, y)
    pg.wait_for_timeout(200)
    placed = E(pg, f'return [...e.buildings.values()].some(b => b.type === "{t}" && b.i === {i} && b.j === {j});')
    if placed:
        log['builds'].append(t)
        if pg.locator('#bh-x').count(): tap_or_click(pg, mobile, pg.locator('#bh-x'), guard=True)   # leave build mode with ✕
        return True
    diag = E(pg, 'const s = e.ui.selected != null ? e.buildings.get(e.ui.selected) : null; return { ghost: e.ui.ghost, sel: s ? s.type + "@" + s.i + "," + s.j : null, bt: e.ui.buildType, mat: Math.round(e.res.mat) };')
    log['build_fail'].append(f'{t}@{i},{j} ghost={diag["ghost"]} sel={diag["sel"]} mode={diag["bt"]} mat={diag["mat"]}')
    E(pg, 'e.select(null);')
    bad.append(f'{i},{j}'); return None   # try another tile (a tile hidden behind a 3D building selects that building)

def repair_worn(pg, mobile, log):
    worn = E(pg, 'return [...e.buildings.values()].filter(b => b.built && b.type !== "shield" && b.type !== "lander" && b.cond < 60).map(b => [b.id, b.i, b.j, e.repairCost(b)]);')
    for bid, i, j, cost in worn[:3]:
        if E(pg, 'return e.res.mat;') < cost + 80: break
        x, y = pg.evaluate(f'() => window.__ja.tileToScreen({i}, {j})')
        if pg.evaluate(f'() => {{ const el = document.elementFromPoint({x}, {y}); return !el || el.tagName !== "CANVAS"; }}'): continue
        pg.touchscreen.tap(x, y) if mobile else pg.mouse.click(x, y)
        pg.wait_for_timeout(250)
        btn = pg.locator('#info button', has_text='Repair')
        if btn.count() and btn.first.is_enabled():
            tap_or_click(pg, mobile, btn.first, guard=True); log['repairs'] += 1
        close = pg.locator('#info .x, #info button[aria-label="Close"]')
        if close.count(): tap_or_click(pg, mobile, close.first, guard=True)
        else: E(pg, 'e.select(null);')
        pg.wait_for_timeout(120)

def chip_level(pg, k):
    return pg.get_attribute(f'#r-{k}', 'data-level') or ''

def student_turn(pg, mobile, persona, log):
    if pg.locator('#modal').count(): return
    # both students follow a 🔧 repair prompt in the goals panel: tap it, then press Repair in the info panel
    if pg.locator('button#hint-why').count():
        tap_or_click(pg, mobile, pg.locator('button#hint-why'), guard=True); pg.wait_for_timeout(200)
        btn = pg.locator('#info button', has_text='Repair')
        if btn.count() and btn.first.is_enabled():
            tap_or_click(pg, mobile, btn.first, guard=True); log['repairs'] += 1; log['prompted_repairs'] = log.get('prompted_repairs', 0) + 1
        if pg.locator('#info .x').count(): tap_or_click(pg, mobile, pg.locator('#info .x').first, guard=True)
    h = pg.evaluate("() => { const x = document.querySelector('.bcard.hint'); return x ? x.dataset.type : null; }")
    if h: build(pg, mobile, h, log)
    if persona == 'careful':
        planet = E(pg, 'return e.planet.id;')
        reactions = [('o2', ['oxygen']), ('water', ['recycler', 'ice']), ('food', ['greenhouse']),
                     ('power', ['solar', 'battery'] if planet == 'mars' else ['reactor', 'solar', 'battery'])]
        if chip_level(pg, 'power') in ('warn', 'crit'):
            tap_or_click(pg, mobile, pg.locator('#r-power'), guard=True); pg.wait_for_timeout(150)
            adv = pg.inner_text('#power-advice') if pg.locator('#power-advice').count() else ''
            log['advice_seen'] = log.get('advice_seen', 0) + (1 if adv else 0)
            tap_or_click(pg, mobile, pg.locator('#r-power'), guard=True)
            reactions[-1] = ('power', ['solar', 'battery'] if 'Add Solar Arrays' in adv else ['battery', 'solar'] if 'Battery Banks' in adv else ['reactor', 'battery'] if 'reactor' in adv and 'Solar' not in adv else ['solar', 'battery'])
        for k, opts in reactions:
            if chip_level(pg, k) in ('warn', 'crit'):
                for t in opts:
                    # buildings under construction count too (the student can see them on the map)
                    n_t = E(pg, f'return [...e.buildings.values()].filter(b => b.type === "{t}").length;')
                    building_now = E(pg, f'return [...e.buildings.values()].some(b => b.type === "{t}" && !b.built);')
                    if building_now: continue
                    if t == 'recycler' and n_t >= 1: continue
                    if t == 'ice' and n_t >= 2: continue
                    if t == 'reactor' and n_t >= 2: continue
                    if build(pg, mobile, t, log): log['reactive'].append(t); break
        if int(E(pg, 'return Math.floor(e.t);')) % 4 == 0: repair_worn(pg, mobile, log)

def play(b, planet, days, device, persona, tutorial=False, seed=1):
    ACTION_FAILS.clear()
    mobile = device == 'phone'
    vp = {'width': 390, 'height': 844} if mobile else {'width': 1366, 'height': 768}
    ctx = b.new_context(viewport=vp, is_mobile=mobile, has_touch=mobile, device_scale_factor=2 if mobile else 1)
    st = {'quality': 'low'}   # graphics preset only (the simulation is identical); keeps the software renderer fast
    if not tutorial: st['tutorialDone'] = True
    ctx.add_init_script(f"localStorage.setItem('ja-settings', JSON.stringify({json.dumps(st)}))")
    ctx.route('https://ccmc.gsfc.nasa.gov/**', lambda r: r.abort())   # no internet here: the game uses its labelled archive
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and 'ccmc' not in m.text else None)
    rng = random.Random(seed)
    lid = f'{planet}{days}_{device}_{persona}'
    log = {'id': lid, 'emergencies': [], 'quiz': 0, 'debriefs': 0, 'modals': 0, 'builds': [], 'reactive': [], 'build_fail': [],
           'no_tile': set(), 'hidden_tile': set(), 'repairs': 0, 'end_title': None, 'shortage_days': {}, 'hint_stuck': 0}
    t0 = time.time()
    pg.goto(URL); pg.wait_for_selector('#main-menu', timeout=30000); pg.wait_for_timeout(600)
    # ---- main menu → mission length → planet ----
    tap_or_click(pg, mobile, pg.locator('[data-mm="play"]')); pg.wait_for_timeout(500)
    tap_or_click(pg, mobile, pg.locator(f'.ml-opt[data-days="{days}"]')); pg.wait_for_timeout(200)
    tap_or_click(pg, mobile, pg.locator(f'button.launch[data-planet="{planet}"]'))
    pg.wait_for_selector('#hud', timeout=30000); pg.wait_for_timeout(3200)
    started = E(pg, 'return [e.planet.id, e.days];')
    handle_modals(pg, mobile, persona, log, rng)            # welcome briefing
    if tutorial:
        seen = []
        for _ in range(16):
            st = pg.evaluate("() => { const t = document.querySelector('#tutorial'); return t ? t.dataset.step : null; }")
            if not st: break
            if not seen or seen[-1] != st: seen.append(st)
            if st == 'pick': tap_or_click(pg, mobile, pg.locator('.bcard[data-type="oxygen"]')); pg.wait_for_timeout(600); continue
            if st == 'place':
                tile = free_tile(pg, 'oxygen'); i, j, x, y = tile
                if mobile: pg.touchscreen.tap(x, y); pg.wait_for_timeout(400); pg.locator('#bh-ok').tap()
                else: pg.mouse.click(x, y)
                pg.wait_for_timeout(700); continue
            if st == 'time': tap_or_click(pg, mobile, pg.locator('#speed button[data-s="1"]')); pg.wait_for_timeout(600); continue
            tap_or_click(pg, mobile, pg.locator('#tut-next')); pg.wait_for_timeout(400)
        log['tutorial'] = seen
    # ---- run the mission ----
    tap_or_click(pg, mobile, pg.locator('#speed button[data-s="8"]'))
    speed_ok = E(pg, 'return e.speed;') == 8
    for _ in range(5):                               # pause: the test runs time itself between student turns
        try:
            tap_or_click(pg, mobile, pg.locator('#speed button[data-s="0"]'), guard=True); break
        except Exception:
            handle_modals(pg, mobile, persona, log, rng)
    speed_ok = speed_ok and E(pg, 'return e.speed;') == 0
    last_day = -1; stuck_since = None; last_hint = None
    while True:
        handle_modals(pg, mobile, persona, log, rng)
        if E(pg, 'return e.over;') or log['end_title']:
            pg.wait_for_timeout(400); handle_modals(pg, mobile, persona, log, rng)
            if E(pg, 'return e.over;'): break
        day = E(pg, f'return Math.floor(e.t * {2 if days <= 30 else 1});')
        if day != last_day:
            last_day = day
            try: student_turn(pg, mobile, persona, log)
            except Interrupted: log['interrupted'] = log.get('interrupted', 0) + 1; E(pg, 'e.cancelBuild && e.cancelBuild();')
            except Exception as ex:      # e.g. a card re-rendered between two reads: skip this turn, count it
                log['turn_errors'] = log.get('turn_errors', 0) + 1; E(pg, 'e.cancelBuild && e.cancelBuild();')
            log.setdefault('trace', []).append(E(pg, 'const S = e.stats; return [Math.round(e.t*10)/10, Math.round(e.res.o2), Math.round(e.res.water), Math.round(e.res.food), Math.round(e.res.mat), Math.round(e.res.battery), Math.round(S.prod*10)/10, Math.round(S.demand*10)/10, Math.round(S.habRatio*100)/100, Math.round(e.crew.reduce((a,c)=>a+(c.status==="active"?c.health:0),0)/4), Object.entries(S.flags||{}).filter(([k,v])=>v).map(([k])=>k).join("|")];'))
            for k in ('o2', 'water', 'food'):
                if E(pg, f'return e.res.{k} <= 0;'): log['shortage_days'][k] = log['shortage_days'].get(k, 0) + 0.5
            h = pg.evaluate("() => { const x = document.querySelector('.bcard.hint'); return x ? x.dataset.type : null; }")
            if h and h == last_hint: log['hint_stuck'] = max(log['hint_stuck'], E(pg, 'return e.t;') - (stuck_since or 0))
            else: stuck_since = E(pg, 'return e.t;'); last_hint = h
            log.setdefault('hint_seq', [])
            if h and (not log['hint_seq'] or log['hint_seq'][-1] != h): log['hint_seq'].append(h)
        # the student "thinks" with the game paused (real frames do not advance time), then lets it run for up to
        # half a game day at 8× (15 ticks × 0.1 s × 8 ÷ 24 s per day) using the game's own tick, which stops by itself when a pop-up opens
        E(pg, f'e.speed = 8; for (let k = 0; k < {15 if days <= 30 else 30} && !e.over && !window.__ja.Modals.isOpen(); k++) e.tick(0.1); e.speed = 0;')
        pg.wait_for_timeout(40)
        if time.time() - t0 > 1800: log['timeout'] = True; break
    pg.wait_for_timeout(600)
    end_modal = pg.inner_text('#modal h2') if pg.locator('#modal h2').count() else log['end_title']
    res = E(pg, '''const r = e.result || {}; const s = r.stem || {};
      return { win: !!r.win, alive: e.crewActive(), day: e.t, total: s.total, rank: s.rank, minHealth: e.report.minHealth,
               dose: e.crew.reduce((a, c) => a + c.dose, 0) / 4, points: e.points, quiz: [e.quizScore, e.quizCount],
               goals: [e.objDone.size, e.objectives.length], decisions: e.decisions.length,
               grades: e.decisions.reduce((a, d) => (a[d.grade] = (a[d.grade] || 0) + 1, a), {}),
               cond: Math.round([...e.buildings.values()].filter(b => b.built && b.type !== 'shield' && b.type !== 'lander').reduce((a, b, _, A) => a + b.cond / A.length, 0)),
               shortage: e.report.shortageTime || 0, time: e.report.time || 1 };''')
    # end screen buttons work: "Fly again" restarts the same mission
    again = pg.locator('#modal .m-btns .btn', has_text='Fly again')
    end_buttons = again.count() == 1 and pg.locator('#modal .m-btns .btn', has_text='Title').count() == 1
    out = {'id': lid, 'planet': planet, 'days': days, 'device': device, 'persona': persona, 'started': started, 'speed_ok': speed_ok,
           **res, 'end_modal': end_modal, 'end_buttons': end_buttons, 'errors': errs[:5], 'secs': round(time.time() - t0),
           'builds': len(log['builds']), 'reactive': log['reactive'], 'advice_seen': log.get('advice_seen', 0), 'action_fails': len(ACTION_FAILS), 'interrupted': log.get('interrupted', 0), 'prompted_repairs': log.get('prompted_repairs', 0), 'interrupted': log.get('interrupted', 0), 'turn_errors': log.get('turn_errors', 0), 'repairs': log['repairs'], 'emergencies': len(log['emergencies']),
           'em_notes_all': all(x['note_shown'] for x in log['emergencies']), 'debriefs': log['debriefs'], 'modals': log['modals'],
           'build_fail': log['build_fail'], 'no_tile': sorted(log['no_tile']), 'hidden_tile': sorted(log['hidden_tile']),
           'shortage_days': log['shortage_days'], 'hint_stuck_days': round(log['hint_stuck'], 1), 'hint_seq': log.get('hint_seq', []),
           'tutorial': log.get('tutorial'), 'trace': log.get('trace', []), 'builds_list': log['builds'], 'timeout': log.get('timeout', False), 'em_list': [(x['title'], x['choice']) for x in log['emergencies']]}
    RESULTS.append(out)
    json.dump(out, open(ROOT + f'/qa/results/student_{lid}.json', 'w'), indent=1, default=list)   # saved per mission
    tag = f'[{planet} {days}d {device} {persona}]'
    ok(f'{tag} Menu → length → launch starts the right mission', started == [planet, days], started)
    ok(f'{tag} 8× and pause buttons work', speed_ok)
    if tutorial: ok(f'{tag} Tutorial completes through real actions', out['tutorial'] == ['welcome', 'gauges', 'camera', 'pick', 'place', 'time', 'goals', 'emerg', 'ready'], out['tutorial'])
    ok(f'{tag} Mission reaches an ending screen (no hang)', bool(end_modal) and ('Mission' in end_modal) and not out['timeout'], end_modal)
    ok(f'{tag} No crashes or runtime errors', not errs, errs[:2])
    ok(f'{tag} Every emergency choice showed its consequence before choosing', out['em_notes_all'], out['emergencies'])
    ok(f'{tag} End screen offers Fly again / Title', end_buttons)
    print(f"RESULT {tag} win={out['win']} crew={out['alive']}/4 day={out['day']:.1f} score={out['total']} rank={out['rank']} minHealth={out['minHealth']:.0f} "
          f"dose={out['dose']:.0f} builds={out['builds']} repairs={out['repairs']} em={out['emergencies']} grades={out['grades']} quiz={out['quiz']} goals={out['goals']} "
          f"cond={out['cond']}% shortage={out['shortage_days']} hintStuck={out['hint_stuck_days']}d noTile={out['no_tile']} hidden={out['hidden_tile']} fails={out['build_fail'][:3]} "
          f"reactive={out['reactive'][:8]} {out['secs']}s", flush=True)
    if again.count(): tap_or_click(pg, mobile, again); pg.wait_for_timeout(2500)
    if again.count(): ok(f'{tag} "Fly again" restarts the mission', E(pg, 'return e.t < 0.5 && !e.over;'))
    ctx.close()

if __name__ == '__main__':
    plan = sys.argv[1:] or ['mars-30-desktop-careful-tutorial']
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=CHROME, args=ARGS)
        for k, spec in enumerate(plan):
            parts = spec.split('-')
            play(b, parts[0], int(parts[1]), parts[2], parts[3], tutorial='tutorial' in parts, seed=k + 1)
        b.close()
    json.dump(RESULTS, open(ROOT + '/qa/results/student_' + '_'.join(plan)[:80] + '.json', 'w'), indent=1, default=list)
    print(f'\n{sum(R)}/{len(R)} passed')
