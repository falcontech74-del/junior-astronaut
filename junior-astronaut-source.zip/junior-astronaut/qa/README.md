# Automated tests

Run everything: `npm run build && npm run test:e2e` (Python 3 + `pip install playwright` + Chrome/Chromium;
set `CHROME_PATH` if Chrome is not at `/usr/bin/google-chrome`). The runner starts `scripts/serve.mjs`, which applies the
real `vercel.json` headers, and drives a real browser with clicks and taps. Set `JA_URL=https://<site>/` to test a deployed copy instead.

| File | Covers |
|---|---|
| `nasa_unit.mjs` | DONKI parsing, storm grouping, strength, live/archive fallback, timeout (Node, `npm test`) |
| `deploy_check.py` | HTTP headers vs `vercel.json`, CSP violations, cached assets, Mars + Moon start on the served build and the standalone file |
| `run_engine.py` + `engine_tests.js` | resources, buildings, 30/60/90-day missions |
| `run_long.py` + `long_tests.js` | long-mission balance and win/lose paths |
| `run_em.py` + `em_tests.js` | the 5 emergencies on both worlds |
| `run_stem.py` + `stem_tests.js` | explainers, debriefs, facts, score and ranks |
| `ui_tests.py` | full UI on Mars/Moon × desktop/phone |
| `em_ui.py`, `stem_ui.py` | emergency and learning UI |
| `nasa_ui.py` | NASA live / blocked / HTTP 503 / timeout |
| `p6_ui.py` | loading screen, menu, settings, music, tutorial, credits, demo mode, overlap audit on 7 screen sizes |
| `screenshots.py` | regenerates `docs/screenshots/` |

Results and screenshots from failed runs go to `qa/results/` (git-ignored).
