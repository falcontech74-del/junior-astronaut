import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
import json
from playwright.sync_api import sync_playwright
src = open(ROOT + '/qa/engine_tests.js').read()
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    pg = b.new_page(viewport={'width': 900, 'height': 700}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(URL); pg.wait_for_timeout(800)
    res = pg.evaluate(src)
    passed = sum(r['pass'] for r in res)
    for r in res: print(('PASS ' if r['pass'] else 'FAIL ') + r['name'] + (f"  [{r['detail']}]" if r['detail'] else ''))
    print(f'\n{passed}/{len(res)} passed; page errors: {errs}')
    json.dump(res, open(ROOT + '/qa/results/engine_results.json', 'w'), indent=1)
    b.close()
