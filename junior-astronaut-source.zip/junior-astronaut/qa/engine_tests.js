// Runs inside the page: window.__ja.Engine is the real game engine.
() => {
  const Engine = window.__ja.Engine;
  window.__ja.Modals.open = () => Promise.resolve(0); // auto-answer modals during engine tests
  const out = [];
  const ok = (name, pass, detail = '') => out.push({ name, pass: !!pass, detail: String(detail) });
  const near = (a, b, tol) => Math.abs(a - b) <= tol;
  const BUILD = { solar: 80, battery: 100, reactor: 420, oxygen: 150, ice: 150, recycler: 120, greenhouse: 200, shield: 40, fabricator: 180, lab: 200, comms: 120 };
  const HOURS = { solar: 6, battery: 6, reactor: 20, oxygen: 12, ice: 12, recycler: 8, greenhouse: 18, shield: 4, fabricator: 12, lab: 12, comms: 8 };
  const fresh = (p, t) => { const e = new Engine(p, 30); e.events = []; if (t != null) e.t = t; e.env = e.computeEnv(e.t); return e; };
  const run = (e, days, dt = 0.005) => { const n = Math.round(days / dt); for (let k = 0; k < n; k++) { e.t += dt; e.env = e.computeEnv(e.t); e.step(dt); } };
  const snap = (e) => ({ ...e.res });
  const place = (e, t, i, j) => { e.ui.buildType = t; const ok2 = e.place(i, j); e.ui.buildType = null; return ok2; };
  const finish = (e) => e.buildings.forEach((b) => { if (!b.built) e.completeBuilding(b); });
  const off = (e, type) => e.buildings.forEach((b) => { if (b.type === type) b.on = false; });

  // ---- 1. crew consumption (all producers off, Moon sunlit so power is stable) ----
  { const e = fresh('moon', 2); off(e, 'greenhouse'); e.res.battery = 50; const a = snap(e); run(e, 1);
    ok('Consumption: O₂ 0.84 kg × 4 crew per day', near(a.o2 - e.res.o2, 3.36, 0.03), (a.o2 - e.res.o2).toFixed(3));
    ok('Consumption: water 3.5 L × 4 crew per day (no recycler)', near(a.water - e.res.water, 14, 0.1), (a.water - e.res.water).toFixed(2));
    ok('Consumption: food 1.2 kg × 4 crew per day', near(a.food - e.res.food, 4.8, 0.05), (a.food - e.res.food).toFixed(2)); }

  // ---- 2. every building: placement cost, build time, functionality ----
  const spots = { solar: [3, 3], battery: [4, 3], reactor: [12, 12], oxygen: [9, 4], ice: null, recycler: [8, 9], greenhouse: [3, 9], shield: [5, 6], fabricator: [9, 6], lab: [9, 9], comms: [10, 12] };
  for (const p of ['mars', 'moon']) {
    for (const t of Object.keys(BUILD)) {
      const e = fresh(p, p === 'mars' ? 0.3 : 2); e.res.mat = 1000;
      const [i, j] = t === 'ice' ? e.iceTiles[0] : spots[t];
      const before = e.res.mat;
      const placed = place(e, t, i, j);
      const b = [...e.buildings.values()].find((x) => x.type === t && x.i === i && x.j === j);
      ok(`[${p}] ${t}: placed and cost ${BUILD[t]} kg`, placed && b && before - e.res.mat === BUILD[t], `paid ${before - e.res.mat}`);
      // build time with 4 crew = buildHours
      let days = 0; while (!b.built && days < 3) { e.t += 0.005; days += 0.005; e.env = e.computeEnv(e.t); e.step(0.005); }
      ok(`[${p}] ${t}: built in ${HOURS[t]} h`, b.built && near(days * 24, HOURS[t], 0.3), `${(days * 24).toFixed(1)} h`);
    }
  }
  // functionality checks (Moon in sunlight: constant solar power, so deltas are clean)
  const delta = (setup, measureDays = 1, planet = 'moon', t0 = 2) => {
    const a0 = fresh(planet, t0); a0.res.mat = 1500; a0.res.water = 500; off(a0, 'greenhouse'); setup(a0); finish(a0); a0.res.battery = a0.stats.cap; const A = snap(a0); run(a0, measureDays);
    const b0 = fresh(planet, t0); b0.res.mat = 1500; b0.res.water = 500; off(b0, 'greenhouse'); b0.res.battery = 50; const B = snap(b0); run(b0, measureDays);
    const d = {}; for (const k of ['o2', 'water', 'food', 'mat', 'science']) d[k] = (a0.res[k] - A[k]) - (b0.res[k] - B[k]);
    return { d, e: a0 };
  };
  { const e = fresh('moon', 2); place(e, 'solar', 3, 3); finish(e); run(e, 0.01); ok('Solar (Moon, sunlit): 2 arrays → 34 kW', near(e.stats.prod, 34, 0.1), e.stats.prod.toFixed(2)); }
  { const e = fresh('mars', 0.5); run(e, 0.005); ok('Solar (Mars, noon): 1 array → 7.4 kW', near(e.stats.prod, 7.4, 0.15), e.stats.prod.toFixed(2)); }
  { const e = fresh('mars', 0.0); run(e, 0.005); ok('Solar (Mars, midnight): 0 kW', e.stats.prod < 0.01, e.stats.prod.toFixed(2)); }
  { const e = fresh('moon', 2); place(e, 'battery', 4, 3); finish(e); run(e, 0.01); ok('Battery: storage 50 → 170 kWh', near(e.stats.cap, 170, 0.1), e.stats.cap.toFixed(2)); }
  { const e = fresh('moon', 2); e.res.mat = 2000; ok('Reactor: refused 3 tiles from habitat', !e.canPlace('reactor', 9, 6).ok, e.canPlace('reactor', 9, 6).why);
    ok('Reactor: allowed 4 tiles from habitat', e.canPlace('reactor', 11, 6).ok); place(e, 'reactor', 11, 6); finish(e); run(e, 0.01); ok('Reactor: +10 kW (17 solar + 10)', near(e.stats.prod, 27, 0.1), e.stats.prod.toFixed(2)); }
  { const { d } = delta((e) => place(e, 'oxygen', 9, 4), 1, 'moon'); ok('Oxygen generator (Moon): +4 kg O₂/day', near(d.o2, 4, 0.05), d.o2.toFixed(2)); ok('Oxygen generator (Moon): uses 4.5 L water/day', near(d.water, -4.5, 0.05), d.water.toFixed(2)); }
  { const { d } = delta((e) => { place(e, 'oxygen', 9, 4); place(e, 'reactor', 12, 12); }, 1, 'mars', 0.3); ok('Oxygen generator (Mars, reactor power): +4 kg O₂/day, no water', near(d.o2, 4, 0.05) && near(d.water, 0, 0.05), `${d.o2.toFixed(2)} O₂, ${d.water.toFixed(2)} L`); }
  { const e = fresh('moon', 2); e.res.mat = 1000; ok('Ice miner: refused off ice', !e.canPlace('ice', 5, 3).ok, e.canPlace('ice', 5, 3).why); }
  { const { d } = delta((e) => place(e, 'ice', ...e.iceTiles[0])); ok('Ice miner: +25 L/day (20 × 1.25 geologist bonus)', near(d.water, 25, 0.1), d.water.toFixed(2)); }
  { const { d } = delta((e) => place(e, 'recycler', 8, 9)); ok('Water recycler: saves 12.6 L/day for 4 crew (90% of 14)', near(d.water, 12.6, 0.1), d.water.toFixed(2)); }
  { const { d } = delta((e) => place(e, 'greenhouse', 3, 9)); ok('Greenhouse: +3.25 kg food/day (2.6 × 1.25 botanist)', near(d.food, 3.25, 0.05), d.food.toFixed(2)); ok('Greenhouse: +0.4 kg O₂ and −2 L water/day', near(d.o2, 0.4, 0.02) && near(d.water, -2, 0.05), `${d.o2.toFixed(2)} / ${d.water.toFixed(2)}`); }
  { const { d } = delta((e) => place(e, 'fabricator', 9, 6)); ok('ISRU fabricator: +50 kg materials/day', near(d.mat, 50, 0.5), d.mat.toFixed(1)); }
  { const { d } = delta((e) => place(e, 'lab', 9, 9)); ok('Science lab: +10 science/day', near(d.science, 10, 0.1), d.science.toFixed(2)); }
  { const e = fresh('moon', 2); place(e, 'comms', 10, 12); finish(e); ok('Comms dish: first cargo scheduled 2 days later', near(e.nextResupply, e.t + 2, 0.01));
    run(e, 2.05); const lander = e.effects.find((x) => x.kind === 'lander'); ok('Comms dish: cargo lander arrives', !!lander); const m = e.res.mat; lander && lander.onDone(); ok('Cargo delivers +120 kg materials', near(e.res.mat - m, 120, 0.01)); ok('Next cargo 6 days later', near(e.nextResupply - e.t, 6, 0.05), (e.nextResupply - e.t).toFixed(2)); }
  { const run2 = (shields) => { const e = fresh('moon', 2); e.res.mat = 1000; if (shields) { place(e, 'shield', 5, 6); place(e, 'shield', 5, 7); finish(e); } e.fireEvent({ type: 'spe', dose: 350 }); run(e, 0.6); return e.crew[0].dose; };
    const d0 = run2(false), d2 = run2(true); ok('Regolith shields: 2 touching habitat cut storm dose ≈ 90%', d2 < d0 * 0.15, `${d0.toFixed(0)} → ${d2.toFixed(0)} mSv`); }

  // ---- 3. power priority, health, failure ----
  { const e = fresh('mars', 0.0); e.res.battery = 0; place(e, 'lab', 9, 9); finish(e); run(e, 0.05);
    ok('Load shedding: no power → life support fails, cold flag set', e.stats.flags.cold && e.stats.habRatio < 0.5, `habRatio ${e.stats.habRatio}`);
    const h = e.crew[0].health; run(e, 0.2); ok('No power: crew health drops', e.crew[0].health < h, `${h.toFixed(1)} → ${e.crew[0].health.toFixed(1)}`); }
  { const e = fresh('moon', 16); e.res.mat = 9000; place(e, 'reactor', 12, 12); [[9,9],[10,9],[11,9],[9,10],[10,10],[11,10],[9,11],[10,11]].forEach(([i, j]) => place(e, 'lab', i, j)); finish(e); e.res.battery = 0; run(e, 0.02);
    ok('Load shedding: in darkness, reactor keeps life support at 100% while 8 labs share the rest', e.stats.habRatio === 1 && near(e.stats.ratio, (e.stats.prod - 2) / (e.stats.demand - 2), 0.01) && e.stats.ratio < 1, `${e.stats.prod.toFixed(1)} kW made, ${e.stats.demand.toFixed(1)} kW wanted → hab ${e.stats.habRatio.toFixed(2)}, others ${e.stats.ratio.toFixed(2)}`); }
  { const e = fresh('moon', 2); e.res.o2 = 0; run(e, 0.5); ok('No oxygen: crew lost within ~1.5 days, mission failed', e.crewActive() < 4 || e.crew[0].health < 70, `health ${e.crew[0].health.toFixed(0)}`);
    run(e, 1.5); ok('Mission failure triggers when all crew are lost', e.over && e.result && e.result.win === false, JSON.stringify(e.result)); }
  { const e = fresh('moon', 2); e.res.water = 0; e.res.mat = 0; run(e, 0.5); ok('No water: health falls (−30/day)', e.crew[0].health < 100 - 10, e.crew[0].health.toFixed(1)); }
  { const e = fresh('moon', 2); e.res.food = 0; run(e, 0.5); ok('No food: health falls slowly (−12/day)', e.crew[0].health < 100 && e.crew[0].health > 90, e.crew[0].health.toFixed(1)); }
  { const e = fresh('moon', 2); e.crew[0].dose = 599.9; run(e, 0.2); ok('Radiation: crew evacuated at 600 mSv career limit', e.crew[0].status === 'evacuated', e.crew[0].status); }
  { const e = fresh('moon', 2); e.crew.forEach((c) => (c.health = 50)); run(e, 1); ok('Health recovers when needs are met (+7.5/day with commander)', near(e.crew[1].health, 57.5, 0.2), e.crew[1].health.toFixed(1)); }

  // ---- 4. events ----
  { const e = fresh('mars', 0.495); run(e, 0.005); const p0 = e.stats.prod; e.fireEvent({ type: 'duststorm', dur: 4, peak: 0.88 }); run(e, 0.8); e.t = 1.495; e.env = e.computeEnv(e.t); run(e, 0.005);
    ok('Dust storm (Mars): solar output cut up to ~72%', e.stats.prod < p0 * 0.4, `${p0.toFixed(2)} → ${e.stats.prod.toFixed(2)} kW`); }
  { const e = fresh('mars', 0.3); run(e, 5); const dirty = [...e.buildings.values()].find((b) => b.type === 'solar').dust; e.fireEvent({ type: 'dustdevil' });
    ok('Dust accumulates on Mars panels; dust devil cleans them', dirty < 0.97 && [...e.buildings.values()].find((b) => b.type === 'solar').dust === 1, `dust ${dirty.toFixed(3)} → 1`); }
  { const e = fresh('moon', 2); run(e, 5); ok('No dust build-up on the Moon (no wind)', [...e.buildings.values()].find((b) => b.type === 'solar').dust === 1); }
  { const e = fresh('mars', 0.5); e.res.mat = 1000; place(e, 'shield', 3, 7); finish(e); e.fireEvent({ type: 'quake' }); const dmg = [...e.buildings.values()].filter((b) => b.cond < 100).length; ok('Quake damages 2 buildings', dmg === 2, dmg); }
  { const e = fresh('mars', 0.5); e.fireEvent({ type: 'failure' }); const f = [...e.buildings.values()].find((b) => b.cond === 20); ok('Equipment failure drops a system to 20%', !!f, f && f.type);
    const c = e.repairCost(f); const m = e.res.mat; e.repair(f); ok('Repair restores 100% and costs materials (engineer −40%)', f.cond === 100 && near(m - e.res.mat, c, 0.01), `cost ${c}`); }
  { const e = fresh('moon', 2); e.fireEvent({ type: 'meteor' }); const m = e.effects.find((x) => x.kind === 'meteor'); m.onDone(); const hit = [...e.buildings.values()].find((b) => b.cond < 100);
    ok('Micrometeoroid damages a building by 45–65%', hit && hit.cond <= 55 && hit.cond >= 35, hit && `${hit.type} ${hit.cond.toFixed(0)}%`); }
  { const e = fresh('moon', 2); e.res.mat = 1000; [[3, 5], [3, 7], [5, 5], [5, 6], [5, 7], [4, 5], [4, 7]].forEach(([i, j]) => place(e, 'shield', i, j)); finish(e);
    const sol = [...e.buildings.values()].find((b) => b.type === 'solar'); ok('Shield next to a building is detected', e.shieldedNear(sol));
    e.buildings.forEach((b) => { if (b.type !== 'solar' && b.type !== 'shield') b.built = false; }); e.fireEvent({ type: 'meteor' }); e.effects.find((x) => x.kind === 'meteor').onDone();
    ok('Shielded building takes only 12% impact damage', near(sol.cond, 88, 0.01), sol.cond); }
  { const e = fresh('moon', 2); const b = [...e.buildings.values()].find((x) => x.type === 'solar'); const m = e.res.mat; e.recycle(b); ok('Recycle refunds 50% (solar → +40 kg)', e.res.mat - m === 40 && !e.buildings.has(b.id)); }
  { const e = fresh('mars', 0.5); const b = [...e.buildings.values()].find((x) => x.type === 'greenhouse'); e.toggle(b); const a = snap(e); run(e, 0.5); ok('Switching a building off stops its output', a.food - e.res.food > 2.3, (a.food - e.res.food).toFixed(2)); }

  // ---- 5. day/night and lunar cycle ----
  { const e = fresh('mars', 0); const f = []; for (let k = 0; k < 24; k++) f.push(e.computeEnv(k / 24).sunFactor);
    ok('Mars: Sun rises and sets every sol (12 h of light)', f.filter((x) => x > 0).length >= 11 && f.filter((x) => x > 0).length <= 13, f.filter((x) => x > 0).length); }
  { const e = fresh('moon', 0); const P = e.planet; let lit = 0, n = 0; const az0 = e.computeEnv(0).az, az1 = e.computeEnv(P.lunarDay).az;
    for (let t = 0; t < P.lunarDay; t += 0.05) { lit += e.computeEnv(t).sunFactor; n++; }
    ok('Moon: Sun circles the horizon once per 29.53 Earth days', near(az1 - az0, Math.PI * 2, 1e-6), ((az1 - az0) / Math.PI * 180).toFixed(1) + '°');
    ok('Moon: sunlit ≈ 80% of a lunar day (real rim sites 80–90%)', near(lit / n, 0.8, 0.03), (lit / n * 100).toFixed(1) + '%');
    ok('Moon: dark during Days 13–19, lit on Days 1–12 and 20–30', e.computeEnv(16).sunFactor < 0.01 && e.computeEnv(5).sunFactor > 0.99 && e.computeEnv(25).sunFactor > 0.99);
    ok('Moon: no 24-hour day/night (constant light on Day 5)', [5, 5.25, 5.5, 5.75].every((t) => e.computeEnv(t).sunFactor > 0.99)); }

  // ---- 6. Mars vs Moon environment values ----
  { const m = fresh('mars', 0.5), l = fresh('moon', 2);
    ok('Different gravity (3.71 vs 1.62 m/s²)', m.planet.gravity === 3.71 && l.planet.gravity === 1.62);
    ok('Different surface radiation (0.67 vs 1.37 mSv/day)', m.planet.radiationPerDay === 0.67 && l.planet.radiationPerDay === 1.37);
    const mt = new Engine('mars', 90).events.map((x) => x.type), lt = new Engine('moon', 90).events.map((x) => x.type);
    ok('Mars-only events: dust storms + dust devils', mt.includes('duststorm') && mt.includes('dustdevil') && !lt.includes('duststorm'));
    ok('Moon-only events: dark spells; Moon gets more impacts and solar storms than Mars', lt.includes('dark') && lt.filter((x) => x === 'meteor').length > mt.filter((x) => x === 'meteor').length && lt.filter((x) => x === 'spe').length > mt.filter((x) => x === 'spe').length, `meteors ${mt.filter((x) => x === 'meteor').length} vs ${lt.filter((x) => x === 'meteor').length}`); }

  // ---- 7. objectives ----
  { const e = fresh('moon', 2); e.res.mat = 1000; const m = e.res.mat; place(e, 'oxygen', 9, 4); finish(e); e.checkObjectives(); ok('Goal reward: Oxygen Generator goal pays +120 kg', e.objDone.has('oxygen') && near(e.res.mat - (m - 150), 120, 0.01)); }

  // ---- 8. full 30-day runs ----
  const strat = {
    mars: ['oxygen', 'solar', 'ice', 'recycler', 'solar', 'battery', 'solar', 'shield', 'shield', 'fabricator', 'solar', 'battery', 'comms', 'lab', 'greenhouse', 'solar'],
    moon: ['oxygen', 'ice', 'recycler', 'shield', 'shield', 'reactor', 'greenhouse', 'lab', 'comms', 'battery', 'fabricator'],
  };
  const free = (e, t) => { for (let r = 1; r < 8; r++) for (let i = 0; i < 14; i++) for (let j = 0; j < 14; j++) {
    const hd = Math.max(i < 6 ? 6 - i : i > 7 ? i - 7 : 0, j < 6 ? 6 - j : j > 7 ? j - 7 : 0); if (hd !== r) continue;
    if (t === 'ice' && !e.ice.has(i + ',' + j)) continue; if (t !== 'ice' && e.ice.has(i + ',' + j)) continue;
    if (t === 'shield' && r !== 1) continue; if (t !== 'shield' && r < 2) continue; if (e.canPlace(t, i, j).ok) return [i, j]; } return null; };
  for (const p of ['mars', 'moon']) {
    for (const mode of ['idle', 'plan']) {
      const e = new Engine(p, 30); let k = 0; e.autoDecide = (em) => em.choices.filter((c) => c.available).sort((a, b) => b.points - a.points)[0].id;
      while (!e.over && e.t < 31) {
        if (mode === 'plan' && k < strat[p].length) { const pos = free(e, strat[p][k]); if (pos) { place(e, strat[p][k], ...pos); k++; } }
        for (let s = 0; s < 10 && !e.over; s++) { e.t += 0.01; e.env = e.computeEnv(e.t); e.step(0.01); }
        e.effects.forEach((x) => { if (x.onDone && !x.done) { x.done = true; x.onDone(); } });
      }
      if (mode === 'idle') ok(`[${p}] 30-day run, building nothing → mission fails`, e.over && !e.result.win, `lost on day ${e.t.toFixed(1)}`);
      else ok(`[${p}] 30-day run, sensible build order → mission complete`, e.over && e.result.win, `crew ${e.result.alive}/4, score ${e.result.score}, min health ${Math.min(...e.crew.map((c) => c.health)).toFixed(0)}`);
    }
  }
  // ---- 9. ⭐ build suggestion (Phase 9): urgent needs first, then the mission goals ----
  { const e = fresh('mars', 1); e.rates.water = -14; e.res.water = 30;
    const s = e.suggestion(); ok('⭐ Water running out with no recycler → suggests a Water Recycler, with a reason', s && s.type === 'recycler' && /Water runs out/.test(s.why), s && s.why); }
  { const e = fresh('mars', 1); e.res.mat = 1000; place(e, 'recycler', 8, 9); e.rates.water = -14; e.res.water = 30;
    const s = e.suggestion(); ok('⭐ …with a recycler already → suggests an Ice Miner on a blue tile', s && s.type === 'ice' && /blue ice tile/.test(s.why), s && s.why); }
  { const e = fresh('mars', 1); e.rates.o2 = -3; e.res.o2 = 6;
    const s = e.suggestion(); ok('⭐ Oxygen running out → suggests an Oxygen Generator', s && s.type === 'oxygen', s && s.why); }
  { const e = fresh('moon', 6); const s = e.suggestion();
    ok('⭐ Moon, no reactor, darkness within a week → suggests saving for a Fission Reactor', s && s.type === 'reactor' && /Darkness from Day 14/.test(s.why), s && s.why); }
  { const e = fresh('moon', 2); const s = e.suggestion(); ok('⭐ Moon, darkness still far away → no urgent suggestion (follow the goals)', s === null || s.type !== 'reactor', s && s.why); }
  { const e = fresh('mars', 4); const hab = e.buildings.get(1); hab.cond = 40; const s = e.suggestion();
    ok('⭐ Leaking habitat → repair prompt that selects the habitat', s && s.repair === 1 && /leaking air/.test(s.why), s && s.why); }
  { const e = fresh('mars', 4); e.res.mat = 1000; place(e, 'oxygen', 9, 4); finish(e); const g = [...e.buildings.values()].find((b) => b.type === 'oxygen'); g.cond = 35;
    const s = e.suggestion(); ok('⭐ Worn Oxygen Generator (35%) → repair prompt with the cost', s && s.repair === g.id && /35%/.test(s.why) && /kg/.test(s.why), s && s.why); }
  { const e = fresh('mars', 4); e.res.mat = 1000; place(e, 'oxygen', 9, 4); finish(e); const g = [...e.buildings.values()].find((b) => b.type === 'oxygen'); g.cond = 0; e.res.mat = 10;
    const s = e.suggestion(); ok('⭐ Broken Oxygen Generator and too few materials → explains how to get materials (quizzes, recycling)', s && s.repair === g.id && /recycle/.test(s.why), s && s.why); }
  { const e = fresh('mars', 1); e.res.mat = 5000;
    ok('Build tip: a shield away from the habitat is flagged (it will not protect the crew)', /does not touch the habitat/.test(e.canPlace('shield', 2, 2).why) && e.canPlace('shield', 5, 6).why === '', e.canPlace('shield', 2, 2).why);
    for (let i = 5; i <= 8; i++) for (let j = 5; j <= 8; j++) if (e.occ[i][j] == null) place(e, 'lab', i, j);
    const s = e.suggestion(); ok('⭐ All tiles around the habitat used and the storm-shelter goal open → explains to free a tile', s && /touch the habitat/.test(s.why), s && s.why); }
  const basics = (e) => { e.res.mat = 2000; place(e, 'oxygen', 9, 4); place(e, 'recycler', 8, 9); const [i, j] = e.iceTiles[0]; place(e, 'ice', i, j); finish(e); };
  { const e = fresh('mars', 4); e.res.mat = 400; const s = e.suggestion();
    ok('⭐ Basics first: no Oxygen Generator / Recycler / Ice Miner yet → follow the goals (no power or fabricator advice)', s === null, s && s.why); }
  { const e = fresh('mars', 2); basics(e); ['lab', 'greenhouse', 'fabricator'].forEach((t, k) => place(e, t, 3 + k, 3)); finish(e); run(e, 0.6);
    const s = e.suggestion(); ok('⭐ Mars power ran out with too little solar → suggests Solar Arrays (not more batteries)', s && s.type === 'solar', s && s.why);
    ok('⚡ Power advice agrees (add Solar Arrays first)', /Solar Arrays/.test(e.powerAdvice()) || e.stats.prod - e.stats.demand >= 0, e.powerAdvice()); }
  { const e = fresh('mars', 4); basics(e); e.res.mat = 400; const s = e.suggestion();
    ok('⭐ Basics built, no fabricator and materials under 450 kg → suggests an ISRU Fabricator while it is affordable', s && s.type === 'fabricator', s && s.why); }
  return out;
}
