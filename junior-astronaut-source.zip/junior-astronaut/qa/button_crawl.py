import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
# Phase 9: press every visible button / tab / toggle on the title screen and in a Mars and a Moon mission, on desktop,
# tablet and phone. Each press must not crash, every pop-up it opens must close again, and the screen must stay usable.
# Also measures touch-target sizes and the smallest text on phones.
import json, sys
from playwright.sync_api import sync_playwright

R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)

ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']
VIEWS = {'desktop': ({'width': 1366, 'height': 768}, False), 'tablet': ({'width': 768, 'height': 1024}, True), 'phone': ({'width': 390, 'height': 844}, True)}

def press(pg, touch, loc):
    loc.scroll_into_view_if_needed(timeout=8000)
    loc.tap(timeout=8000) if touch else loc.click(timeout=8000)

def close_modal(pg, touch):
    for _ in range(6):
        if not pg.locator('#modal').count(): return True
        btns = pg.locator('#modal .m-btns .btn')
        closer = None
        for lab in ('Close', 'Resume', 'Continue', 'Got it', 'OK'):
            c = pg.locator('#modal .m-btns .btn', has_text=lab)
            if c.count(): closer = c.first; break
        if closer is None and pg.locator('#modal .em-choice:not([disabled])').count(): closer = pg.locator('#modal .em-choice:not([disabled])').first
        if closer is None and btns.count(): closer = btns.first
        if closer is None: pg.keyboard.press('Escape'); pg.wait_for_timeout(200); continue
        press(pg, touch, closer); pg.wait_for_timeout(250)
    return not pg.locator('#modal').count()

def modal_inner(pg, touch, stats):
    """press every tab/button inside an open pop-up that is not a closing button"""
    sel = '#modal button:not(.m-btns .btn):not(.em-choice):not([disabled])'
    n = pg.locator(sel).count()
    for k in range(min(n, 30)):
        loc = pg.locator(sel).nth(k)
        if not loc.is_visible(): continue
        try:
            press(pg, touch, loc); pg.wait_for_timeout(120); stats['inner'] += 1
            if not pg.locator('#modal').count(): break         # a button in the pop-up closed it (fine)
        except Exception as e:
            stats['fail'].append('modal-inner: ' + str(e)[:80])

def crawl(pg, touch, sel, label, stats, skip=()):
    n = pg.locator(sel).count()
    for k in range(n):
        loc = pg.locator(sel).nth(k)
        try:
            if not loc.is_visible(): continue
            name = (loc.get_attribute('id') or loc.get_attribute('data-type') or loc.get_attribute('data-s') or loc.get_attribute('data-mm') or loc.inner_text()[:24]).replace('\n', ' ')
        except Exception:
            continue
        if any(s in name for s in skip): continue
        try:
            press(pg, touch, loc); pg.wait_for_timeout(220); stats['pressed'].append(f'{label}:{name}')
            if pg.locator('#modal').count():
                stats['modals'] += 1; modal_inner(pg, touch, stats)
                if not close_modal(pg, touch): stats['fail'].append(f'{label}:{name} pop-up would not close')
            if pg.locator('#bh-x').count(): press(pg, touch, pg.locator('#bh-x'))   # leave build mode
        except Exception as e:
            stats['fail'].append(f'{label}:{name} ' + str(e).split('\n')[0][:90])

def sizes(pg):
    return pg.evaluate("""() => {
      const els = [...document.querySelectorAll('button, [role=button], a, .chip.tap, .ml-opt, .bcard, .sh')].filter(e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && r.bottom > 0 && r.top < innerHeight; });
      const small24 = [], small44 = [];
      for (const e of els) { const r = e.getBoundingClientRect(); const m = Math.min(r.width, r.height); const n = (e.id || e.className || e.tagName).toString().slice(0, 30) + ':' + (e.innerText || '').trim().slice(0, 14);
        if (m < 24) small24.push(n + ' ' + Math.round(r.width) + 'x' + Math.round(r.height)); else if (m < 44) small44.push(n); }
      let minFont = 99, minEl = '';
      for (const e of document.querySelectorAll('body *')) { if (!e.childNodes.length || ![...e.childNodes].some(c => c.nodeType === 3 && c.textContent.trim())) continue;
        const r = e.getBoundingClientRect(); if (r.width === 0 || r.bottom < 0 || r.top > innerHeight) continue;
        const f = parseFloat(getComputedStyle(e).fontSize); if (f < minFont) { minFont = f; minEl = (e.id || e.className || e.tagName).toString().slice(0, 30) + ':' + e.textContent.trim().slice(0, 20); } }
      return { total: els.length, small24, small44: small44.length, minFont, minEl };
    }""")

def run(b, view):
    vp, touch = VIEWS[view]
    ctx = b.new_context(viewport=vp, is_mobile=touch, has_touch=touch, device_scale_factor=2 if touch else 1)
    ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true, quality: 'low' }))")
    ctx.route('https://ccmc.gsfc.nasa.gov/**', lambda r: r.abort())
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('popup', lambda p: p.close())                        # external source links open new tabs: close them
    pg.goto(URL); pg.wait_for_selector('#main-menu', timeout=30000); pg.wait_for_timeout(600)
    tag = f'[{view}]'
    st = {'pressed': [], 'fail': [], 'modals': 0, 'inner': 0}
    # ---- title screen (tutorial/demo/launch start a mission: covered by the mission tests) ----
    crawl(pg, touch, '#title button:not(.launch), #title .ml-opt', 'title', st, skip=('tutorial', 'demo'))
    sz_title = sizes(pg)
    ok(f'{tag} Title screen: every button/option pressed, pop-ups close, no errors', not st['fail'] and not errs, f"{len(st['pressed'])} pressed, {st['modals']} pop-ups, {st['inner']} tabs; {st['fail'][:2]} {errs[:1]}")
    results = {'title': dict(st), 'title_sizes': sz_title}
    for planet in ['mars', 'moon']:
        st = {'pressed': [], 'fail': [], 'modals': 0, 'inner': 0}
        pg.evaluate(f"() => window.__ja.start('{planet}', 30)"); pg.wait_for_selector('#hud', timeout=30000); pg.wait_for_timeout(3200)
        close_modal(pg, touch)
        pg.evaluate("() => { const e = window.__ja.engine; e.setSpeed(0); e.events = []; e.res.mat = 3000; }")
        crawl(pg, touch, '#speed button', 'speed', st)
        pg.evaluate("() => window.__ja.engine.setSpeed(0)")
        crawl(pg, touch, '#topbar .tools button', 'tools', st, skip=('btn-menu',))
        crawl(pg, touch, '#resources .chip', 'gauge', st)
        crawl(pg, touch, '#objectives .sh, #crew .sh', 'panel', st)
        crawl(pg, touch, '#objectives .sh, #crew .sh', 'panel', st)       # toggle back
        crawl(pg, touch, '.bcard', 'card', st)
        # info panel of a building: select the starting solar array, press its buttons (Recycle last)
        sid = pg.evaluate("() => { const e = window.__ja.engine; const b = [...e.buildings.values()].find(b => b.type === 'solar'); b.cond = 70; e.select(b.id); return b.id; }")
        pg.wait_for_timeout(300)
        crawl(pg, touch, '#info button', 'info', st, skip=('Recycle', '✕'))
        crawl(pg, touch, '#info button', 'info', st)
        # in-game menu and every entry except leaving the mission
        press(pg, touch, pg.locator('#btn-menu')); pg.wait_for_timeout(300)
        labels = [x.inner_text() for x in pg.locator('#modal .m-btns .btn').all()]
        close_modal(pg, touch)
        for lab in labels:
            if 'Restart' in lab or 'Change destination' in lab or 'Resume' in lab: continue
            try:
                press(pg, touch, pg.locator('#btn-menu')); pg.wait_for_timeout(250)
                press(pg, touch, pg.locator('#modal .m-btns .btn', has_text=lab).first); pg.wait_for_timeout(350)
                st['pressed'].append('menu:' + lab)
                if pg.locator('#modal').count(): st['modals'] += 1; modal_inner(pg, touch, st); close_modal(pg, touch)
            except Exception as e:
                st['fail'].append('menu:' + lab + ' ' + str(e).split('\n')[0][:80])
        usable = pg.locator('#modal').count() == 0 and pg.evaluate("() => !!document.querySelector('#hud') && !document.querySelector('#tutorial')")
        sz = sizes(pg)
        results[planet] = dict(st); results[planet + '_sizes'] = sz
        ok(f'{tag} {planet.title()} mission: every control pressed, pop-ups close, screen still usable, no errors', not st['fail'] and not errs and usable, f"{len(st['pressed'])} pressed, {st['modals']} pop-ups, {st['inner']} tabs; {st['fail'][:3]} {errs[:1]}")
        # leaving the mission from the menu
        press(pg, touch, pg.locator('#btn-menu')); pg.wait_for_timeout(250)
        press(pg, touch, pg.locator('#modal .m-btns .btn', has_text='Change destination').first); pg.wait_for_timeout(900)
        ok(f'{tag} {planet.title()}: menu → Change destination returns to the title', pg.locator('#main-menu').count() == 1)
    if touch:
        s = results['mars_sizes']
        ok(f'{tag} Touch targets: none smaller than 24 px in a mission', not s['small24'], f"{len(s['small24'])} small: {s['small24'][:6]}; {s['small44']} between 24 and 44 px of {s['total']}")
        ok(f'{tag} Smallest visible text is at least 10 px', s['minFont'] >= 10, f"{s['minFont']} px ({s['minEl']})")
    pg.screenshot(path=ROOT + f'/qa/results/shots/crawl_{view}.png')
    ctx.close()
    return results

if __name__ == '__main__':
    out = {}
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=CHROME, args=ARGS)
        for v in (sys.argv[1:] or ['desktop', 'tablet', 'phone']): out[v] = run(b, v)
        b.close()
    json.dump(out, open(ROOT + '/qa/results/button_crawl.json', 'w'), indent=1)
    print(f'\n{sum(R)}/{len(R)} passed')
