// STEM learning system QA (runs in the page with the real engine)
async () => {
  const Engine = window.__ja.Engine, L = window.__ja.learning, M = window.__ja.Modals;
  const realOpen = M.open.bind(M);
  let opened = [];
  M.open = (o) => { opened.push(o); return Promise.resolve(o.custom === 'emergency' ? (o._pick ?? 0) : 0); };
  const out = [], logs = [];
  const ok = (name, pass, detail = '') => out.push({ name, pass: !!pass, detail: String(detail) });
  const near = (a, b, tol) => Math.abs(a - b) <= tol;
  const fx = (e) => e.effects.forEach((x) => { if (x.onDone && !x.done) { x.done = true; x.onDone(); } });
  const step = (e, days, dt = 0.01) => { const n = Math.round(days / dt); for (let k = 0; k < n && !e.over; k++) { e.t += dt; e.env = e.computeEnv(e.t); e.step(dt); fx(e); } };
  const place = (e, t, i, j) => { e.ui.buildType = t; const r = e.place(i, j); e.ui.buildType = null; return r; };
  const finish = (e) => e.buildings.forEach((b) => { if (!b.built) e.completeBuilding(b); });
  const base = (p, t, o = {}) => {
    const e = new Engine(p, 90); e.events = []; e.t = t; e.env = e.computeEnv(t); e.res.mat = 2000;
    place(e, 'oxygen', 9, 4); place(e, 'battery', 4, 3); place(e, 'recycler', 8, 9); place(e, 'lab', 9, 9); place(e, 'fabricator', 9, 6);
    if (o.reactor !== false) place(e, 'reactor', 12, 12);
    if (o.shields !== false) { place(e, 'shield', 5, 6); place(e, 'shield', 5, 7); }
    finish(e); e.res.mat = 1000; e.res.water = 300; e.res.o2 = 100; e.res.food = 150; step(e, 0.02); e.res.battery = e.stats.cap;
    return e;
  };
  const tick = () => new Promise((r) => setTimeout(r, 0));

  // ---------- 1. science explainers ----------
  const sk = Object.keys(L.SYSTEMS);
  ok('Science explainers exist for oxygen, water, food, energy and radiation', ['o2', 'water', 'food', 'energy', 'radiation'].every((k) => sk.includes(k)), sk.join(','));
  ok('Every explainer has a need, 4+ science points (REAL and GAME labelled) and a tip', sk.every((k) => { const s = L.SYSTEMS[k]; return s.need && s.tip && s.science.length >= 4 && s.science.every(([h, t, kind]) => h && t.length > 40 && (kind === 'real' || kind === 'game')) && s.science.some((x) => x[2] === 'game'); }));
  // ---------- 3. planet facts ----------
  ok('Mars and Moon each have 12+ distinct short facts', ['mars', 'moon'].every((p) => L.FACTS[p].length >= 12 && new Set(L.FACTS[p]).size === L.FACTS[p].length && L.FACTS[p].every((f) => f.length < 160)), `${L.FACTS.mars.length} / ${L.FACTS.moon.length}`);
  for (const p of ['mars', 'moon']) {
    const e = new Engine(p, 90); e._scheduleEvents();
    const f = e.events.filter((x) => x.type === 'fact');
    ok(`[${p}] Fact pop-ups scheduled about every 3 days across 90 days`, f.length >= 24 && f.length <= 34, `${f.length} facts`);
    const seen = new Set(); let dup = false;
    for (let k = 0; k < L.FACTS[p].length; k++) { const t = e.showFact(); if (seen.has(t)) dup = true; seen.add(t); }
    ok(`[${p}] Facts never repeat; they come from the right planet`, !dup && seen.size === L.FACTS[p].length && [...seen].every((t) => L.FACTS[p].includes(t)) && e.showFact() === null);
  }

  // ---------- 2 + 4. engineering consequences and verdicts for every choice ----------
  for (const p of ['mars', 'moon']) {
    let total = 0, bad = [];
    for (const type of ['dust', 'o2fail', 'waterleak', 'batfail', 'radiation']) for (const lvl of [0, 3]) {
      const e = base(p, p === 'mars' ? 3.5 + lvl * 23 : 3 + lvl * 23); e.res.mat = 1000;
      e.autoDecide = (em) => { em.choices.forEach((c) => { total++; const v = L.judgeChoice(e, em, c), t = L.engText(p, type, c.id);
        if (!L.GRADES[v.grade] || !v.why || v.why.length < 30 || !t || t === L.ENG.endure && c.id !== 'endure') bad.push(`${type}.${c.id}`); }); return em.choices[0].id; };
      e.triggerEmergency(type);
    }
    ok(`[${p}] Every emergency choice has an engineering consequence and a verdict with a reason`, total >= 25 && !bad.length, `${total} choices checked ${bad.join(' ')}`);
  }
  // context-sensitive verdicts
  { const e = base('mars', 3.5, { reactor: false }); e.res.battery = 20; e.autoDecide = () => 'ride'; const em = e.triggerEmergency('dust', { dur: 3, peak: 0.85 });
    const d = e.decisions.at(-1);
    ok('[mars] Riding out a dust storm with no reactor and low batteries → Poor call, and the better option is named', d.grade === 'poor' && d.better && d.better.label && /reactor|battery|batteries/i.test(d.why), `${d.grade}; better: ${d.better && d.better.label}`); }
  { const e = base('mars', 3.5); e.autoDecide = () => 'ride'; e.triggerEmergency('dust', { dur: 3, peak: 0.6 }); const d = e.decisions.at(-1);
    ok('[mars] Same choice with a reactor → Good call (verdict depends on the base)', d.grade === 'good', d.grade); }
  { const e = base('moon', 3); e.autoDecide = () => 'shelter'; e.triggerEmergency('radiation'); const a = e.decisions.at(-1);
    const f = base('moon', 3, { shields: false }); f.autoDecide = () => 'shelter'; f.triggerEmergency('radiation'); const b = f.decisions.at(-1);
    ok('[moon] Radiation shelter: Best call with 2 shields, only Good with none (water wall suggested)', a.grade === 'best' && !a.better && b.grade === 'good' && b.better && /water/i.test(b.better.label), `${a.grade} / ${b.grade} → ${b.better && b.better.label}`); }
  { const e = base('mars', 3.5); e.autoDecide = () => 'work'; e.triggerEmergency('radiation'); const d = e.decisions.at(-1);
    ok('[mars] Working outside in a solar storm → Risky call (below the 250 mSv storm limit, but an avoidable career dose)', d.grade === 'risky' && /mSv/.test(d.why) && /career/.test(d.why) && d.better, d.why); }
  { const e = base('moon', 3.5); e.autoDecide = () => 'work'; e.triggerEmergency('radiation'); const d = e.decisions.at(-1);
    ok('[moon] Working outside in a solar storm → Poor call (over NASA\'s 250 mSv storm limit)', d.grade === 'poor' && /250 mSv/.test(d.why) && d.better, d.why); }
  { const e = base('moon', 3); e.autoDecide = () => 'gamble'; e.triggerEmergency('batfail'); const d = e.decisions.at(-1);
    ok('[moon] Gambling with a damaged battery → Poor call (thermal runaway explained)', d.grade === 'poor' && /thermal runaway/i.test(d.eng + d.why), d.eng); }
  { const e = base('mars', 3.5); e.autoDecide = () => 'repair'; const before = e.res.mat; e.triggerEmergency('o2fail'); const d = e.decisions.at(-1);
    ok('[mars] Decision record stores the real resource change (materials spent)', d.delta.mat === -Math.round(before - e.res.mat) && d.delta.mat < 0, JSON.stringify(d.delta)); }

  // ---------- debrief modal after a player decision ----------
  { const e = base('moon', 3); opened = [];
    M.open = (o) => { opened.push(o); return Promise.resolve(o.custom === 'emergency' ? 'leave' : 0); };
    e.triggerEmergency('dust'); await tick(); await tick();
    const db = opened.find((o) => o.custom === 'debrief');
    ok('A player decision opens a debrief that jumps the modal queue', db && db.front && db.dec.grade && db.dec.eng && db.dec.why && opened[0].custom === 'emergency', db && `${db.title}: ${db.dec.why.slice(0, 60)}…`);
    ok('Debrief verdict colour matches the grade', db && db.kind === { best: 'good', good: 'good', risky: 'warn', poor: 'danger' }[db.dec.grade]);
    M.open = (o) => { opened.push(o); return Promise.resolve(0); }; }

  // ---------- live flows ----------
  for (const p of ['mars', 'moon']) {
    const e = base(p, p === 'mars' ? 3.5 : 3); step(e, 2);
    const f = e.flows.o2, w = e.flows.water;
    ok(`[${p}] Live O₂ breakdown: crew breathing ≈ −3.36 kg/day, generator positive`, near(f['Crew breathing'], -3.36, 0.05) && f['O₂ generators'] > 2, JSON.stringify(Object.fromEntries(Object.entries(f).map(([k, v]) => [k, +v.toFixed(2)]))));
    ok(`[${p}] Live water breakdown includes the recycler (+12.6 L/day)`, near(w['Water recycler'], 12.6, 0.2) && near(w['Crew drinking & washing'], -14, 0.1) && (p === 'mars' || w['O₂ generator (electrolysis)'] < 0));
    const net = Object.values(f).reduce((a, v) => a + v, 0);
    ok(`[${p}] Breakdown adds up to the HUD rate`, near(net, e.rates.o2, 0.6), `${net.toFixed(2)} vs ${e.rates.o2.toFixed(2)}`);
  }

  // ---------- 5 + 6. score and ranks ----------
  const S = L.survivalScore;
  { const e = base('mars', 3.5); e.t = 90; e.report.time = 86; e.report.powerOkTime = 86; e.quizScore = 20; e.quizCount = 22; e.objectives.forEach((o) => e.objDone.add(o.id));
    const s = S(e, true);
    ok('Score has 5 parts (survival, crew health, resources, engineering, learning) summing to 100 max', Object.values(s.parts).reduce((a, p) => a + p.max, 0) === 100 && Object.keys(s.parts).join() === 'survival,health,resources,engineering,learning');
    ok('Score total equals the rounded sum of its parts', s.total === Math.round(Object.values(s.parts).reduce((a, p) => a + p.value, 0)));
    ok('Perfect 90-day mission → Gold', s.rank === 'gold' && s.total >= 85, `${s.total} ${s.rank}`);
    e.crew[3].status = 'evacuated'; const s3 = S(e, true);
    ok('Same mission with one astronaut evacuated → not Gold', s3.rank !== 'gold', `${s3.total} ${s3.rank}`);
    e.crew[2].status = 'lost'; e.crew[1].status = 'lost'; const s1 = S(e, true);
    ok('Survived with only 1 crew → Bronze', s1.rank === 'bronze', `${s1.total} ${s1.rank}`);
    const f0 = S(e, false); ok('Failed mission → Astronaut Cadet (no medal)', f0.rank === 'cadet', `${f0.total}`); }
  { const e = new Engine('moon', 90); e.t = 40; e.crew.forEach((c) => (c.status = 'lost')); const s = S(e, false);
    ok('Early failure scores low', s.total < 40 && s.rank === 'cadet', s.total); }
  { const e = base('mars', 3.5); e.t = 90; e.decisions = [{ grade: 'poor' }, { grade: 'poor' }]; const a = S(e, true).parts.engineering.value;
    e.decisions = [{ grade: 'best' }, { grade: 'best' }]; const b = S(e, true).parts.engineering.value;
    ok('Better decisions raise the engineering score', b - a >= 9.9, `${a.toFixed(1)} → ${b.toFixed(1)}`); }

  // ---------- full missions: rank reflects how you played ----------
  const PLANS = {
    mars: ['oxygen', 'solar', 'ice', 'recycler', 'solar', 'battery', 'solar', 'shield', 'shield', 'fabricator', 'solar', 'battery', 'comms', 'lab', 'solar', 'greenhouse', 'reactor', 'greenhouse', 'battery', 'shield', 'shield', 'shield', 'shield', 'oxygen'],
    moon: ['oxygen', 'ice', 'recycler', 'shield', 'shield', 'reactor', 'greenhouse', 'lab', 'comms', 'battery', 'fabricator', 'greenhouse', 'battery', 'shield', 'shield', 'shield', 'shield', 'reactor', 'solar'],
  };
  const sol = (e) => [...e.buildings.values()].filter((b) => b.type === 'solar');
  const free = (e, t) => { for (let r = 1; r < 8; r++) for (let i = 0; i < 14; i++) for (let j = 0; j < 14; j++) {
    const hd = Math.max(i < 6 ? 6 - i : i > 7 ? i - 7 : 0, j < 6 ? 6 - j : j > 7 ? j - 7 : 0); if (hd !== r) continue;
    if (t === 'ice' && !e.ice.has(i + ',' + j)) continue; if (t !== 'ice' && e.ice.has(i + ',' + j)) continue;
    if (t === 'shield' && r !== 1 && e.habitatShields() < 2) continue; if (t !== 'shield' && r < 2) continue; if (e.canPlace(t, i, j).ok) return [i, j]; } return null; };
  const PRIORITY = ['habitat', 'oxygen', 'ice', 'recycler', 'greenhouse', 'reactor', 'solar', 'battery', 'fabricator', 'comms', 'lab'];
  const deciders = {
    wise: (e) => (em) => { const a = em.choices.filter((c) => c.available); return a.map((c) => [c, L.GRADES[L.judgeChoice(e, em, c).grade].value]).sort((x, y) => y[1] - x[1] || y[0].points - x[0].points)[0][0].id; },
    poor: () => (em) => em.choices.filter((c) => c.available).sort((a, b) => a.points - b.points)[0].id,
  };
  const mission = (p, D, who, maintain = true) => {
    const e = new Engine(p, D); e.autoDecide = deciders[who](e); let k = 0;
    const quiz = e.quiz; e.quiz = () => { e.quizCount++; if (who === 'wise' || Math.random() < 0.3) e.quizScore++; };
    while (!e.over && e.t < D + 1) {
      if (k < PLANS[p].length) { const pos = free(e, PLANS[p][k]); if (pos) { place(e, PLANS[p][k], ...pos); k++; } }
      if (maintain) {
        const worn = [...e.buildings.values()].filter((b) => b.built && b.type !== 'shield' && b.type !== 'lander' && b.cond < 70).sort((a, b) => PRIORITY.indexOf(a.type) - PRIORITY.indexOf(b.type));
        for (const b of worn) if (e.res.mat >= e.repairCost(b) + 40) e.repair(b);
        if (e.landerCapLoss) e.repairLander();
        if (sol(e).some((b) => b.dust < 0.9) && e.canEVA()) e.clean();
        const opt = [...e.buildings.values()].filter((b) => b.type === 'lab' || b.type === 'fabricator');
        if (e.stats.ratio < 0.95 || (e.stats.prod < e.stats.demand && e.res.battery < e.stats.cap * 0.3)) opt.forEach((b) => (b.on = false));
        else if (e.res.battery > e.stats.cap * 0.6 || e.stats.prod > e.stats.demand + 3) opt.forEach((b) => (b.on = true));
      }
      for (let s = 0; s < 10 && !e.over; s++) { e.t += 0.01; e.env = e.computeEnv(e.t); e.step(0.01); fx(e); }
    }
    return e;
  };
  for (const p of ['mars', 'moon']) {
    const w = mission(p, 90, 'wise'), q = mission(p, 90, 'poor'), n = mission(p, 90, 'wise', false);
    const r = (e) => `${e.result.win ? 'won' : 'lost d' + Math.floor(e.t)} crew ${e.result.alive} score ${e.result.stem.total} ${e.result.rank} cond ${Math.round(e.result.stem.avgCond)}% repairs ${e.repairs} (${Object.values(e.result.stem.parts).map((x) => Math.round(x.value)).join('/')})`;
    logs.push(`${p}: wise ${r(w)} | poor ${r(q)} | no maintenance ${r(n)}`);
    ok(`[${p} 90d] endGame result carries the survival score and rank`, w.result.stem && w.result.rank === w.result.stem.rank && typeof w.result.stem.total === 'number');
    ok(`[${p} 90d] Wise engineer (best verdicts + maintenance) earns Silver or Gold`, w.result.win && (w.result.rank === 'gold' || w.result.rank === 'silver'), r(w));
    ok(`[${p} 90d] Poor decisions score lower and rank lower than wise ones`, q.result.stem.total < w.result.stem.total && ['cadet', 'bronze', 'silver', 'gold'].indexOf(q.result.rank) <= ['cadet', 'bronze', 'silver', 'gold'].indexOf(w.result.rank), r(q));
    ok(`[${p} 90d] Neglected base (no repairs) gets a lower engineering score and a lower total`, n.result.stem.parts.engineering.value < w.result.stem.parts.engineering.value - 3 && n.result.stem.total < w.result.stem.total, r(n));
    ok(`[${p} 90d] Mission totals tracked (energy, recycled water, lowest levels)`, w.report.energyKWh > 1000 && w.report.recycledL > 500 && w.report.minRes.o2 >= 0 && w.report.minRes.o2 < 45 && near(w.report.time, 90 - (p === 'mars' ? 0.3 : 0.2), 0.2), `${Math.round(w.report.energyKWh)} kWh, ${Math.round(w.report.recycledL)} L recycled, min O₂ ${w.report.minRes.o2.toFixed(1)}`);
    ok(`[${p} 90d] Graded decisions recorded`, w.decisions.filter((d) => d.grade).length >= 8, `${w.decisions.length} decisions`);
  }
  M.open = realOpen;
  return { out, logs };
}
