import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
# Regenerates docs/screenshots/*.png from the production build (run "npm run preview" first).
from playwright.sync_api import sync_playwright

OUT = ROOT + '/docs/screenshots'
os.makedirs(OUT, exist_ok=True)
ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']

def context(b, mobile, tutorial_done=True):
    vp = {'width': 390, 'height': 844} if mobile else {'width': 1440, 'height': 900}
    ctx = b.new_context(viewport=vp, is_mobile=mobile, has_touch=mobile, device_scale_factor=2 if mobile else 1)
    st = '{ tutorialDone: true, quality: "high" }' if tutorial_done else '{ quality: "high" }'
    ctx.add_init_script(f"localStorage.setItem('ja-settings', JSON.stringify({st}))")
    ctx.route('https://ccmc.gsfc.nasa.gov/**', lambda r: r.abort())  # no internet here: the game shows its labelled archive
    return ctx, ctx.new_page()

def close_modals(pg):
    for _ in range(10):
        if not pg.locator('#modal').count(): return
        c = pg.locator('#modal .em-choice:not([disabled])')
        if c.count(): c.first.scroll_into_view_if_needed(); c.first.click()
        else: pg.locator('#modal .m-btns .btn').first.click()
        pg.wait_for_timeout(500)

def shot(pg, name):
    pg.screenshot(path=f'{OUT}/{name}.png'); print('saved', name)

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=ARGS)
    ctx, pg = context(b, False)
    pg.goto(URL); pg.wait_for_timeout(1800); shot(pg, '01-main-menu')
    pg.click('[data-mm="demo"]'); pg.wait_for_timeout(3500)
    pg.click('#modal .m-btns .btn.primary'); pg.wait_for_timeout(4500)
    pg.click('.dp-h'); pg.wait_for_timeout(300); shot(pg, '02-mars-base'); pg.click('.dp-h'); pg.wait_for_timeout(300)
    nxt = lambda wait=2400: (pg.click('#demo-next'), pg.wait_for_timeout(wait))
    nxt(); close_modals(pg)                                   # tour
    nxt(); shot(pg, '03-life-support-science'); close_modals(pg)
    nxt(); shot(pg, '04-dust-emergency'); close_modals(pg)
    nxt(); pg.locator('#modal .nasa-card').scroll_into_view_if_needed(); pg.wait_for_timeout(300); shot(pg, '05-radiation-nasa'); close_modals(pg)
    nxt(); shot(pg, '06-nasa-data-sources'); close_modals(pg)
    nxt(3800); pg.click('#modal .m-btns .btn.primary'); pg.wait_for_timeout(4500)
    pg.click('.dp-h'); pg.wait_for_timeout(300); shot(pg, '07-moon-base'); pg.click('.dp-h'); pg.wait_for_timeout(300)
    nxt(4000); shot(pg, '08-final-report')
    ctx.close()

    ctx, pg = context(b, True)
    pg.goto(URL); pg.wait_for_timeout(1500)
    pg.tap('[data-mm="demo"]'); pg.wait_for_timeout(3500)
    pg.tap('#modal .m-btns .btn.primary'); pg.wait_for_timeout(4500); shot(pg, '09-phone-mars')
    ctx.close()

    ctx, pg = context(b, True, tutorial_done=False)
    pg.goto(URL); pg.wait_for_timeout(1500)
    pg.tap('[data-mm="tutorial"]'); pg.wait_for_timeout(3500)
    close_modals(pg); pg.wait_for_timeout(1500)            # welcome briefing -> tutorial coach marks start
    nx = pg.locator('.tut-card .btn.primary')
    if nx.count(): nx.first.tap(); pg.wait_for_timeout(900)  # step 2: life-support gauges
    shot(pg, '10-phone-tutorial')
    ctx.close()
    b.close()
