"""Run the full Junior Astronaut regression against the production build.

Usage:  npm run build && npm run test:e2e
        (or: python3 qa/run_all.py)  — needs Python 3 + Playwright and a Chrome/Chromium.
        CHROME_PATH=/path/to/chrome  overrides the browser;  JA_URL=https://your-site.vercel.app/  tests a deployed site
        instead of starting the local preview server.

Every suite prints PASS/FAIL lines; this runner totals them and exits non-zero if anything failed.
"""
import os, subprocess, sys, time, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
QA = os.path.join(ROOT, 'qa')
SUITES = [
    ('Deployment checks (headers, CSP, assets, standalone)', ['deploy_check.py']),
    ('Engine: resources, 30/60/90-day missions', ['run_engine.py']),
    ('Engine: long-mission balance', ['run_long.py']),
    ('Engine: 5 emergencies', ['run_em.py']),
    ('Engine: STEM learning system', ['run_stem.py']),
    ('UI: Mars & Moon, desktop & phone', ['ui_tests.py', 'mars-desktop', 'moon-desktop', 'mars-phone', 'moon-phone']),
    ('UI: emergencies', ['em_ui.py', 'mars-desktop', 'moon-desktop', 'mars-phone', 'moon-phone']),
    ('UI: STEM learning', ['stem_ui.py', 'mars-desktop', 'moon-phone']),
    ('UI: NASA DONKI live / blocked / HTTP 503 / timeout', ['nasa_ui.py', 'live-desktop', 'live-phone', 'blocked-desktop', 'http503-phone', 'timeout-desktop']),
    ('UI: menu, settings, tutorial, credits, report', ['p6_ui.py', 'features-desktop', 'features-phone']),
    ('UI: hackathon demo mode', ['p6_ui.py', 'demo-desktop', 'demo-phone']),
    ('UI: overlap audit on 7 screen sizes', ['p6_ui.py', 'layouts']),
]

def wait_up(url, secs=15):
    for _ in range(secs * 10):
        try:
            urllib.request.urlopen(url, timeout=1); return True
        except Exception:
            time.sleep(0.1)
    return False

server = None
if 'JA_URL' not in os.environ:
    os.environ['JA_URL'] = 'http://127.0.0.1:4173/'
    server = subprocess.Popen(['node', os.path.join(ROOT, 'scripts', 'serve.mjs')], stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    if not wait_up(os.environ['JA_URL']):
        print('Preview server did not start — did you run "npm run build"?'); server.kill(); sys.exit(1)

only = sys.argv[1:]
total_p = total_f = 0; rows = []
try:
    unit = subprocess.run(['node', os.path.join(QA, 'nasa_unit.mjs')], capture_output=True, text=True, cwd=ROOT)
    up = unit.stdout.count('PASS'); uf = unit.stdout.count('FAIL') + (unit.returncode != 0)
    rows.append(('NASA DONKI unit tests (Node)', up, uf)); total_p += up; total_f += uf
    for name, cmd in SUITES:
        if only and not any(o in cmd[0] for o in only): continue
        t0 = time.time()
        r = subprocess.run([sys.executable, os.path.join(QA, cmd[0])] + cmd[1:], capture_output=True, text=True, cwd=ROOT)
        lines = r.stdout.splitlines()
        p = sum(l.startswith('PASS') for l in lines); f = sum(l.startswith('FAIL') for l in lines)
        if r.returncode != 0 or (p + f) == 0: f += 1; lines.append('SUITE ERROR: ' + (r.stderr.strip().splitlines() or ['no output'])[-1])
        tail = [l for l in lines if 'page errors' in l and '[]' not in l]
        if tail: f += 1
        rows.append((name, p, f)); total_p += p; total_f += f
        print(f'{"OK  " if f == 0 else "FAIL"} {name}: {p} passed, {f} failed  ({time.time() - t0:.0f}s)', flush=True)
        for l in lines:
            if l.startswith('FAIL') or l.startswith('SUITE ERROR') or l in tail: print('     ' + l)
finally:
    if server: server.kill()

print('\n' + '-' * 72)
for name, p, f in rows: print(f'{p:>4} passed {f:>3} failed   {name}')
print('-' * 72 + f'\n{total_p} checks passed, {total_f} failed')
sys.exit(1 if total_f else 0)
