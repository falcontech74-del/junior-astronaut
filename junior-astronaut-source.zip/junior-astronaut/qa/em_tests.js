// Emergency system QA (runs in the page with the real engine)
() => {
  const Engine = window.__ja.Engine;
  window.__ja.nasa.NasaData.disabled = true; // fixed doses for exact checks (NASA scaling is tested in nasa_tests.js)
  window.__ja.Modals.open = () => Promise.resolve(0);
  const out = [], logs = [];
  const ok = (name, pass, detail = '') => out.push({ name, pass: !!pass, detail: String(detail) });
  const near = (a, b, tol) => Math.abs(a - b) <= tol;
  const fx = (e) => e.effects.forEach((x) => { if (x.onDone && !x.done) { x.done = true; x.onDone(); } });
  const step = (e, days, dt = 0.01) => { const n = Math.round(days / dt); for (let k = 0; k < n && !e.over; k++) { e.t += dt; e.env = e.computeEnv(e.t); e.step(dt); fx(e); } };
  const place = (e, t, i, j) => { e.ui.buildType = t; const r = e.place(i, j); e.ui.buildType = null; return r; };
  const finish = (e) => e.buildings.forEach((b) => { if (!b.built) e.completeBuilding(b); });
  const sol = (e) => [...e.buildings.values()].filter((b) => b.type === 'solar');
  const one = (e, type) => [...e.buildings.values()].find((b) => b.type === type);
  // a well-supplied test base
  const base = (p, t, opts = {}) => {
    const e = new Engine(p, 90); e.events = []; e.t = t; e.env = e.computeEnv(t);
    e.res.mat = 2000;
    place(e, 'oxygen', 9, 4); place(e, 'battery', 4, 3); place(e, 'recycler', 8, 9); place(e, 'lab', 9, 9); place(e, 'fabricator', 9, 6); place(e, 'reactor', 12, 12);
    if (opts.shields !== false) { place(e, 'shield', 5, 6); place(e, 'shield', 5, 7); }
    finish(e); e.res.mat = 1000; e.res.water = 300; e.res.o2 = 100; e.res.food = 150; step(e, 0.02); e.res.battery = e.stats.cap;
    return e;
  };
  const trigger = (e, type, choice, ev = {}) => { e.autoDecide = () => choice; const before = { ...e.res, pts: e.points }; const em = e.triggerEmergency(type, ev); return { em, before }; };
  const costOK = (e, before, k) => ['mat', 'water', 'o2'].every((r) => !k[r] || near(before[r] - e.res[r], k[r], 0.01));

  for (const p of ['mars', 'moon']) {
    const T0 = p === 'mars' ? 3.5 : 3; // daytime, threat I
    // ---------- DUST ----------
    if (p === 'mars') {
      { const e = base(p, T0); const { em, before } = trigger(e, 'dust', 'powerplan', { dur: 3, peak: 0.6 });
        ok('[mars] Dust storm onset: storm starts (solar −49%)', e.storm && e.storm.peak === 0.6);
        ok('[mars] Dust → Emergency power plan: lab + fabricator switched off, +30 pts', !one(e, 'lab').on && !one(e, 'fabricator').on && e.points - before.pts === 30);
        step(e, 3.7); ok('[mars] Dust → power plan: systems switch back on when the storm ends; success bonus', one(e, 'lab').on && one(e, 'fabricator').on && e.report.emResolved === 1, `points ${e.points}`); }
      { const e = base(p, T0); sol(e).forEach((b) => (b.dust = 0.7)); const h = e.crew.map((c) => c.health); const { em, before } = trigger(e, 'dust', 'eva', { dur: 3, peak: 0.6 });
        ok('[mars] Dust → EVA: costs 3 kg O₂, storm thins by 30%, panels clean, 2 crew −8% health', near(before.o2 - e.res.o2, 3, 0.01) && near(e.storm.peak, 0.42, 0.001) && sol(e).every((b) => b.dust === 1) && e.crew.filter((c, k) => c.health < h[k] - 7).length === 2); }
      { const e = base(p, T0); const { before } = trigger(e, 'dust', 'ride', { dur: 3, peak: 0.6 }); ok('[mars] Dust → Ride it out: free, 0 pts, storm unchanged', e.storm.peak === 0.6 && e.points === before.pts && e.res.mat === before.mat); }
      { const e = base(p, 0.5); step(e, 0.005); const p0 = e.stats.prod; trigger(e, 'dust', 'ride', { dur: 3, peak: 0.88 }); step(e, 1.0); e.t = 1.5; e.env = e.computeEnv(e.t); step(e, 0.01);
        ok('[mars] Dust storm really cuts solar power', e.stats.prod - 10 < (p0 - 10) * 0.35 + 0.5, `solar part ${(p0 - 10).toFixed(1)} → ${(e.stats.prod - 10).toFixed(1)} kW`); }
    } else {
      { const e = base(p, T0); const { before } = trigger(e, 'dust', 'eva');
        ok('[moon] Dust cloud onset: panels coated to 58%, then EVA cleans them (2 crew −6% health)', sol(e).every((b) => b.dust === 1) && e.crew.filter((c) => c.health <= 94.01).length === 2 && near(before.o2 - e.res.o2, 3, 0.01)); }
      { const e = base(p, T0); const { before } = trigger(e, 'dust', 'eds'); ok('[moon] Dust → Electrodynamic dust shield: −40 kg, −30 kWh, panels 92%', near(before.mat - e.res.mat, 40, 0.01) && near(before.battery - e.res.battery, 30, 0.01) && sol(e).every((b) => b.dust === 0.92)); }
      { const e = base(p, T0); trigger(e, 'dust', 'leave'); ok('[moon] Dust → Leave it: panels stay at 58%, solar output drops', sol(e).every((b) => near(b.dust, 0.58, 0.001)));
        step(e, 0.01); ok('[moon] Dirty panels really produce less', near(e.stats.prod, 10 + 17 * 0.58 * sol(e)[0].cond / 100, 0.2), e.stats.prod.toFixed(2)); }
      { const e = base(p, T0); trigger(e, 'dust', 'leave'); ok('[moon] Dust cloud is visible (3D haze flag)', e.lunarDust() > 0); }
    }
    // ---------- OXYGEN GENERATOR FAILURE ----------
    { const e = base(p, T0); const { em, before } = trigger(e, 'o2fail', 'repair');
      ok(`[${p}] O₂ failure onset: generator to 0% (production stops)`, em && em.target === one(e, 'oxygen').id);
      ok(`[${p}] O₂ → Full repair: −54 kg (engineer discount), back to 100%, +30 pts`, near(before.mat - e.res.mat, 54, 0.01) && one(e, 'oxygen').cond === 100 && e.points - before.pts === 30);
      step(e, 4.1); ok(`[${p}] O₂ → repaired: success bonus after 4 days`, e.report.emResolved === 1); }
    { const e = base(p, T0); const alt = p === 'mars' ? 'filter' : 'flush'; const { em, before } = trigger(e, 'o2fail', alt);
      ok(`[${p}] O₂ → ${alt}: ${p === 'mars' ? '−20 kg, runs at 70%, 1 crew −5%' : '−15 L water, −10 kg, runs at 75%'}`, costOK(e, before, em.chosen.costs) && one(e, 'oxygen').cond === (p === 'mars' ? 70 : 75)); }
    { const e = base(p, T0); const { em, before } = trigger(e, 'o2fail', 'candles');
      ok(`[${p}] O₂ → Oxygen candles: −25 kg, +10 kg O₂ now, generator stays off`, near(before.mat - e.res.mat, 25, 0.01) && near(e.res.o2 - before.o2, 10, 0.01) && one(e, 'oxygen').cond === 0);
      const o = e.res.o2; step(e, 1); ok(`[${p}] O₂ candles: with the generator off, oxygen really falls`, e.res.o2 < o - 2.5, `${o.toFixed(1)} → ${e.res.o2.toFixed(1)}`);
      step(e, 3.2); ok(`[${p}] O₂ candles: still broken after 4 days → −10 pts penalty`, e.report.emFailed === 1 && e.points === before.pts + 5 - 10, e.points - before.pts); }
    // ---------- WATER LEAK ----------
    { const e = base(p, T0); const { em, before } = trigger(e, 'waterleak', 'replace');
      ok(`[${p}] Water leak onset: 5% of water lost instantly`, near(before.water * 0.95, e.res.water + 0, 0.01) || near(e.res.water, before.water * 0.95, 0.01), `${before.water} → ${e.res.water.toFixed(1)}`);
      ok(`[${p}] Water → Replace pipe: −30 kg (engineer), leak stops`, near(before.mat - e.res.mat, 30, 0.01) && em.leakRate === 0); }
    { const e = base(p, T0); const { em } = trigger(e, 'waterleak', 'patch'); const w = e.res.water;
      const ctrl = base(p, T0); const wc = ctrl.res.water; step(e, 1); step(ctrl, 1);
      ok(`[${p}] Water → Patch: leak slows to 2 L/day (measured)`, near((w - e.res.water) - (wc - ctrl.res.water), 2, 0.15), ((w - e.res.water) - (wc - ctrl.res.water)).toFixed(2)); }
    if (p === 'mars') {
      { const e = base(p, T0); const { before } = trigger(e, 'waterleak', 'heat'); ok('[mars] Water → Pipe heaters: −25 kWh −30 kg, leak stops, future leaks halved', e.pipeHeated && near(before.mat - e.res.mat, 30, 0.01));
        e.autoDecide = () => 'patch'; const em2 = e.triggerEmergency('waterleak'); ok('[mars] …next Mars pipe leak is half as fast (4 L/day)', em2.chosen && near(em2.leakRate / 0.25, 4, 0.01), em2.leakRate / 0.25); }
    } else {
      { const e = base(p, T0); const rec = one(e, 'recycler'); const { em, before } = trigger(e, 'waterleak', 'reroute');
        ok('[moon] Water → Reroute through recycler: leak stops, half the lost water recovered, recycler −30%', em.leakRate === 0 && near(e.res.water, before.water * 0.95 + before.water * 0.05 * 0.5, 0.01) && near(rec.cond, 70, 0.6)); }
      { const e = base(p, T0); e.buildings.delete(one(e, 'recycler').id); const em = (e.autoDecide = () => 'replace', e.triggerEmergency('waterleak'));
        ok('[moon] Reroute is disabled without a recycler', em.choices.find((c) => c.id === 'reroute').available === false); }
    }
    { const e = base(p, T0); const { em } = trigger(e, 'waterleak', 'nonexistent-choice'); ok(`[${p}] Unknown choice falls back to the first option safely`, em.chosen && em.chosen.id === em.choices[0].id); }
    // ---------- BATTERY FAILURE ----------
    { const e = base(p, T0); const bat = one(e, 'battery'); const b0 = e.res.battery; const { em, before } = trigger(e, 'batfail', 'replace');
      ok(`[${p}] Battery onset: 45% of stored energy lost`, near(e.res.battery, b0 * 0.55, 0.01), `${b0.toFixed(0)} → ${e.res.battery.toFixed(0)} kWh`);
      ok(`[${p}] Battery → Replace cells: −42 kg, bank back to 100%`, near(before.mat - e.res.mat, 42, 0.01) && bat.cond === 100); }
    { const e = base(p, T0); const bat = one(e, 'battery'); trigger(e, 'batfail', 'isolate'); step(e, 0.02);
      ok(`[${p}] Battery → Isolate: free, bank at 50% so storage drops (170 → 110 kWh)`, near(bat.cond, 50, 0.1) && near(e.stats.cap, 110, 1), e.stats.cap.toFixed(0)); }
    { const e = base(p, T0); const bat = one(e, 'battery'); const { em, before } = trigger(e, 'batfail', 'gamble'); em.forceRunaway = true; step(e, 0.7);
      ok(`[${p}] Battery → Gamble lost: thermal runaway, bank destroyed, energy 0, −20 pts`, em.runaway && bat.cond === 0 && e.points === before.pts - 20, `points ${e.points - before.pts}`); }
    { const e = base(p, T0); const { em, before } = trigger(e, 'batfail', 'gamble'); em.forceRunaway = false; step(e, 0.7); ok(`[${p}] Battery → Gamble won: +5 pts`, !em.runaway && e.points === before.pts + 5); }
    { const e = new Engine(p, 90); e.events = []; e.t = T0; e.res.mat = 500; e.autoDecide = () => 'replace'; const b0 = e.res.battery; const em = e.triggerEmergency('batfail');
      ok(`[${p}] Battery failure with no Battery Bank hits the lander battery (−25 kWh capacity until fixed)`, em.target === 'lander' && e.landerCapLoss === 0 && e.res.battery <= b0 * 0.55 + 0.01); }
    // ---------- RADIATION ----------
    const rad = (choice, shields = true) => { const e = base(p, T0, { shields }); e.autoDecide = () => choice; const w = e.res.water; const em = e.triggerEmergency('radiation', { dose: p === 'mars' ? 55 : 350 });
      const s0 = e.res.science; e.pendingRadiation = em; e.fireEvent({ type: 'spe', dose: em.dose }); step(e, 0.45); const sci = e.res.science - s0; step(e, 0.15);
      const doses = e.crew.map((c) => c.stormDose || 0).sort((a, b) => b - a);
      return { e, em, dose: doses[0], doses, minH: Math.min(...e.crew.map((c) => c.health)), water: w, sci }; };
    { const s = rad('shelter'), w = rad('waterwall'), x = rad('work');
      ok(`[${p}] Radiation → Shelter: lowest workload dose, lab stops (no science)`, s.dose < 0.06 * s.em.dose + 0.5 && s.sci < 0.01, `${s.dose.toFixed(1)} mSv`);
      ok(`[${p}] Radiation → Water wall: −60 L, 48 L returned after; dose ×0.4; lab keeps working`, w.dose < s.dose && near(w.e.res.water - (w.water - 60), 48, 6) && w.sci > 2, `${w.dose.toFixed(1)} mSv, water ${w.water.toFixed(0)} → ${w.e.res.water.toFixed(0)}, sci +${w.sci.toFixed(1)}`);
      ok(`[${p}] Radiation → Work outside: the 2 outside crew get the full unshielded dose (~${p === 'mars' ? 55 : 350} mSv)${p === 'mars' ? ', below NASA\'s 250 mSv storm limit (no illness)' : ', over NASA\'s 250 mSv storm limit (they get sick)'}; the other 2 are shielded`, near(x.doses[1], x.em.dose, x.em.dose * 0.04) && x.doses[2] < x.em.dose * 0.12 && (p === 'mars' ? x.minH > 95 : x.minH < 100 - 20), `${x.doses.map((d) => d.toFixed(0)).join('/')} mSv, health ${x.minH.toFixed(0)}`);
      ok(`[${p}] Radiation points: shelter +40, water wall +25, work −10`, s.em.chosen.points === 40 && w.em.chosen.points === 25 && x.em.chosen.points === -10); }
    { const s = rad('shelter', false); ok(`[${p}] Without shields, shelter dose is 35% of the full dose (habitat walls ×0.7, shelter ×0.5)`, near(s.dose, s.em.dose * 0.35, s.em.dose * 0.03), s.dose.toFixed(0)); }
    // ---------- difficulty progression ----------
    { const a = base(p, T0), z = base(p, 75 + (p === 'mars' ? 0.5 : 0));
      a.autoDecide = z.autoDecide = () => 'repair';
      const ea = a.triggerEmergency('o2fail'), ez = z.triggerEmergency('o2fail');
      ok(`[${p}] Harder later: O₂ repair costs 54 → ${Math.round(90 * 1.7 * 0.6)} kg at threat IV`, ea.chosen.costs.mat === 54 && ez.chosen.costs.mat === Math.round(90 * 1.7 * 0.6));
      ok(`[${p}] Harder later: points ×1.75 at threat IV (30 → 53)`, ea.chosen.points === 30 && ez.chosen.points === 53);
      a.autoDecide = z.autoDecide = () => 'patch';
      const la = a.triggerEmergency('waterleak'), lz = z.triggerEmergency('waterleak');
      ok(`[${p}] Harder later: leaks 8 → 20 L/day`, near(la.leakRate / 0.25, 8, 0.01) && near(lz.leakRate / 0.25, 20, 0.01));
      a.autoDecide = z.autoDecide = () => 'isolate';
      const ga = a.triggerEmergency('batfail'), gz = z.triggerEmergency('batfail');
      ok(`[${p}] Harder later: battery gamble risk 50% → 80%`, ga.choices.find((c) => c.id === 'gamble').note.includes('50%') && gz.choices.find((c) => c.id === 'gamble').note.includes('80%')); }
    // ---------- unaffordable ----------
    { const e = base(p, T0); e.res.mat = 0; e.res.water = 0; e.autoDecide = (em) => em.choices.find((c) => c.available).id; const em = e.triggerEmergency('o2fail');
      ok(`[${p}] No materials: paid choices disabled with a reason, free fallback offered`, em.choices.filter((c) => !c.available).every((c) => /Not enough/.test(c.why)) && em.choices.some((c) => c.id === 'makedo'), em.choices.map((c) => `${c.id}:${c.available}`).join(' ')); }
    // ---------- scheduling ----------
    { const counts = { 30: 0, 90: 0 }; let early = 0, late = 0;
      for (let k = 0; k < 10; k++) for (const D of [30, 90]) {
        const ev = new Engine(p, D).events.filter((x) => x.type === 'em' || x.type === 'duststorm' || x.type === 'spe_warn');
        counts[D] += ev.length / 10; if (D === 90) { early += ev.filter((x) => x.day < 20).length / 10; late += ev.filter((x) => x.day >= 70).length / 10; }
      }
      const types = new Set(new Engine(p, 90).events.flatMap((x) => x.type === 'em' ? [x.em] : x.type === 'duststorm' ? ['dust'] : x.type === 'spe_warn' ? ['radiation'] : []));
      ok(`[${p}] All 5 emergencies scheduled on a 90-day mission`, ['dust', 'o2fail', 'waterleak', 'batfail', 'radiation'].every((t) => types.has(t)), [...types].join(','));
      ok(`[${p}] Emergencies per 10 days rise from threat I to IV`, late / 2 > early / 2 * 1.4, `I: ${(early / 2).toFixed(1)} → IV: ${(late / 2).toFixed(1)} per 10 days`);
      logs.push(`${p}: avg interactive emergencies — 30 days: ${counts[30].toFixed(1)}, 90 days: ${counts[90].toFixed(1)}`); }
  }
  // ---------- Mars vs Moon differences ----------
  { const m = base('mars', 3.5), l = base('moon', 3); m.autoDecide = l.autoDecide = (em) => em.choices[0].id;
    const ids = (e, t) => e.triggerEmergency(t).choices.map((c) => c.id).join(',');
    const md = ids(m, 'dust'), ld = ids(l, 'dust'), mo = ids(m, 'o2fail'), lo = ids(l, 'o2fail'), mw = ids(m, 'waterleak'), lw = ids(l, 'waterleak');
    ok('Mars and Moon emergencies offer different choices (dust, O₂, water)', md !== ld && mo !== lo && mw !== lw, `${md} | ${ld}`);
    const mr = base('mars', 3.5), lr = base('moon', 3); mr.autoDecide = lr.autoDecide = () => 'shelter';
    ok('Radiation alerts are stronger on the Moon (no air) than on Mars', lr.triggerEmergency('radiation').dose > mr.triggerEmergency('radiation').dose); }

  // ---------- full missions with different decision makers ----------
  const PLANS = {
    mars: ['oxygen', 'solar', 'ice', 'recycler', 'solar', 'battery', 'solar', 'shield', 'shield', 'fabricator', 'solar', 'battery', 'comms', 'lab', 'solar', 'greenhouse', 'reactor', 'greenhouse', 'battery', 'shield', 'shield', 'shield', 'shield', 'oxygen'],
    moon: ['oxygen', 'ice', 'recycler', 'shield', 'shield', 'reactor', 'greenhouse', 'lab', 'comms', 'battery', 'fabricator', 'greenhouse', 'battery', 'shield', 'shield', 'shield', 'shield', 'reactor', 'solar'],
  };
  const free = (e, t) => { for (let r = 1; r < 8; r++) for (let i = 0; i < 14; i++) for (let j = 0; j < 14; j++) {
    const hd = Math.max(i < 6 ? 6 - i : i > 7 ? i - 7 : 0, j < 6 ? 6 - j : j > 7 ? j - 7 : 0); if (hd !== r) continue;
    if (t === 'ice' && !e.ice.has(i + ',' + j)) continue; if (t !== 'ice' && e.ice.has(i + ',' + j)) continue;
    if (t === 'shield' && r !== 1 && e.habitatShields() < 2) continue; if (t !== 'shield' && r < 2) continue; if (e.canPlace(t, i, j).ok) return [i, j]; } return null; };
  const PRIORITY = ['habitat', 'oxygen', 'ice', 'recycler', 'greenhouse', 'reactor', 'solar', 'battery', 'fabricator', 'comms', 'lab'];
  const deciders = {
    smart: (em) => em.choices.filter((c) => c.available).sort((a, b) => b.points - a.points)[0].id,
    random: (em) => { const a = em.choices.filter((c) => c.available); return a[Math.floor(Math.random() * a.length)].id; },
    poor: (em) => em.choices.filter((c) => c.available).sort((a, b) => a.points - b.points)[0].id,
  };
  const mission = (p, D, who, maintain = true) => {
    const e = new Engine(p, D); e.autoDecide = deciders[who]; let k = 0;
    while (!e.over && e.t < D + 1) {
      if (k < PLANS[p].length) { const pos = free(e, PLANS[p][k]); if (pos) { place(e, PLANS[p][k], ...pos); k++; } }
      if (maintain) {
        const worn = [...e.buildings.values()].filter((b) => b.built && b.type !== 'shield' && b.type !== 'lander' && b.cond < 70).sort((a, b) => PRIORITY.indexOf(a.type) - PRIORITY.indexOf(b.type));
        for (const b of worn) if (e.res.mat >= e.repairCost(b) + 40) e.repair(b);
        if (e.landerCapLoss) e.repairLander();
        if (sol(e).some((b) => b.dust < 0.9) && e.canEVA()) e.clean();
        const opt = [...e.buildings.values()].filter((b) => b.type === 'lab' || b.type === 'fabricator');
        if (e.stats.ratio < 0.95 || (e.stats.prod < e.stats.demand && e.res.battery < e.stats.cap * 0.3)) opt.forEach((b) => (b.on = false));
        else if (e.res.battery > e.stats.cap * 0.6 || e.stats.prod > e.stats.demand + 3) opt.forEach((b) => (b.on = true));
      }
      for (let s = 0; s < 10 && !e.over; s++) { e.t += 0.01; e.env = e.computeEnv(e.t); e.step(0.01); fx(e); }
    }
    return e;
  };
  for (const p of ['mars', 'moon']) {
    const res = {};
    for (const who of ['smart', 'random', 'poor']) {
      const runs = who === 'smart' ? [30, 60, 90] : [90];
      for (const D of runs) {
        const e = mission(p, D, who);
        res[`${who}${D}`] = e;
        if (who === 'smart') ok(`[${p} ${D}d] Smart decisions + maintenance → Mission Complete`, e.result.win, `crew ${e.result.alive}/4, points ${e.points}, decisions ${e.decisions.length}, handled well ${e.report.emResolved}/${e.report.emResolved + e.report.emFailed}, min health ${e.report.minHealth.toFixed(0)}`);
      }
    }
    const s = res.smart90, r = res.random90, w = res.poor90;
    ok(`[${p} 90d] Smart decisions score more points than random, random more than poor`, s.points > r.points && r.points > w.points, `smart ${s.points} · random ${r.points} · poor ${w.points}`);
    const why = (e) => e.result.win ? 'won' : `lost day ${e.t.toFixed(0)}: ${e.decisions.slice(-4).map((d) => d.choice).join(' / ')}`;
    logs.push(`${p} random: ${why(r)} | poor: ${why(w)}`);
    logs.push(`${p} 90d — smart: win=${s.result.win} crew ${s.result.alive} pts ${s.points} | random: win=${r.result.win} crew ${r.result.alive} pts ${r.points} min health ${r.report.minHealth.toFixed(0)} | poor: win=${w.result.win} crew ${w.result.alive} pts ${w.points} min health ${w.report.minHealth.toFixed(0)} day ${w.t.toFixed(1)}`);
    const avgDose = (e) => e.crew.reduce((a, c) => a + c.dose, 0) / e.crew.length;
    ok(`[${p} 90d] Poor decisions hurt the mission (far fewer points, and lower health, failure or a much higher radiation dose)`, w.points < s.points * 0.5 && (!w.result.win || w.result.alive < 4 || w.report.minHealth < s.report.minHealth || avgDose(w) > avgDose(s) + 100), `poor: win=${w.result.win}, crew ${w.result.alive}, min health ${w.report.minHealth.toFixed(0)} vs smart ${s.report.minHealth.toFixed(0)}, avg dose ${avgDose(w).toFixed(0)} vs ${avgDose(s).toFixed(0)} mSv`);
    ok(`[${p} 90d] Points add up (decisions + outcome bonuses/penalties)`, Number.isFinite(s.points) && s.decisions.length >= 10, `${s.decisions.length} decisions`);
  }
  window.__ja.nasa.NasaData.disabled = false;
  return { out, logs };
}
