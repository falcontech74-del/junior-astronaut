// Long-mission QA. Runs inside the page with the real engine.
() => {
  const Engine = window.__ja.Engine;
  window.__ja.Modals.open = () => Promise.resolve(0);
  const out = []; const logs = [];
  const ok = (name, pass, detail = '') => out.push({ name, pass: !!pass, detail: String(detail) });
  const near = (a, b, tol) => Math.abs(a - b) <= tol;
  const step = (e, days, dt = 0.01) => { const n = Math.round(days / dt); for (let k = 0; k < n && !e.over; k++) { e.t += dt; e.env = e.computeEnv(e.t); e.step(dt); fx(e); } };
  const fx = (e) => e.effects.forEach((x) => { if (x.onDone && !x.done) { x.done = true; x.onDone(); } });
  const place = (e, t, i, j) => { e.ui.buildType = t; const r = e.place(i, j); e.ui.buildType = null; return r; };
  const finish = (e) => e.buildings.forEach((b) => { if (!b.built) e.completeBuilding(b); });
  const quiet = (p, d, t) => { const e = new Engine(p, d); e.events = []; if (t != null) e.t = t; e.env = e.computeEnv(e.t); return e; };

  // ---- 1. completion only after the full mission ----
  for (const p of ['mars', 'moon']) for (const D of [30, 60, 90]) {
    const e = quiet(p, D, D - 0.6); e.res.o2 = 150; e.res.water = 600; e.res.food = 300;
    step(e, 0.5);
    const before = e.over;
    step(e, 0.2);
    ok(`[${p} ${D}d] Not complete at Day ${D} morning; complete only after Day ${D} ends`, !before && e.over && e.result.win && e.t >= D, `t=${e.t.toFixed(2)} over=${e.over}`);
  }
  { const e = quiet('mars', 90, 30.5); e.res.o2 = 150; e.res.water = 600; e.res.food = 300; step(e, 1); ok('[90d] Surviving past Day 30 does NOT end a 90-day mission', !e.over); }

  // ---- 2. event schedule by duration ----
  for (const p of ['mars', 'moon']) {
    const counts = {};
    for (const D of [30, 60, 90]) {
      const e = new Engine(p, D);
      counts[D] = e.events.length;
      ok(`[${p} ${D}d] All scheduled events fall inside the mission`, e.events.every((x) => x.day > 0 && x.day < D), Math.max(...e.events.map((x) => x.day)).toFixed(1));
      const q = e.events.filter((x) => x.type === 'quiz').length;
      ok(`[${p} ${D}d] Quizzes spread over the mission (${q}) without running out of questions (27)`, q >= D / 4.2 && q <= 27, q);
    }
    ok(`[${p}] Longer missions get more events (30 < 60 < 90)`, counts[30] < counts[60] && counts[60] < counts[90], JSON.stringify(counts));
    // density of hazards rises with threat level
    let lo = 0, hi = 0;
    for (let k = 0; k < 20; k++) {
      const ev = new Engine(p, 90).events.filter((x) => ['failure', 'meteor', 'leak', 'contamination', 'illness', 'cropblight', 'battery_fault', 'quake', 'duststorm'].includes(x.type));
      lo += ev.filter((x) => x.day < 20).length / 20; hi += ev.filter((x) => x.day >= 70).length / 20;
    }
    ok(`[${p} 90d] Hazards per 10 days rise from threat I to IV`, hi / 20 * 10 > lo / 20 * 10 * 1.5, `I: ${(lo / 2).toFixed(1)} → IV: ${(hi / 2).toFixed(1)} per 10 days (avg of 20 schedules)`);
  }
  { const m = new Engine('moon', 90).events.filter((x) => x.type === 'dark_warn').map((x) => x.start);
    ok('[moon 90d] Three dark spells, one per lunar day (Days ~13, ~43, ~72)', m.length === 3 && near(m[1] - m[0], 29.53, 0.001) && near(m[2] - m[1], 29.53, 0.001), m.map((x) => x.toFixed(2)).join(', '));
    const e = quiet('moon', 90); ok('[moon] Dark again on Day 45 and 75, lit on Day 35 and 60', e.computeEnv(45).sunFactor < 0.01 && e.computeEnv(75).sunFactor < 0.01 && e.computeEnv(35).sunFactor > 0.99 && e.computeEnv(60).sunFactor > 0.99); }
  { const g30 = new Engine('mars', 30).events.some((x) => x.global), g90 = new Engine('mars', 90).events.filter((x) => x.global);
    ok('[mars] Global dust storm only on 60/90-day missions, in the second half', !g30 && g90.length === 1 && g90[0].day > 55, g90.map((x) => x.day.toFixed(1))); }
  { const e = new Engine('mars', 90); const types = new Set(e.events.map((x) => x.type));
    const ems = new Set(e.events.filter((x) => x.type === 'em').map((x) => x.em));
    ok('[90d] Emergency types are scheduled (air leak, contamination, illness, crop disease + interactive O₂/water/battery)', ['leak', 'contamination', 'illness', 'cropblight'].every((t) => types.has(t)) && ['o2fail', 'waterleak', 'batfail'].every((t) => ems.has(t)), [...types].join(',') + ' | ' + [...ems].join(',')); }
  { const e = new Engine('moon', 30); ok('[30d] No new emergencies before Day 20; only threat level II at Day 20', !e.events.some((x) => ['leak', 'illness'].includes(x.type) && x.day < 20) && e.events.filter((x) => x.type === 'phase').length === 1); }

  // ---- 3. threat levels & wear ----
  { const e = quiet('moon', 90, 2); const b = e.buildings.get(3); step(e, 1); const w0 = 100 - b.cond;
    const f = quiet('moon', 90, 72); const c = f.buildings.get(3); step(f, 1); const w3 = 100 - c.cond;
    ok('Equipment wear: 0.3%/day at threat I, 0.9%/day at threat IV', near(w0, 0.3, 0.02) && near(w3, 0.9, 0.03), `${w0.toFixed(2)} → ${w3.toFixed(2)} %/day`);
    ok('Worn equipment produces less (output ∝ condition)', (() => { const g = quiet('moon', 90, 2); const s = [...g.buildings.values()].find((x) => x.type === 'solar'); s.cond = 50; step(g, 0.01); return near(g.stats.prod, 8.5, 0.1); })()); }
  { const e = quiet('moon', 90, 2); e.buildings.get(1).cond = 40; const o = e.res.o2; step(e, 1);
    ok('Habitat under 50% leaks air (extra O₂ loss)', e.stats.flags.leak && (o - e.res.o2) > 3.36 + 2, (o - e.res.o2).toFixed(2));
    e.res.mat = 1000; const r0 = e.repairs; e.repair(e.buildings.get(1)); step(e, 0.05);
    ok('Repairing the habitat stops the leak and counts as a repair', !e.stats.flags.leak && e.repairs === r0 + 1); }

  // ---- 4. new emergencies ----
  { const e = quiet('mars', 90, 30); const o = e.res.o2; e.fireEvent({ type: 'leak' }); ok('Air leak: habitat ≤45% and 4 kg O₂ lost', e.buildings.get(1).cond <= 45 && near(o - e.res.o2, 4, 0.01)); }
  { const a = quiet('moon', 90, 30); a.res.water = 100; a.fireEvent({ type: 'contamination' });
    const b = quiet('moon', 90, 30); b.res.water = 100; b.res.mat = 1000; place(b, 'recycler', 8, 9); finish(b); b.fireEvent({ type: 'contamination' });
    ok('Water contamination: −25% without recycler, −5% with one', near(a.res.water, 75, 0.01) && near(b.res.water, 95, 0.01), `${a.res.water} / ${b.res.water}`); }
  { const e = quiet('moon', 90, 30); e.fireEvent({ type: 'illness' }); ok('Illness: one astronaut loses ~33% health (threat II)', e.crew.filter((c) => c.health < 70).length === 1); }
  { const e = quiet('moon', 90, 30); const f = e.res.food; e.fireEvent({ type: 'cropblight' }); const gh = [...e.buildings.values()].find((b) => b.type === 'greenhouse');
    ok('Crop disease: greenhouse to 65% (botanist), 8% food spoiled', gh.cond === 65 && near(e.res.food, f * 0.92, 0.01)); }
  { const e = quiet('moon', 90, 30); e.res.mat = 1000; place(e, 'battery', 4, 3); finish(e); e.res.battery = 170; e.fireEvent({ type: 'battery_fault' });
    const b = [...e.buildings.values()].find((x) => x.type === 'battery'); ok('Battery fault: bank to 30%, stored energy halved', b.cond === 30 && e.res.battery === 85); }
  { const e = quiet('moon', 90, 30); const n = e.events.length; e.fireEvent({ type: 'battery_fault' }); ok('Battery fault with no battery falls back to an equipment failure', [...e.buildings.values()].some((b) => b.cond === 20)); }
  { const e = quiet('moon', 90, 19.5); e.fireEvent({ type: 'dawn' }); const s = [...e.buildings.values()].find((b) => b.type === 'solar');
    ok('Moon dawn: charged dust settles on panels (86%)', s.dust === 0.86); e.t = 20; e.env = e.computeEnv(20); e.clean(); ok('Moon panels can be cleaned by EVA', s.dust === 1); }
  { const e = quiet('mars', 90, 10); e.fireEvent({ type: 'duststorm', dur: 3, peak: 0.6 }); e.fireEvent({ type: 'duststorm', dur: 8, peak: 0.93, global: true });
    ok('Overlapping dust storms merge (longest and strongest wins)', near(e.storm.until, 18, 0.01) && e.storm.peak === 0.93); }
  { const e = quiet('mars', 90, 75); e.fireEvent({ type: 'meteor' }); const m = e.effects.find((x) => x.kind === 'meteor'); m.onDone(); const hit = [...e.buildings.values()].find((b) => b.cond < 90);
    ok('Impacts hit harder at threat IV (×1.3, max 85%)', hit && 100 - hit.cond >= 45 * 1.3 - 1, hit && (100 - hit.cond).toFixed(0)); }
  { const e = quiet('moon', 90, 1); const m = e.res.mat; e.fireEvent({ type: 'milestone', m: 30 }); ok('Checkpoint gives +150 kg and is recorded', e.res.mat - m === 150 && e.milestonesDone.has(30)); }
  { ok('Checkpoints: 30d none, 60d Day 30, 90d Days 30 & 60', new Engine('moon', 30).milestones.length === 0 && new Engine('moon', 60).milestones.join() === '30' && new Engine('moon', 90).milestones.join() === '30,60'); }
  { const g = [30, 60, 90].map((D) => new Engine('mars', D).objectives.length); ok('Goals by length: 10 / 13 / 14', g.join() === '10,13,14', g.join()); }
  { const e = quiet('mars', 90, 2); e.res.science = 449; e.checkObjectives(); const a = e.objDone.has('science'); e.res.science = 450; e.checkObjectives();
    ok('Science goal scales (450 for 90 days) and now completes (bug fix)', !a && e.objDone.has('science')); }
  { ok('Mars cargo every 15 sols, Moon every 6 days', new Engine('mars', 90).cargoEvery === 15 && new Engine('moon', 90).cargoEvery === 6); }

  // ---- 5. depletion → failure ----
  { const e = quiet('moon', 90, 30); e.buildings.forEach((b) => { if (b.type === 'greenhouse') b.on = false; }); e.res.o2 = 6.72; step(e, 2.05);
    ok('Oxygen depletes at 3.36 kg/day (6.72 kg → empty after 2 days)', e.stats.flags.noO2 || e.res.o2 === 0); step(e, 2); ok('…then the crew is lost and the mission fails', e.over && !e.result.win); }

  // ---- 6. full simulations ----
  const PLANS = {
    mars: ['oxygen', 'solar', 'ice', 'recycler', 'solar', 'battery', 'solar', 'shield', 'shield', 'fabricator', 'solar', 'battery', 'comms', 'lab', 'solar', 'greenhouse', 'reactor', 'greenhouse', 'battery', 'shield', 'shield', 'shield', 'shield', 'oxygen'],
    moon: ['oxygen', 'ice', 'recycler', 'shield', 'shield', 'reactor', 'greenhouse', 'lab', 'comms', 'battery', 'fabricator', 'greenhouse', 'battery', 'shield', 'shield', 'shield', 'shield', 'reactor', 'solar'],
  };
  const free = (e, t) => { for (let r = 1; r < 8; r++) for (let i = 0; i < 14; i++) for (let j = 0; j < 14; j++) {
    const hd = Math.max(i < 6 ? 6 - i : i > 7 ? i - 7 : 0, j < 6 ? 6 - j : j > 7 ? j - 7 : 0); if (hd !== r) continue;
    if (t === 'ice' && !e.ice.has(i + ',' + j)) continue; if (t !== 'ice' && e.ice.has(i + ',' + j)) continue;
    if (t === 'shield' && r !== 1 && e.habitatShields() < 2) continue; if (t !== 'shield' && r < 2) continue; if (e.canPlace(t, i, j).ok) return [i, j]; } return null; };
  const PRIORITY = ['habitat', 'oxygen', 'ice', 'recycler', 'greenhouse', 'reactor', 'solar', 'battery', 'fabricator', 'comms', 'lab'];
  const simulate = (p, D, mode) => {
    const e = new Engine(p, D); let k = 0; const traj = []; e.autoDecide = (em) => em.choices.filter((c) => c.available).sort((a, b) => b.points - a.points)[0].id; const mins = { o2: 1e9, water: 1e9, food: 1e9 };
    while (!e.over && e.t < D + 1) {
      if (mode !== 'idle' && k < PLANS[p].length) { const pos = free(e, PLANS[p][k]); if (pos) { place(e, PLANS[p][k], ...pos); k++; } }
      if (mode === 'maintained') {
        // repair worn/damaged buildings (most important first), keeping a small reserve for construction
        const worn = [...e.buildings.values()].filter((b) => b.built && b.type !== 'shield' && b.type !== 'lander' && b.cond < 70).sort((a, b) => PRIORITY.indexOf(a.type) - PRIORITY.indexOf(b.type));
        for (const b of worn) if (e.res.mat >= e.repairCost(b) + 40) e.repair(b);
        if ([...e.buildings.values()].some((b) => b.type === 'solar' && b.dust < 0.9) && e.canEVA()) e.clean();
        // load management: switch science/fabrication off in a power crisis
        const opt = [...e.buildings.values()].filter((b) => b.type === 'lab' || b.type === 'fabricator');
        if (e.stats.ratio < 0.95 || (e.stats.prod < e.stats.demand && e.res.battery < e.stats.cap * 0.3)) opt.forEach((b) => (b.on = false));
        else if (e.res.battery > e.stats.cap * 0.6 || e.stats.prod > e.stats.demand + 3) opt.forEach((b) => (b.on = true));
      }
      for (let s = 0; s < 10 && !e.over; s++) { e.t += 0.01; e.env = e.computeEnv(e.t); e.step(0.01); fx(e); }
      for (const r of ['o2', 'water', 'food']) mins[r] = Math.min(mins[r], e.res[r]);
      if (Math.abs(e.t % 10) < 0.1 && e.t > 1) traj.push(`d${Math.round(e.t)}: O₂ ${e.res.o2.toFixed(0)} · H₂O ${e.res.water.toFixed(0)} · food ${e.res.food.toFixed(0)} · mat ${e.res.mat.toFixed(0)} · crew ${e.crewActive()} · hp ${Math.min(...e.crew.map((c) => c.status === 'active' ? c.health : 100)).toFixed(0)}`);
    }
    return { e, traj, mins };
  };
  for (const p of ['mars', 'moon']) {
    for (const D of [30, 60, 90]) {
      const { e, traj, mins } = simulate(p, D, 'maintained');
      if (D === 90) var m90 = e;
      ok(`[${p} ${D}d] Maintained base survives all ${D} days → Mission Complete`, e.over && e.result.win && e.t >= D, `crew ${e.result.alive}/4, stars ${e.result.stars}, goals ${e.objDone.size}/${e.objectives.length}, repairs ${e.repairs}, emergencies ${e.report.emergencies}, min health ${e.report.minHealth.toFixed(0)}`);
      ok(`[${p} ${D}d] O₂, water and food never run out (balanced)`, mins.o2 > 0 && mins.water > 0 && mins.food > 0, `minimums O₂ ${mins.o2.toFixed(1)}, water ${mins.water.toFixed(0)}, food ${mins.food.toFixed(0)}`);
      ok(`[${p} ${D}d] Stocks stay within storage limits`, e.res.o2 <= 150 && e.res.water <= 600 && e.res.food <= 300 && e.res.mat <= 2500, `end: O₂ ${e.res.o2.toFixed(0)}, water ${e.res.water.toFixed(0)}, food ${e.res.food.toFixed(0)}, mat ${e.res.mat.toFixed(0)}`);
      if (D === 90) logs.push(`${p} maintained 90d:\n  ` + traj.join('\n  '));
    }
    const n = simulate(p, 90, 'neglected');
    const ms = m90.result.stem, ns = n.e.result.stem;
    ok(`[${p} 90d] Same buildings but no repairs/cleaning → much worse (fails, loses crew, or a clearly lower survival score)`, !n.e.result.win || n.e.result.alive < 4 || n.e.report.minHealth < 50 || ns.total <= ms.total - 5, (n.e.result.win ? `won with ${n.e.result.alive}/4, min health ${n.e.report.minHealth.toFixed(0)}` : `failed on day ${n.e.t.toFixed(1)}`) + ` · score ${ns.total} (${ns.rank}) vs maintained ${ms.total} (${ms.rank}); equipment ${Math.round(ns.avgCond)}% vs ${Math.round(ms.avgCond)}%`);
    logs.push(`${p} neglected 90d:\n  ` + n.traj.join('\n  '));
    const i = simulate(p, 90, 'idle');
    ok(`[${p} 90d] Building nothing → mission fails early`, i.e.over && !i.e.result.win && i.e.t < 12, `day ${i.e.t.toFixed(1)}`);
  }
  return { out, logs };
}
