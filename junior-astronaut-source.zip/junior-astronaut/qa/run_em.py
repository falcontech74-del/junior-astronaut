import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
import json
from playwright.sync_api import sync_playwright
src = open(ROOT + '/qa/em_tests.js').read()
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    pg = b.new_page(viewport={'width': 600, 'height': 400}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.set_default_timeout(600000)
    pg.goto(URL); pg.wait_for_timeout(800)
    res = pg.evaluate(src)
    for r in res['out']: print(('PASS ' if r['pass'] else 'FAIL ') + r['name'] + (f"  [{r['detail']}]" if r['detail'] else ''))
    print('\n'.join(res['logs']))
    print(f"\n{sum(r['pass'] for r in res['out'])}/{len(res['out'])} passed; page errors: {errs}")
    b.close()
