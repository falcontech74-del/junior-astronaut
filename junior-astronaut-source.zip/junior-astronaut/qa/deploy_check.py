import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
# Deployment checks: HTTP headers match vercel.json, hashed assets are cached, the strict Content-Security-Policy
# blocks nothing the game needs (fonts, NASA DONKI API, WebGL, audio), Mars and Moon missions start on the served
# build, and the single-file standalone build also works from disk.
import json, re, time, urllib.request, urllib.error
from playwright.sync_api import sync_playwright

R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)

ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']
VERCEL = json.load(open(ROOT + '/vercel.json'))
CSP = [h['value'] for r in VERCEL['headers'] if r['source'] == '/(.*)' for h in r['headers'] if h['key'] == 'Content-Security-Policy'][0]
LOCAL = URL.startswith('http://127.0.0.1') or URL.startswith('http://localhost')

def get(path):
    try:
        r = urllib.request.urlopen(URL.rstrip('/') + path, timeout=20); return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), b''

# ---------- HTTP level ----------
st, hd, body = get('/')
html = body.decode('utf8', 'replace')
ok('GET / returns 200 text/html', st == 200 and 'text/html' in hd.get('Content-Type', ''), st)
ok('Content-Security-Policy header matches vercel.json', hd.get('Content-Security-Policy') == CSP)
ok('Security headers present (nosniff, referrer, permissions)', hd.get('X-Content-Type-Options') == 'nosniff' and 'Referrer-Policy' in hd and 'Permissions-Policy' in hd)
ok('HTML shell is small (game code is in a separate cached file)', len(body) < 150_000, f'{len(body) // 1024} KB')
ok('Loading screen is in the HTML (shows before the 3D engine loads)', 'id="loading"' in html)
ok('No inline <script> in the deployed HTML (strict CSP)', not re.search(r'<script(?![^>]*\bsrc=)[^>]*>', html))
assets = re.findall(r'<script defer src="(assets/[a-z]+\.[0-9a-f]{10}\.js)"></script>', html)
ok('HTML loads hashed app + boot bundles with defer', len(assets) == 2 and assets[0].startswith('assets/app.'), assets)
for a in assets:
    st, hd2, b = get('/' + a)
    ok(f'{a}: 200, JavaScript, cached 1 year immutable', st == 200 and 'javascript' in hd2.get('Content-Type', '') and 'immutable' in hd2.get('Cache-Control', ''), f'{len(b) // 1024} KB, {hd2.get("Cache-Control")}')
st, _, _ = get('/no-such-page')
ok('Unknown path returns 404', st == 404, st)
ok('Description, theme-color and icon meta tags present', 'name="description"' in html and 'theme-color' in html and 'rel="icon"' in html)

# ---------- browser level ----------
CSP_HOOK = "window.__csp = []; document.addEventListener('securitypolicyviolation', e => window.__csp.push(e.violatedDirective + ' ' + e.blockedURI));"
NASA_ROWS = {'FLR': [], 'CME': [], 'SEP': []}

def play(b, url, label, mobile=False, mock_nasa=True):
    vp = {'width': 412, 'height': 860} if mobile else {'width': 1366, 'height': 768}
    ctx = b.new_context(viewport=vp, is_mobile=mobile, has_touch=mobile, device_scale_factor=2 if mobile else 1)
    ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))")
    ctx.add_init_script(CSP_HOOK)
    pg = ctx.new_page(); errs = []; nasa_reqs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc.gsfc.nasa.gov' not in (m.location or {}).get('url', '') and 'fonts.g' not in (m.location or {}).get('url', '') and 'Failed to load resource' not in m.text else None)
    pg.on('request', lambda r: nasa_reqs.append(r.url) if 'ccmc.gsfc.nasa.gov' in r.url else None)
    if mock_nasa:  # the test sandbox cannot reach NASA; answer like the real API so the CSP connect-src rule is exercised
        pg.route('https://ccmc.gsfc.nasa.gov/**', lambda r: r.fulfill(status=200, content_type='application/json', body='[]', headers={'Access-Control-Allow-Origin': '*'}))
    t0 = time.time(); pg.goto(url, wait_until='domcontentloaded')
    pg.wait_for_selector('#main-menu', timeout=30000); t_menu = time.time() - t0
    pg.wait_for_function("() => !document.getElementById('loading')", timeout=15000)
    ok(f'{label}: main menu ready, loading screen removed', True, f'{t_menu:.1f}s to menu')
    for planet in ['mars', 'moon']:
        pg.evaluate(f"() => window.__ja.start('{planet}', 30)")
        pg.wait_for_selector('#hud', timeout=20000); pg.wait_for_timeout(2500)
        info = pg.evaluate("() => ({ planet: window.__ja.engine && window.__ja.engine.planet.id, canvas: !!document.querySelector('#scene canvas'), gl: (() => { const c = document.querySelector('#scene canvas'); return !!(c && (c.getContext('webgl2') || c.getContext('webgl'))); })(), body: document.body.dataset.planet })")
        ok(f'{label}: {planet.title()} mission runs (engine + WebGL canvas + HUD)', info['planet'] == planet and info['canvas'] and info['gl'], info)
        pg.evaluate("() => { const e = window.__ja.engine; for (let i = 0; i < 150 && !e.over; i++) { window.__ja.Modals.clear(); e.t += 0.01; e.env = e.computeEnv(e.t); e.step(0.01); } window.__ja.Modals.clear(); }")
        day = pg.evaluate("() => window.__ja.engine.t")
        ok(f'{label}: {planet.title()} simulation advances', day >= 1.0, f'day {day:.2f}')
        if planet == 'mars': pg.screenshot(path=ROOT + f'/qa/results/shots/deploy_{label.replace(" ", "_")}_{planet}.png')
        pg.evaluate("() => window.__ja.toTitle()"); pg.wait_for_selector('#main-menu', timeout=10000)
    csp = pg.evaluate('() => window.__csp')
    ok(f'{label}: no Content-Security-Policy violations', csp == [], csp)
    if mock_nasa:
        ok(f'{label}: NASA DONKI API request allowed by CSP', len(nasa_reqs) >= 3, f'{len(nasa_reqs)} requests')
    ok(f'{label}: no page errors', errs == [], errs[:3])
    ctx.close()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=ARGS)
    play(b, URL, 'served desktop', mock_nasa=LOCAL)
    play(b, URL, 'served phone', mobile=True, mock_nasa=LOCAL)
    sa = ROOT + '/dist-standalone/junior-astronaut.html'
    if os.path.exists(sa):
        play(b, 'file://' + sa, 'standalone file')
    else:
        ok('standalone file exists (run npm run build)', False)
    b.close()
print(f'\n{sum(R)}/{len(R)} passed')
