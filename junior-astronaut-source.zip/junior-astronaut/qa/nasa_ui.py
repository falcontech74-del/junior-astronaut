import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
# NASA DONKI integration QA: loading, live (mocked network with real archived DONKI records), HTTP error,
# blocked network, timeout, title badge, Data Sources panel, radiation alert card, phone layout.
import sys, json, re, urllib.parse
from playwright.sync_api import sync_playwright
R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)
RAW = {k: json.load(open(ROOT + f'/tools/donki-archive/{k}.json')) for k in ['flares', 'cmes', 'seps']}
def raw(kind, x):  # rebuild DONKI-API-shaped records from the archived real records (test fixture)
    le = [{'activityID': i} for i in x['linked']]
    if kind == 'FLR': return {'flrID': x['id'], 'beginTime': x['begin'], 'peakTime': x['time'], 'classType': x['cls'], 'sourceLocation': x['loc'], 'activeRegionNum': x['ar'], 'instruments': [{'displayName': x['inst']}], 'link': x['link'], 'linkedEvents': le}
    if kind == 'CME': return {'activityID': x['id'], 'startTime': x['time'], 'sourceLocation': x['loc'], 'link': x['link'], 'linkedEvents': le, 'cmeAnalyses': [{'isMostAccurate': True, 'speed': x['speed'], 'halfAngle': x['halfAngle'], 'type': x['type']}]}
    return {'sepID': x['id'], 'eventTime': x['time'], 'instruments': [{'displayName': x['inst']}], 'link': x['link'], 'linkedEvents': le}
SRC = {'FLR': 'flares', 'CME': 'cmes', 'SEP': 'seps'}
def mock_live(route):
    u = urllib.parse.urlparse(route.request.url); kind = u.path.rstrip('/').split('/')[-1]; q = urllib.parse.parse_qs(u.query)
    s, e = q['startDate'][0], q['endDate'][0] + 'T23:59Z'
    rows = [raw(kind, x) for x in RAW[SRC[kind]] if s <= x['time'] <= e]
    route.fulfill(status=200, content_type='application/json', body=json.dumps(rows), headers={'Access-Control-Allow-Origin': '*'})

def no_overflow(pg):  # content must fit the card width (the emergency icon's bobbing animation is ignored)
    return pg.evaluate("() => { const c = document.querySelector('#modal .m-body'); return !!c && c.scrollWidth <= c.clientWidth + 1; }")
SEEN = '''window.__seen = []; new MutationObserver(() => { const b = document.querySelector('#nasa-badge'); if (b && window.__seen.at(-1) !== b.dataset.status) window.__seen.push(b.dataset.status); }).observe(document, { subtree: true, childList: true, attributes: true });'''

def suite(b, mode, mobile):
    tag = f'[{mode} {"phone" if mobile else "desktop"}]'; sfx = f'{mode}_{"m" if mobile else "d"}'
    ctx = b.new_context(viewport={'width': 390, 'height': 844} if mobile else {'width': 1440, 'height': 900}, device_scale_factor=2 if mobile else 1, is_mobile=mobile, has_touch=mobile); ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))")
    pg = ctx.new_page(); errs = []; reqs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc' not in m.text and 'Failed to load resource' not in m.text else None)
    pg.on('request', lambda r: reqs.append(r.url) if 'ccmc.gsfc.nasa.gov' in r.url else None)
    if mode == 'live': pg.route('https://ccmc.gsfc.nasa.gov/DONKI-API/**', mock_live)
    if mode == 'http503': pg.route('https://ccmc.gsfc.nasa.gov/DONKI-API/**', lambda r: r.fulfill(status=503, body='down', headers={'Access-Control-Allow-Origin': '*'}))
    if mode == 'blocked': pg.route('https://ccmc.gsfc.nasa.gov/DONKI-API/**', lambda r: r.abort('connectionrefused'))
    hold = []
    if mode == 'timeout': pg.route('https://ccmc.gsfc.nasa.gov/DONKI-API/**', lambda r: hold.append(r))  # never answers
    pg.add_init_script(SEEN)
    pg.goto(URL); pg.wait_for_timeout(500)
    click = (lambda loc: loc.tap()) if mobile else (lambda loc: loc.click())
    badge = pg.locator('#nasa-badge')
    ok(f'{tag} NASA DATA INSIDE badge on the title screen', badge.count() == 1 and 'NASA DATA INSIDE' in badge.inner_text())
    st0 = badge.get_attribute('data-status')
    if mode == 'timeout':
        ok(f'{tag} While waiting, the badge says it is connecting', 'Connecting' in badge.inner_text())
        pg.evaluate("() => { const N = window.__ja.nasa; N.NasaData.status = 'idle'; return N.loadDonki({ timeoutMs: 2500 }); }")
    want = 'live' if mode == 'live' else 'archived'
    try: pg.wait_for_function(f"() => document.querySelector('#nasa-badge').dataset.status === '{want}'", timeout=30000)
    except Exception: pass
    st = badge.get_attribute('data-status')
    seen = pg.evaluate('() => window.__seen')
    ok(f'{tag} Badge showed "Connecting…" (loading) before the result', 'loading' in seen and seen[-1] == want and seen.index('loading') < len(seen) - 1, ' → '.join(seen))
    ok(f'{tag} Ends in the correct state: {want}', st == want, f'{st}: {badge.inner_text()!r}')
    ok(f'{tag} Requests go to the official DONKI API (ccmc.gsfc.nasa.gov/DONKI-API)', reqs and all(u.startswith('https://ccmc.gsfc.nasa.gov/DONKI-API/get/') for u in reqs) and {'FLR', 'CME', 'SEP'} <= {re.search(r'/get/(\w+)', u).group(1) for u in reqs}, f'{len(reqs)} requests')
    ok(f'{tag} Badge text matches the state (never says live when archived)', ('Live from NASA DONKI' in badge.inner_text()) == (want == 'live') and (('Archived' in badge.inner_text()) == (want == 'archived')), badge.inner_text().replace('\n', ' | '))
    # ---- Data Sources panel from the badge ----
    click(badge); pg.wait_for_timeout(400)
    m = pg.locator('#modal .modal-card[data-custom="sources"]')
    ok(f'{tag} Badge opens the Data Sources panel', m.count() == 1)
    stt = pg.inner_text('#src-status')
    if want == 'live': ok(f'{tag} Panel says the data is live, with download time', 'Live data from NASA' in stt and 'UTC' in stt and 'Archived' not in stt, stt[:140])
    else:
        reason = {'http503': 'HTTP 503', 'blocked': 'Failed to fetch', 'timeout': 'no answer within'}[mode]
        ok(f'{tag} Panel says archived, not live, gives the reason and the retrieval date', 'Archived NASA data, not live' in stt and reason in stt and '14 Nov 2026' in stt, stt[:200])
        ok(f'{tag} Retry button offered', pg.locator('#src-retry').count() == 1)
        if mode == 'blocked': ok(f'{tag} Explains a blocked connection (offline or host blocks outside connections)', 'blocks outside connections' in stt)
    rows = pg.locator('#src-seps .src-row').count(); tags = pg.locator('#src-seps .tag').all_inner_texts()
    ok(f'{tag} Lists real SEP storms with dates, type and DONKI links', rows >= 4 and pg.locator('#src-seps a[href^="https://ccmc.gsfc.nasa.gov/DONKI/view/SEP/"]').count() == rows, f'{rows} storms')
    ok(f'{tag} Every listed event is labelled {"LIVE" if want == "live" else "ARCHIVED"}', tags and all(t == ('LIVE NASA RECORD' if want == 'live' else 'ARCHIVED NASA RECORD') for t in tags + pg.locator('#src-flares .tag, #src-cmes .tag').all_inner_texts()))
    ok(f'{tag} Flares and fast CMEs listed with DONKI links', pg.locator('#src-flares a[href*="/DONKI/view/FLR/"]').count() >= 5 and pg.locator('#src-cmes a[href*="/DONKI/view/CME/"]').count() >= 5)
    links = pg.eval_on_selector_all('.src-links a', 'as => as.map(a => a.href)')
    ok(f'{tag} Original NASA links shown (DONKI page, web app, API docs, user guide)', links == ['https://ccmc.gsfc.nasa.gov/tools/DONKI/', 'https://ccmc.gsfc.nasa.gov/DONKI/', 'https://ccmc.gsfc.nasa.gov/DONKI/api/', 'https://ccmc.gsfc.nasa.gov/DONKI/guide/'], links)
    ok(f'{tag} Panel states game values are simulated', 'simulated values, not NASA measurements' in m.inner_text())
    ok(f'{tag} Panel fits the screen', no_overflow(pg))
    pg.screenshot(path=ROOT + f'/qa/results/shots/NASA_{sfx}_sources.png')
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    # ---- radiation alert inside the game ----
    btn = pg.locator('button.launch[data-planet="moon"]'); btn.scroll_into_view_if_needed(); click(btn); pg.wait_for_timeout(2500)
    pg.locator('#modal .m-btns .btn.primary').click(); pg.wait_for_timeout(300)
    pg.evaluate("() => { const e = window.__ja.engine; e.events = []; e.setSpeed(0); }")
    em = pg.evaluate("() => { const e = window.__ja.engine; const em = e.triggerEmergency('radiation'); return { dose: em.dose, base: em.baseDose, s: em.nasa && em.nasa.strength, src: em.nasa && em.nasa.src, link: em.nasa && em.nasa.link, t: em.nasa && em.nasa.firstObs }; }")
    pg.wait_for_timeout(500)
    card = pg.locator('#modal .nasa-card')
    ok(f'{tag} Radiation alert shows the real NASA event card', card.count() == 1 and 'Solar Energetic Particle event (SEP)' in card.inner_text(), em)
    ok(f'{tag} Card shows event date, type and NASA source link', em['t'][:10] and pg.locator('#modal .nasa-card a').first.get_attribute('href') == em['link'] and em['link'].startswith('https://ccmc.gsfc.nasa.gov/DONKI/view/SEP/'))
    ok(f'{tag} Card labelled {"LIVE" if want == "live" else "ARCHIVED"} correctly', card.get_attribute('data-src') == em['src'] == want and (('LIVE NASA RECORD' if want == 'live' else 'ARCHIVED NASA RECORD') in card.inner_text()))
    fac = {'strong': 1.25, 'moderate': 1, 'minor': 0.8}[em['s']]
    ok(f'{tag} Simulated dose follows the real event strength ({em["s"]} ×{fac}) and is labelled SIMULATED', abs(em['dose'] - round(em['base'] * fac)) <= 1 and 'SIMULATED' in card.inner_text() and f"{em['dose']} mSv" in card.inner_text(), f"{em['base']} → {em['dose']}")
    click(card.locator('summary')); pg.wait_for_timeout(250)
    ok(f'{tag} "Why shielding matters" explanation opens', 'Shielding works by putting' in card.inner_text() and 'radiation sickness' in card.inner_text())
    ok(f'{tag} Alert still fits the screen', no_overflow(pg))
    pg.screenshot(path=ROOT + f'/qa/results/shots/NASA_{sfx}_alert.png')
    c = pg.locator('#modal .em-choice[data-choice="shelter"]'); c.scroll_into_view_if_needed(); click(c); pg.wait_for_timeout(500)
    ok(f'{tag} Choices and debrief still work', pg.locator('#modal .modal-card[data-custom="debrief"]').count() == 1)
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    # second alert uses a different real storm
    em2 = pg.evaluate("() => { const e = window.__ja.engine; e.autoDecide = () => 'shelter'; const em = e.triggerEmergency('radiation'); e.autoDecide = null; return em.nasa && em.nasa.id; }")
    ok(f'{tag} Next radiation alert uses a different real storm', em2 and em2 != pg.evaluate("() => null") and em2 not in [None], em2)
    # pause menu entry
    click(pg.locator('#btn-menu')); pg.wait_for_timeout(300)
    mb = pg.locator('#modal .btn', has_text='NASA data sources'); ok(f'{tag} Pause menu has "NASA data sources"', mb.count() == 1)
    click(mb); pg.wait_for_timeout(400)
    ok(f'{tag} …and it opens the panel', pg.locator('#modal .modal-card[data-custom="sources"]').count() == 1)
    ok(f'{tag} No runtime errors', not errs, errs[:3])
    for r in hold:
        try: r.abort()
        except Exception: pass
    ctx.close()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    for arg in sys.argv[1:]:
        mode, dev = arg.split('-'); suite(b, mode, dev == 'phone')
    b.close()
print(f'\n{sum(R)}/{len(R)} passed')
