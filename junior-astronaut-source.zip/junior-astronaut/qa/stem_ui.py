import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
import sys
from playwright.sync_api import sync_playwright
R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)
def E(pg, js): return pg.evaluate('() => { const e = window.__ja.engine; ' + js + ' }')
SETUP = '''e.events = []; e.setSpeed(0); e.res.mat = 2000;
  const P = (t,i,j) => { e.ui.buildType = t; e.place(i,j); e.ui.buildType = null; };
  P('oxygen',9,4); P('battery',4,3); P('recycler',8,9); P('lab',9,9); P('fabricator',9,6); P('ice',0,0);
  e.buildings.forEach(b => { if (!b.built) e.completeBuilding(b); }); e.res.mat = 1000; e.res.water = 300; e.res.o2 = 100; e.t = Math.floor(e.t) + 0.5; e.env = e.computeEnv(e.t);'''

def no_overflow(pg):
    return pg.evaluate("() => { const c = document.querySelector('#modal .modal-card'); return c && c.scrollWidth <= c.clientWidth + 1; }")

def suite(b, planet, mobile):
    tag = f'[{planet.upper()} {"phone" if mobile else "desktop"}]'; sfx = f'{planet}_{"m" if mobile else "d"}'
    ctx = b.new_context(viewport={'width': 390, 'height': 844} if mobile else {'width': 1440, 'height': 900}, device_scale_factor=2 if mobile else 1, is_mobile=mobile, has_touch=mobile); ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))")
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc.gsfc.nasa.gov' not in (m.location or {}).get('url', '') else None)  # the sandbox cannot reach NASA: the failed request is expected (game falls back to archived data)
    pg.goto(URL); pg.wait_for_timeout(900)
    click = (lambda loc: loc.tap()) if mobile else (lambda loc: loc.click())
    btn = pg.locator(f'button.launch[data-planet="{planet}"]'); btn.scroll_into_view_if_needed(); click(btn); pg.wait_for_timeout(3000)
    pg.locator('#modal .m-btns .btn.primary').click(); pg.wait_for_timeout(300)
    E(pg, SETUP); E(pg, 'e.setSpeed(4);'); pg.wait_for_timeout(2500 if not mobile else 3500); E(pg, 'e.setSpeed(0);'); pg.wait_for_timeout(300)
    E(pg, 'window.__ja.Toasts && 0;')

    # 1. science explainers from the resource chips
    click(pg.locator('#r-o2')); pg.wait_for_timeout(400)
    m = pg.locator('#modal .modal-card[data-custom="systems"]')
    ok(f'{tag} Tapping the oxygen chip opens the Oxygen science explainer', m.count() == 1 and 'What the crew needs' in m.inner_text() and m.locator('[data-tab="o2"].primary').count() == 1)
    flows = m.locator('.sy-flow').all_inner_texts()
    ok(f'{tag} Oxygen explainer shows the live base breakdown (crew breathing, generator, net)', any('Crew breathing' in f for f in flows) and any('O₂ generators' in f for f in flows) and any('Net balance' in f for f in flows), ' | '.join(f.replace('\n', ' ') for f in flows))
    ok(f'{tag} Science points are tagged REAL / GAME', m.locator('.sy-item .tag.real').count() >= 3 and m.locator('.sy-item .tag.game').count() >= 1)
    ok(f'{tag} Explainer includes an engineer tip and a planet fact', m.locator('.sy-tip').count() == 1 and 'Did you know?' in m.locator('.fact').inner_text())
    ok(f'{tag} Explainer fits the screen (no sideways scrolling)', no_overflow(pg))
    pg.screenshot(path=ROOT + f'/qa/results/shots/STEM_{sfx}_o2.png')
    for k, needle in [('water', 'Water recycler'), ('food', 'Crew meals'), ('energy', 'Habitat life support'), ('radiation', '/ 600 mSv')]:
        click(m.locator(f'[data-tab="{k}"]')); pg.wait_for_timeout(250)
        ok(f'{tag} {k} tab shows its science and live numbers', needle in m.inner_text() and m.locator('.sy-item').count() >= 4, needle)
        if k == 'energy': pg.screenshot(path=ROOT + f'/qa/results/shots/STEM_{sfx}_energy.png')
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    ok(f'{tag} Explainer closes', pg.locator('#modal').count() == 0)
    # power chip keeps its detail and gains a Why? link
    click(pg.locator('#r-power')); pg.wait_for_timeout(250)
    ok(f'{tag} Power chip shows making/using detail', pg.locator('#power-detail').is_visible() and 'Making' in pg.inner_text('#power-detail'))
    click(pg.locator('#power-learn')); pg.wait_for_timeout(300)
    ok(f'{tag} "Why?" on the power chip opens the Energy explainer', pg.locator('#modal [data-tab="energy"].primary').count() == 1)
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    # crew panel → radiation
    click(pg.locator('#r-crew')); pg.wait_for_timeout(300)
    cl = pg.locator('#crew-learn'); cl.scroll_into_view_if_needed(); click(cl); pg.wait_for_timeout(300)
    ok(f'{tag} Crew panel link opens the Radiation explainer', pg.locator('#modal [data-tab="radiation"].primary').count() == 1)
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    if pg.locator('#crew:not(.collapsed)').count(): click(pg.locator('#r-crew')); pg.wait_for_timeout(200)
    # menu entry
    click(pg.locator('#btn-menu')); pg.wait_for_timeout(300)
    mb = pg.locator('#modal .btn', has_text='Life-support science'); ok(f'{tag} Pause menu has a Life-support science entry', mb.count() == 1)
    click(mb); pg.wait_for_timeout(400)
    ok(f'{tag} Menu entry opens the explainer', pg.locator('#modal .modal-card[data-custom="systems"]').count() == 1)
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    if not mobile: ok(f'{tag} 🔬 toolbar button present on desktop', pg.locator('#btn-science').count() == 1)

    # 3. fact toast
    fact = E(pg, 'return e.showFact();'); pg.wait_for_timeout(300)
    ok(f'{tag} "Did you know?" fact appears as a toast', pg.locator('#toasts .toast.fact').count() >= 1 and fact[:30] in pg.inner_text('#toasts'), fact)

    # 2 + 4. debrief after a decision
    E(pg, "e.res.battery = 10; e.buildings.forEach(b => { if (b.type === 'reactor') e.demolish && 0; });")
    E(pg, "e.triggerEmergency('batfail');"); pg.wait_for_timeout(500)
    c = pg.locator('#modal .em-choice[data-choice="gamble"]'); c.scroll_into_view_if_needed(); click(c); pg.wait_for_timeout(500)
    db = pg.locator('#modal .modal-card[data-custom="debrief"]')
    ok(f'{tag} Risky decision → debrief says "Poor call" and why', db.count() == 1 and 'Poor call' in db.locator('.db-verdict').inner_text() and 'thermal runaway' in db.inner_text().lower())
    ok(f'{tag} Debrief names a better option', db.locator('.db-sec.better').count() == 1, db.locator('.db-sec.better').inner_text().replace('\n', ' ') if db.locator('.db-sec.better').count() else '')
    ok(f'{tag} Debrief fits the screen', no_overflow(pg))
    pg.screenshot(path=ROOT + f'/qa/results/shots/STEM_{sfx}_debrief_poor.png')
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)
    E(pg, "e.res.mat = 1000; e.triggerEmergency('o2fail');"); pg.wait_for_timeout(500)
    c = pg.locator('#modal .em-choice[data-choice="repair"]'); c.scroll_into_view_if_needed(); click(c); pg.wait_for_timeout(500)
    txt = pg.locator('#modal').inner_text()
    ok(f'{tag} Sound decision → debrief praises it and shows the resources spent', ('Best call' in pg.locator('#modal .db-verdict').inner_text() or 'Good call' in pg.locator('#modal .db-verdict').inner_text()) and 'why this worked' in txt.lower() and '🧱 −' in txt, pg.locator('#modal h2').inner_text())
    pg.screenshot(path=ROOT + f'/qa/results/shots/STEM_{sfx}_debrief_good.png')
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(300)

    # 5 + 6. final report with rank
    E(pg, "e.t = e.days; e.quizScore = 18; e.quizCount = 20; e.endGame(true);"); pg.wait_for_timeout(800)
    md = pg.locator('#modal')
    ok(f'{tag} Final report keeps its title and adds an astronaut rank', 'Mission Complete!' in md.locator('h2').inner_text() and md.locator('#rank').count() == 1, md.locator('#rank').get_attribute('data-rank'))
    rank = md.locator('#rank').get_attribute('data-rank'); score = int(md.locator('#surv-score').inner_text())
    ok(f'{tag} Rank matches the survival score shown ({score}/100)', rank == E(pg, 'return e.result.rank;') and score == E(pg, 'return e.result.stem.total;') and rank in ('gold', 'silver', 'bronze'), f'{rank} {score}')
    body = md.inner_text()
    ok(f'{tag} Report has score breakdown, crew health, resources and engineering sections', md.locator('.sc-row').count() == 5 and md.locator('.rp-crew').count() == 4 and all(s in body.upper() for s in ['SURVIVAL SCORE BREAKDOWN', 'CREW HEALTH', 'RESOURCES', 'ENGINEERING PERFORMANCE']))
    ok(f'{tag} Engineering section lists decision quality and every graded decision', 'Decision quality' in body and md.locator('.rp-dec').count() == E(pg, 'return e.decisions.filter(d => d.grade).length;'))
    ok(f'{tag} Original report rows still present', all(s in body for s in ['Days survived', 'Emergencies survived', 'Mission points', 'Mission score']) and f"{E(pg, 'return e.days;')} / {E(pg, 'return e.days;')}" in body)
    ok(f'{tag} Report fits the screen', no_overflow(pg))
    btns = md.locator('.m-btns .btn').all_inner_texts(); ok(f'{tag} End buttons unchanged', len(btns) == 3 and 'Fly again' in btns[0], btns)
    pg.screenshot(path=ROOT + f'/qa/results/shots/STEM_{sfx}_report_top.png')
    pg.evaluate("() => { const c = document.querySelector('#modal .modal-card'); c.scrollTop = c.scrollHeight * 0.45; }"); pg.wait_for_timeout(200)
    pg.screenshot(path=ROOT + f'/qa/results/shots/STEM_{sfx}_report_mid.png')
    click(md.locator('.m-btns .btn').first); pg.wait_for_timeout(3000)
    ok(f'{tag} "Fly again" restarts a fresh mission', E(pg, 'return !!e && !e.over && e.t < 1;'))
    ok(f'{tag} No runtime errors', not errs, errs[:3])
    ctx.close()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    for arg in sys.argv[1:]:
        planet, dev = arg.split('-'); suite(b, planet, dev == 'phone')
    b.close()
print(f'\n{sum(R)}/{len(R)} passed')
