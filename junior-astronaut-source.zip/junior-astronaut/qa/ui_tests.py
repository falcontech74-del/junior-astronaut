import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
import json, sys, math
from playwright.sync_api import sync_playwright

RESULTS = []
def ok(name, cond, detail=''):
    RESULTS.append((bool(cond), name, str(detail)))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{detail}]' if detail != '' else ''), flush=True)

ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']
COST = {'solar': 80, 'battery': 100, 'reactor': 420, 'oxygen': 150, 'ice': 150, 'recycler': 120, 'greenhouse': 200, 'shield': 40, 'fabricator': 180, 'lab': 200, 'comms': 120}

def E(pg, js):
    return pg.evaluate('() => { const e = window.__ja.engine; ' + js + ' }')

def cam(pg):
    return pg.evaluate('''() => { const c = window.__ja.controls; return { az: c.getAzimuthalAngle(), pol: c.getPolarAngle(), dist: c.getDistance(), tx: c.target.x, tz: c.target.z }; }''')

def hud_num(pg, sel):
    t = pg.inner_text(sel)
    return float(''.join(ch for ch in t.split(' ')[0] if ch in '0123456789.-−').replace('−', '-').replace(',', '') or 'nan')

def dismiss_all(pg, n=6):
    for _ in range(n):
        if pg.locator('#modal').count() == 0: return
        if pg.locator('.em-choice:not([disabled])').count(): pg.locator('.em-choice:not([disabled])').first.click()
        else: pg.locator('#modal .m-btns .btn').first.click()
        pg.wait_for_timeout(250)

def launch(pg, planet, mobile):
    btn = pg.locator(f'button.launch[data-planet="{planet}"]'); btn.scroll_into_view_if_needed()
    btn.tap() if mobile else btn.click()
    pg.wait_for_timeout(3500)

def desktop_suite(b, planet):
    ctx = b.new_context(viewport={'width': 1440, 'height': 900}); ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))"); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc.gsfc.nasa.gov' not in (m.location or {}).get('url', '') else None)  # the sandbox cannot reach NASA: the failed request is expected (game falls back to archived data)
    pg.goto(URL); pg.wait_for_timeout(900)
    P = planet.upper()
    # ---- mission length selector ----
    ok(f'[{P} desktop] Mission length default is 90 days', pg.get_attribute('.ml-opt[data-days="90"]', 'aria-checked') == 'true' and '90 days' in pg.inner_text(f'button.launch[data-planet="{planet}"]'))
    pg.click('.ml-opt[data-days="60"]'); pg.wait_for_timeout(200)
    ok(f'[{P} desktop] Selecting 60 days updates launch buttons and description', '60 days' in pg.inner_text(f'button.launch[data-planet="{planet}"]') and 'Standard' in pg.inner_text('.ml-opt.on'), pg.inner_text('.ml-note')[:60])
    pg.reload(); pg.wait_for_timeout(900)
    ok(f'[{P} desktop] Selection remembered after reload', pg.get_attribute('.ml-opt[data-days="60"]', 'aria-checked') == 'true')
    want = 90 if planet == 'mars' else 30
    pg.click(f'.ml-opt[data-days="{want}"]'); pg.wait_for_timeout(200)
    launch(pg, planet, False)
    ok(f'[{P} desktop] Game starts with the chosen length ({want} days)', E(pg, 'return e.days;') == want and f'/ {want}' in pg.inner_text('.clock b'), pg.inner_text('.clock b'))
    ok(f'[{P} desktop] Briefing mentions the {want}-day mission', f'{want}-' in pg.inner_text('#modal .m-body'))
    ok(f'[{P} desktop] Launch button opens 3D colony', pg.evaluate('() => !!document.querySelector("#scene canvas") && !document.querySelector("#title")'))
    ok(f'[{P} desktop] Correct world loaded', E(pg, 'return e.planet.id;') == planet)
    ok(f'[{P} desktop] Briefing shown', 'Welcome' in pg.inner_text('#modal h2'))
    pg.click('#modal .btn.primary'); pg.wait_for_timeout(600)
    E(pg, 'e.events = [];')  # scheduled events are covered by the engine suites; keep the UI test deterministic
    ok(f'[{P} desktop] Starting base: habitat, solar, greenhouse, lander', E(pg, 'return [...e.buildings.values()].map(b=>b.type).sort().join(",");') == 'greenhouse,habitat,lander,solar')
    # ---- camera ---- (game paused so no event pop-up interrupts the test)
    E(pg, 'e.setSpeed(0);')
    c0 = cam(pg)
    pg.mouse.move(720, 600); pg.mouse.down(); pg.mouse.move(820, 590, steps=8); pg.mouse.up(); pg.wait_for_timeout(500)
    c1 = cam(pg); ok(f'[{P} desktop] Rotate (left-drag)', abs(c1['az'] - c0['az']) > 0.1, f"azimuth {c0['az']:.2f} → {c1['az']:.2f}")
    pg.mouse.move(720, 500); pg.mouse.wheel(0, -600); pg.wait_for_timeout(700)
    c2 = cam(pg); ok(f'[{P} desktop] Zoom (scroll wheel)', c2['dist'] < c1['dist'] - 2, f"distance {c1['dist']:.1f} → {c2['dist']:.1f}")
    pg.mouse.move(720, 600); pg.mouse.down(button='right'); pg.mouse.move(600, 520, steps=8); pg.mouse.up(button='right'); pg.wait_for_timeout(500)
    c3 = cam(pg); ok(f'[{P} desktop] Pan (right-drag)', math.hypot(c3['tx'] - c2['tx'], c3['tz'] - c2['tz']) > 1, f"target moved {math.hypot(c3['tx'] - c2['tx'], c3['tz'] - c2['tz']):.1f} m")
    pg.mouse.move(720, 500)
    for _ in range(40): pg.mouse.wheel(0, 400); pg.wait_for_timeout(30)
    pg.wait_for_timeout(800)
    ok(f'[{P} desktop] Zoom out stops at the 120 m limit', 110 < cam(pg)['dist'] <= 120.5, f"{cam(pg)['dist']:.1f}")
    for _ in range(90): pg.mouse.wheel(0, -400); pg.wait_for_timeout(20)
    pg.wait_for_timeout(800)
    ok(f'[{P} desktop] Zoom in stops at the 10 m limit', 9.5 <= cam(pg)['dist'] < 14, f"{cam(pg)['dist']:.1f}")
    dismiss_all(pg)
    # reset camera to default view for building
    pg.evaluate('() => { const c = window.__ja.controls; c.target.set(0,0,0); window.__ja.camera.position.set(24,22,30); c.update(); }'); pg.wait_for_timeout(400)
    # ---- build all 11 through the UI ----
    E(pg, 'e.res.mat = 3000; e.setSpeed(0);')
    ice = E(pg, 'return e.iceTiles[0];')
    spots = {'solar': [4, 4], 'battery': [3, 4], 'oxygen': [9, 4], 'ice': ice, 'recycler': [8, 9], 'greenhouse': [4, 8], 'shield': [5, 6],
             'fabricator': [9, 6], 'lab': [9, 9], 'comms': [8, 4], 'reactor': [11, 5] if planet == 'mars' else [2, 9]}
    for t, (i, j) in spots.items():
        pg.click(f'.bcard[data-type="{t}"]'); pg.wait_for_timeout(250)
        mat0 = E(pg, 'return e.res.mat;')
        x, y = pg.evaluate(f'() => window.__ja.tileToScreen({i}, {j})')
        pg.mouse.move(x, y); pg.wait_for_timeout(150); pg.mouse.click(x, y); pg.wait_for_timeout(350)
        placed = E(pg, f'return [...e.buildings.values()].some(b => b.type === "{t}" && b.i === {i} && b.j === {j});')
        paid = mat0 - E(pg, 'return e.res.mat;')
        ok(f'[{P} desktop] Build menu → {t} placed by clicking tile ({i},{j}), cost {COST[t]} kg', placed and abs(paid - COST[t]) < 0.01, f'paid {paid:.0f} at screen ({x:.0f},{y:.0f})')
        E(pg, 'e.cancelBuild();')
    # invalid placement checks via UI
    pg.click('.bcard[data-type="ice"]'); x, y = pg.evaluate('() => window.__ja.tileToScreen(5, 3)'); pg.mouse.move(x, y); pg.wait_for_timeout(200)
    ok(f'[{P} desktop] Invalid tile shows red reason (Ice Miner off ice)', 'ice deposit' in pg.inner_text('#build-hint'), pg.inner_text('.bh-why'))
    m0 = E(pg, 'return e.res.mat;'); pg.mouse.click(x, y); pg.wait_for_timeout(200)
    ok(f'[{P} desktop] Invalid placement is refused and costs nothing', E(pg, 'return e.res.mat;') == m0)
    pg.click('#bh-x'); pg.wait_for_timeout(200)
    ok(f'[{P} desktop] ✕ cancels build mode', E(pg, 'return e.ui.buildType;') is None)
    # ---- finish construction and check resources update in HUD ----
    E(pg, 'e.buildings.forEach(b => { if (!b.built) e.completeBuilding(b); });')
    dismiss_all(pg)
    h0 = {k: hud_num(pg, f'#r-{k} .v') for k in ['o2', 'water', 'food', 'mat']}; t0 = E(pg, 'return e.t;')
    pg.click('#speed button[data-s="8"]'); ok(f'[{P} desktop] 8× speed button', E(pg, 'return e.speed;') == 8)
    pg.click('#speed button[data-s="4"]'); ok(f'[{P} desktop] 4× speed button', E(pg, 'return e.speed;') == 4)
    for _ in range(10): pg.wait_for_timeout(500); dismiss_all(pg)
    dismiss_all(pg); pg.click('#speed button[data-s="0"]', timeout=60000); ok(f'[{P} desktop] Pause button', E(pg, 'return e.speed;') == 0)
    pg.wait_for_timeout(400)
    h1 = {k: hud_num(pg, f'#r-{k} .v') for k in ['o2', 'water', 'food', 'mat']}; t1 = E(pg, 'return e.t;')
    ok(f'[{P} desktop] Time advances while running', t1 > t0 + 0.2, f'{t0:.2f} → {t1:.2f} days')
    ok(f'[{P} desktop] HUD oxygen/water/food/materials values update', any(abs(h1[k] - h0[k]) > 0.05 for k in h0), f'{h0} → {h1}')
    hudv = E(pg, 'return [e.res.o2, e.res.water, e.res.food];')
    ok(f'[{P} desktop] HUD shows engine values', abs(hud_num(pg, '#r-o2 .v') - hudv[0]) < 0.2 and abs(hud_num(pg, '#r-water .v') - hudv[1]) < 1, f'{hudv}')
    ok(f'[{P} desktop] HUD shows energy and crew health', '%' in pg.inner_text('#r-crew') and 'kW' in pg.inner_text('#r-power'), pg.inner_text('#r-crew').replace('\n', ' '))
    # ---- info panel actions ----
    x, y = pg.evaluate('() => window.__ja.tileToScreen(9, 9)'); pg.mouse.click(x, y); pg.wait_for_timeout(400)
    ok(f'[{P} desktop] Clicking a building opens its info panel', 'Science Lab' in (pg.inner_text('#info') if pg.locator('#info').count() else ''))
    ok(f'[{P} desktop] Info panel shows REAL/GAME tags and trade-off', pg.locator('#info .tag').count() > 0 and 'Trade-off' in pg.inner_text('#info'))
    pg.locator('#info button', has_text='Switch off').click(); pg.wait_for_timeout(300)
    ok(f'[{P} desktop] Switch off button', E(pg, 'return [...e.buildings.values()].find(b=>b.type==="lab").on;') is False)
    pg.locator('#info button', has_text='Switch on').click(); pg.wait_for_timeout(200)
    E(pg, 'const b=[...e.buildings.values()].find(b=>b.type==="lab"); b.cond = 40; e.bump();'); pg.wait_for_timeout(300)
    m0 = E(pg, 'return e.res.mat;'); pg.locator('#info button', has_text='Repair').click(); pg.wait_for_timeout(300)
    ok(f'[{P} desktop] Repair button', E(pg, 'return [...e.buildings.values()].find(b=>b.type==="lab").cond;') == 100 and E(pg, 'return e.res.mat;') < m0)
    m0 = E(pg, 'return e.res.mat;'); pg.locator('#info button', has_text='Recycle').click(); pg.wait_for_timeout(300)
    ok(f'[{P} desktop] Recycle button refunds 50%', E(pg, 'return e.res.mat;') - m0 == 100 and not E(pg, 'return [...e.buildings.values()].some(b=>b.type==="lab");'))
    if planet == 'mars':
        E(pg, 'e.t = Math.floor(e.t) + 1.5; e.env = e.computeEnv(e.t); e.buildings.forEach(b => { if (b.type === "solar") b.dust = 0.8; });')
        x, y = pg.evaluate('() => window.__ja.tileToScreen(4, 4)'); pg.mouse.click(x, y); pg.wait_for_timeout(400)
        pg.locator('#info button', has_text='Clean').click(); pg.wait_for_timeout(300)
        ok('[MARS desktop] Clean panels (EVA) button', E(pg, 'return [...e.buildings.values()].filter(b=>b.type==="solar").every(b=>b.dust===1);'))
    # ---- interactive emergencies (real clicks on choice cards) ----
    E(pg, 'e.select(null); e.setSpeed(0); e.res.mat = 1500; e.res.water = 300; e.res.o2 = 100; e.res.battery = Math.min(e.stats.cap, 150); e.buildings.forEach(b => { if (!b.built) e.completeBuilding(b); });')
    dismiss_all(pg)
    plan = [('dust', 'eva' if planet == 'moon' else 'powerplan'), ('o2fail', 'repair'), ('waterleak', 'replace'), ('batfail', 'isolate'), ('radiation', 'shelter')]
    for etype, cid in plan:
        E(pg, 'e.t = Math.floor(e.t) + 0.5; e.env = e.computeEnv(e.t); e.bump();')
        if etype == 'radiation': E(pg, 'e.fireEvent({ type: "spe_warn", dose: 300 });')
        else: E(pg, f'e.triggerEmergency("{etype}");')
        pg.wait_for_timeout(500)
        shown = pg.locator('.modal-card.emergency').count() == 1
        n = pg.locator('.em-choice').count()
        strip = pg.inner_text('.em-strip') if shown else ''
        ok(f'[{P} desktop] Emergency "{etype}": alert with description and {n} choices', shown and n >= 2 and 'EMERGENCY' in strip and len(pg.inner_text('.m-body.em p').strip()) > 40, strip)
        m0, p0 = E(pg, 'return e.res.mat;'), E(pg, 'return e.points;')
        cost = E(pg, f'return (e.activeEm[e.activeEm.length-1].choices.find(c => c.id === "{cid}").costs.mat) || 0;')
        pts = E(pg, f'return e.activeEm[e.activeEm.length-1].choices.find(c => c.id === "{cid}").points;')
        pg.locator(f'.em-choice[data-choice="{cid}"]').click(); pg.wait_for_timeout(500)
        chosen = E(pg, 'const em = e.activeEm[e.activeEm.length-1] || e.decisions[e.decisions.length-1]; return e.decisions.length ? e.decisions[e.decisions.length-1].choice : null;')
        ok(f'[{P} desktop] Emergency "{etype}": clicking "{cid}" applies it (−{cost} kg, {pts:+d} pts)', pg.locator('.modal-card.emergency').count() == 0 and abs((m0 - E(pg, 'return e.res.mat;')) - cost) < 0.6 and E(pg, 'return e.points;') - p0 == pts, f'{chosen}; mat −{m0 - E(pg, "return e.res.mat;"):.0f}')
        ok(f'[{P} desktop] Emergency "{etype}": points shown in HUD', pg.inner_text('#r-pts .v').strip() == str(E(pg, 'return e.points;')), pg.inner_text('#r-pts .v'))
        ok(f'[{P} desktop] Emergency "{etype}": decision debrief shown', pg.locator('.modal-card[data-custom="debrief"]').count() == 1)
        pg.locator('#modal .m-btns .btn').first.click() if pg.locator('.modal-card[data-custom="debrief"]').count() else None; pg.wait_for_timeout(300)
    E(pg, 'e.res.mat = 0; e.res.battery = 0;')
    E(pg, 'e.triggerEmergency("waterleak");'); pg.wait_for_timeout(400)
    ok(f'[{P} desktop] Unaffordable choice is greyed out and cannot be clicked', pg.locator('.em-choice[data-choice="replace"]').is_disabled() and 'Not enough materials' in pg.inner_text('.em-choice[data-choice="replace"]'))
    pg.screenshot(path=ROOT + f'/qa/results/shots/em_{planet}_desktop.png')
    pg.locator('.em-choice:not([disabled])').last.click(); pg.wait_for_timeout(400)
    pg.locator('#modal .m-btns .btn').first.click() if pg.locator('.modal-card[data-custom="debrief"]').count() else None; pg.wait_for_timeout(300)
    E(pg, 'e.res.mat = 1500;'); dismiss_all(pg)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    ok(f'[{P} desktop] Esc closes the info panel', E(pg, 'return e.ui.selected;') is None)
    E(pg, 'e.setSpeed(0);'); dismiss_all(pg)
    pg.keyboard.press('4'); pg.wait_for_timeout(100); s8 = E(pg, 'return e.speed;')
    ok(f'[{P} desktop] Keyboard: 4 = 8×', s8 == 8)
    pg.keyboard.press('3'); pg.wait_for_timeout(100); s3 = E(pg, 'return e.speed;')
    pg.keyboard.press('Space'); pg.wait_for_timeout(100); s0 = E(pg, 'return e.speed;')
    pg.keyboard.press('Space'); pg.wait_for_timeout(100); s4 = E(pg, 'return e.speed;')
    ok(f'[{P} desktop] Keyboard: 3 = 4×, Space pauses and resumes', s3 == 4 and s0 == 0 and s4 == 4, f'{s3},{s0},{s4}')
    pg.keyboard.press('Space'); dismiss_all(pg)
    # ---- panels, codex, handbook, quiz ----
    pg.click('#crew .sh'); pg.wait_for_timeout(200); ok(f'[{P} desktop] Crew panel expands', pg.locator('#crew.collapsed').count() == 0)
    pg.click('#btn-codex'); pg.wait_for_timeout(300); ok(f'[{P} desktop] Codex opens', 'Science Codex' in pg.inner_text('#modal h2'))
    pg.locator('.cx:not(.locked)').nth(1).click(); pg.wait_for_timeout(200); ok(f'[{P} desktop] Codex entry readable', pg.locator('.cx-d').count() == 1)
    pg.locator('#modal .m-btns .btn').click(); pg.wait_for_timeout(200)
    pg.click('#btn-menu'); pg.wait_for_timeout(300); pg.locator('#modal .m-btns .btn', has_text='Handbook').click(); pg.wait_for_timeout(300)
    ok(f'[{P} desktop] Mission Handbook opens from menu', 'Mission Handbook' in pg.inner_text('#modal h2') and pg.locator('.hb-row').count() >= 15)
    pg.locator('.hb-tabs .btn', has_text='Mars vs Moon').click(); pg.wait_for_timeout(200); ok(f'[{P} desktop] Handbook Mars-vs-Moon tab', pg.locator('.hb-cmp-r').count() >= 10)
    pg.locator('#modal .m-btns .btn').click(); pg.wait_for_timeout(200)
    q0 = E(pg, 'return e.quizCount;')
    pg.evaluate('() => { window.__ja.engine.quiz(); }'); pg.wait_for_timeout(400)
    ok(f'[{P} desktop] Quiz modal appears', 'Mission Control' in pg.inner_text('#modal h2'))
    pg.locator('#modal .m-btns .btn').first.click(); pg.wait_for_timeout(400)
    ok(f'[{P} desktop] Quiz answer gives feedback', pg.inner_text('#modal h2') in ('Correct!', 'Not quite')); pg.locator('#modal .m-btns .btn').click(); pg.wait_for_timeout(200)
    ok(f'[{P} desktop] Quiz counted', E(pg, 'return e.quizCount;') == q0 + 1)
    pg.screenshot(path=ROOT + f'/qa/results/shots/qa_{planet}_desktop_base.png')
    # ---- threat level badge & goals list ----
    if want == 90:
        E(pg, 'e.t = 46.2; e.env = e.computeEnv(e.t); e.bump();'); pg.wait_for_timeout(500)
        ok(f'[{P} desktop] Threat badge shows level III on Day 47', 'THREAT III' in pg.inner_text('.clock b') and 'DAY 47 / 90' in pg.inner_text('.clock b').upper().replace('SOL', 'DAY'), pg.inner_text('.clock b'))
        ok(f'[{P} desktop] Goals panel lists 14 goals + Day 30/60 checkpoints', pg.locator('#obj-list li').count() == 14 + 2 + 1 and 'Checkpoint: Day 60' in pg.inner_text('#obj-list'), pg.locator('#obj-list li').count())
        ok(f'[{P} desktop] Progress bar has checkpoint ticks', pg.locator('#mission-track .mtick').count() == 2)
    # ---- mission complete ----
    dismiss_all(pg)
    E(pg, 'e.res.o2 = 150; e.res.water = 300; e.res.food = 200; e.events = []; e.t = e.days - 0.6; e.setSpeed(1);')
    pg.wait_for_timeout(1500)
    ok(f'[{P} desktop] Not complete on the morning of the last day', not E(pg, 'return e.over;') and pg.locator('#modal').count() == 0, E(pg, 'return e.t.toFixed(2);'))
    E(pg, 'e.t = e.days - 0.02; e.setSpeed(4);')
    pg.wait_for_timeout(2500)
    ok(f'[{P} desktop] Day 30 → Mission Complete screen', pg.locator('#modal h2').count() and 'Mission Complete' in pg.inner_text('#modal h2'), pg.inner_text('#modal h2') if pg.locator('#modal').count() else 'no modal')
    ok(f'[{P} desktop] Final report shows mission length and days survived', f'{want} / {want}' in pg.inner_text('#modal .m-body') and 'Emergencies survived' in pg.inner_text('#modal .m-body'), pg.inner_text('#modal .m-body')[:120].replace('\n', ' | '))
    pg.screenshot(path=ROOT + f'/qa/results/shots/qa_{planet}_win.png')
    other = 'moon' if planet == 'mars' else 'mars'
    pg.locator('#modal .m-btns .btn').nth(1).click(); pg.wait_for_timeout(3000)
    ok(f'[{P} desktop] "Try the other world" button loads {other} with the same length', E(pg, 'return e.planet.id;') == other and E(pg, 'return e.days;') == want)
    dismiss_all(pg)
    # ---- mission failure ----
    E(pg, 'e.events = []; e.res.o2 = 0; e.crew.forEach(c => c.health = 3); e.setSpeed(1);')
    txt = ''; seen = []
    for _ in range(20):
        pg.wait_for_timeout(600)
        txt = pg.inner_text('#modal h2') if pg.locator('#modal').count() else ''
        if txt: seen.append(txt)
        if 'Mission Failed' in txt: break
        if txt: pg.locator('#modal .m-btns .btn').first.click()
    ok(f'[{P} desktop] Simultaneous crew losses shown in ONE pop-up', seen.count('Crew members lost') + seen.count('Crew member lost') == 1, seen)
    ok(f'[{P} desktop] No oxygen → crew lost → Mission Failed screen', 'Mission Failed' in txt, txt)
    pg.locator('#modal .m-btns .btn', has_text='Title').click(); pg.wait_for_timeout(800)
    ok(f'[{P} desktop] Title button returns to planet selection', pg.locator('#title').count() == 1 and pg.locator('button.launch').count() == 2)
    ok(f'[{P} desktop] No runtime errors', not errs, errs[:3])
    ctx.close()

def touch_drag(cdp, pts0, pts1, steps=10):
    cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x, 'y': y, 'id': k} for k, (x, y) in enumerate(pts0)]})
    for s in range(1, steps + 1):
        f = s / steps
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x0 + (x1 - x0) * f, 'y': y0 + (y1 - y0) * f, 'id': k} for k, ((x0, y0), (x1, y1)) in enumerate(zip(pts0, pts1))]})
    cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})

def mobile_suite(b, planet):
    ctx = b.new_context(viewport={'width': 412, 'height': 860}, device_scale_factor=2, is_mobile=True, has_touch=True); ctx.add_init_script("localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))"); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc.gsfc.nasa.gov' not in (m.location or {}).get('url', '') else None)  # the sandbox cannot reach NASA: the failed request is expected (game falls back to archived data)
    pg.goto(URL); pg.wait_for_timeout(900)
    P = planet.upper()
    pg.locator('.ml-opt[data-days="60"]').tap(); pg.wait_for_timeout(200)
    launch(pg, planet, True)
    ok(f'[{P} phone] Launch button (tap) opens 3D colony', pg.evaluate('() => !!document.querySelector("#scene canvas")') and E(pg, 'return e.planet.id;') == planet)
    ok(f'[{P} phone] Tapped 60-day option is used (HUD shows / 60)', E(pg, 'return e.days;') == 60 and '/ 60' in pg.inner_text('.clock b'), pg.inner_text('.clock b'))
    pg.locator('#modal .btn.primary').tap(); pg.wait_for_timeout(600)
    cdp = ctx.new_cdp_session(pg)
    c0 = cam(pg); touch_drag(cdp, [(200, 560)], [(300, 550)]); pg.wait_for_timeout(500); c1 = cam(pg)
    ok(f'[{P} phone] One-finger drag rotates', abs(c1['az'] - c0['az']) > 0.1, f"{c0['az']:.2f} → {c1['az']:.2f}")
    touch_drag(cdp, [(180, 520), (240, 520)], [(110, 520), (310, 520)]); pg.wait_for_timeout(600); c2 = cam(pg)
    ok(f'[{P} phone] Pinch zooms', c2['dist'] < c1['dist'] - 1, f"{c1['dist']:.1f} → {c2['dist']:.1f}")
    touch_drag(cdp, [(170, 520), (250, 520)], [(170, 420), (250, 420)]); pg.wait_for_timeout(600); c3 = cam(pg)
    ok(f'[{P} phone] Two-finger drag pans', math.hypot(c3['tx'] - c2['tx'], c3['tz'] - c2['tz']) > 0.5, f"moved {math.hypot(c3['tx'] - c2['tx'], c3['tz'] - c2['tz']):.1f} m")
    pg.evaluate('() => { const c = window.__ja.controls; c.target.set(0,0,0); window.__ja.camera.position.set(24,22,30); c.update(); }'); pg.wait_for_timeout(400)
    E(pg, 'e.setSpeed(0);')
    # tap-to-preview, then ✓ Build
    pg.locator('.bcard[data-type="oxygen"]').tap(); pg.wait_for_timeout(250)
    x, y = pg.evaluate('() => window.__ja.tileToScreen(9, 4)'); pg.touchscreen.tap(x, y); pg.wait_for_timeout(300)
    ok(f'[{P} phone] First tap previews (ghost), does not build yet', E(pg, 'return JSON.stringify(e.ui.ghost);') == '[9,4]' and not E(pg, 'return [...e.buildings.values()].some(b=>b.type==="oxygen");'))
    pg.locator('#bh-ok').tap(); pg.wait_for_timeout(300)
    ok(f'[{P} phone] ✓ Build places it and charges 150 kg', E(pg, 'return [...e.buildings.values()].some(b=>b.type==="oxygen") && e.res.mat === 550;'), E(pg, 'return e.res.mat;'))
    pg.locator('.bcard[data-type="shield"]').tap(); pg.wait_for_timeout(200)
    x, y = pg.evaluate('() => window.__ja.tileToScreen(5, 6)'); pg.touchscreen.tap(x, y); pg.wait_for_timeout(250); pg.touchscreen.tap(x, y); pg.wait_for_timeout(300)
    ok(f'[{P} phone] Tapping the same tile twice also builds', E(pg, 'return [...e.buildings.values()].some(b=>b.type==="shield");'))
    pg.locator('#bh-x').tap(); pg.wait_for_timeout(200)
    x, y = pg.evaluate('() => window.__ja.tileToScreen(6.5, 6.5)'); pg.touchscreen.tap(x, y); pg.wait_for_timeout(400)
    ok(f'[{P} phone] Tap habitat → info panel', pg.locator('#info').count() == 1 and 'Habitat' in pg.inner_text('#info'))
    pg.screenshot(path=ROOT + f'/qa/results/shots/qa_{planet}_phone_info.png')
    pg.locator('#info .x').tap(); pg.wait_for_timeout(200)
    pg.locator('#objectives .sh').tap(); pg.wait_for_timeout(250); ok(f'[{P} phone] Goals panel opens on tap', pg.locator('#objectives.collapsed').count() == 0)
    pg.screenshot(path=ROOT + f'/qa/results/shots/qa_{planet}_phone_goals.png')
    pg.locator('#objectives .sh').tap(); pg.wait_for_timeout(200)
    pg.locator('#r-crew').tap(); pg.wait_for_timeout(250); ok(f'[{P} phone] Crew chip opens crew panel', pg.locator('#crew.collapsed').count() == 0)
    pg.locator('#crew .sh').tap()
    # emergency on a phone: tap a choice card
    E(pg, 'e.setSpeed(0); e.res.mat = 900; e.buildings.forEach(b => { if (!b.built) e.completeBuilding(b); });'); dismiss_all(pg)
    E(pg, 'e.triggerEmergency("o2fail");'); pg.wait_for_timeout(500)
    ok(f'[{P} phone] Emergency alert fits the phone screen', pg.locator('.modal-card.emergency').count() == 1 and pg.evaluate('() => { const r = document.querySelector(".modal-card").getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth; }'))
    pg.screenshot(path=ROOT + f'/qa/results/shots/em_{planet}_phone.png')
    pg.locator('.em-choice[data-choice="candles"]').tap(); pg.wait_for_timeout(500)
    ok(f'[{P} phone] Tapping a choice applies it (oxygen candles: +10 kg O₂)', E(pg, 'return e.decisions.length === 1 && e.decisions[0].choice === "Burn oxygen candles";') and pg.locator('.modal-card.emergency').count() == 0)
    pg.locator('#modal .m-btns .btn').first.tap() if pg.locator('.modal-card[data-custom="debrief"]').count() else None; pg.wait_for_timeout(300)
    ok(f'[{P} phone] Points shown on the compact HUD', '🏅' in pg.inner_text('#r-mat .s'), pg.inner_text('#r-mat .s'))
    pg.locator('#speed button[data-s="4"]').tap()
    for _ in range(6): pg.wait_for_timeout(500); dismiss_all(pg)
    ok(f'[{P} phone] Simulation runs at 4×', E(pg, 'return e.t;') > 0.4)
    dismiss_all(pg); pg.locator('#speed button[data-s="0"]').tap(); pg.wait_for_timeout(500)
    pg.screenshot(path=ROOT + f'/qa/results/shots/qa_{planet}_phone_play.png')
    ok(f'[{P} phone] No runtime errors', not errs, errs[:3])
    ctx.close()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=ARGS)
    which = sys.argv[1:] or ['mars-desktop', 'moon-desktop', 'mars-phone', 'moon-phone']
    for w in which:
        pl, kind = w.split('-')
        try: (desktop_suite if kind == 'desktop' else mobile_suite)(b, pl)
        except Exception as ex:
            print('EXCEPTION', str(ex)[:600]); RESULTS.append((False, 'exception'))
            for c in b.contexts:
                for pgx in c.pages: pgx.screenshot(path=ROOT + '/qa/results/shots/ui_fail.png'); print('MODAL:', pgx.evaluate("() => { const m = document.querySelector('#modal'); return m ? m.innerText.slice(0, 300) : 'none'; }"))
                c.close()
    b.close()
n = sum(r[0] for r in RESULTS)
print(f'\n{n}/{len(RESULTS)} UI checks passed')
json.dump(RESULTS, open(ROOT + '/qa/results/ui_results_' + '_'.join(sys.argv[1:] or ['all']) + '.json', 'w'), indent=1)
