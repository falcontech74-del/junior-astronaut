import os, sys as _sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = os.environ.get('JA_URL', 'http://localhost:4173/')
CHROME = os.environ.get('CHROME_PATH', '/usr/bin/google-chrome')
os.makedirs(ROOT + '/qa/results/shots', exist_ok=True)
# Phase 6 QA: loading screen, main menu, settings/music/quality, credits links, tutorial, demo mode,
# report learning section, layout overlap audit on 7 screen sizes.
import sys, json
from playwright.sync_api import sync_playwright
R = []
def ok(n, c, d=''):
    R.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + (f'  [{d}]' if d != '' else ''), flush=True)
ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required']
URL = URL
DONE = "localStorage.setItem('ja-settings', JSON.stringify({ tutorialDone: true }))"
OVERLAP = """() => {
  const sel = ['#topbar', '#resources', '#objectives', '#crew', '#buildbar', '#demo-panel', '#alertbar.show', '#tutorial .tut-card'];
  const vis = sel.map((s) => [s, document.querySelector(s)]).filter(([, el]) => el && el.offsetParent !== null && getComputedStyle(el).opacity !== '0').map(([s, el]) => [s, el.getBoundingClientRect()]);
  const bad = [];
  for (let i = 0; i < vis.length; i++) for (let j = i + 1; j < vis.length; j++) {
    const [a, A] = vis[i], [b, B] = vis[j];
    const w = Math.min(A.right, B.right) - Math.max(A.left, B.left), h = Math.min(A.bottom, B.bottom) - Math.max(A.top, B.top);
    if (w > 6 && h > 6) bad.push(`${a}×${b} ${Math.round(w)}x${Math.round(h)}`);
  }
  const off = vis.filter(([, r]) => r.left < -1 || r.right > innerWidth + 1).map(([s]) => s + ' off-screen');
  return bad.concat(off);
}"""
EXPECT_SCI = ['https://www.nasa.gov/missions/mars-2020-perseverance/perseverance-rover/nasas-oxygen-generating-experiment-moxie-completes-mars-mission/',
              'https://www.nasa.gov/missions/station/iss-research/nasa-achieves-water-recovery-milestone-on-international-space-station/',
              'https://ntrs.nasa.gov/citations/20180005435', 'https://www.nasa.gov/technology/tech-transfer-spinoffs/space-farming-yields-a-crop-of-benefits-for-earth/',
              'https://doi.org/10.1126/science.1244797', 'https://doi.org/10.1126/sciadv.aaz1334',
              'https://www.nasa.gov/wp-content/uploads/2023/03/radiation-protection-technical-brief-ochmo.pdf', 'https://ntrs.nasa.gov/citations/20250006168',
              'https://www.nasa.gov/solar-system/nasa-watches-mars-light-up-during-epic-solar-storm/',
              'https://www.esa.int/Science_Exploration/Human_and_Robotic_Exploration/Exploration/ExoMars/Giant_solar_eruption_felt_on_Earth_Moon_and_Mars',
              'https://www.cdc.gov/radiation-emergencies/hcp/clinical-guidance/ars.html', 'https://www.nasa.gov/history/25-years-ago-fire-aboard-space-station-mir/',
              'https://www.nasa.gov/blogs/missions/2025/03/14/nasa-science-data-received-blue-ghost-captures-eclipse-from-moon/',
              'https://www.nasa.gov/general/nasa-seeks-industry-feedback-on-fission-surface-power/',
              'https://www.jpl.nasa.gov/news/nasas-insight-records-monster-quake-on-mars/', 'https://www.jpl.nasa.gov/news/opportunity-hunkers-down-during-dust-storm/',
              'https://react.dev/', 'https://threejs.org/', 'https://r3f.docs.pmnd.rs/', 'https://github.com/pmndrs/drei']

def page(b, vp, mobile, fresh=False):
    ctx = b.new_context(viewport=vp, device_scale_factor=2 if mobile else 1, is_mobile=mobile, has_touch=mobile)
    if not fresh: ctx.add_init_script(DONE)
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ccmc.gsfc.nasa.gov' not in (m.location or {}).get('url', '') else None)
    pg.route('https://ccmc.gsfc.nasa.gov/**', lambda r: r.abort())
    return ctx, pg, errs

def features(b, mobile):
    tag = '[phone]' if mobile else '[desktop]'
    vp = {'width': 390, 'height': 844} if mobile else {'width': 1440, 'height': 900}
    ctx, pg, errs = page(b, vp, mobile, fresh=True)
    click = (lambda l: l.tap()) if mobile else (lambda l: l.click())
    pg.goto(URL); pg.wait_for_timeout(100)
    ok(f'{tag} Loading screen shows while the app starts', pg.locator('#loading h1').count() == 1 and 'JUNIOR ASTRONAUT' in pg.inner_text('#loading h1'))
    pg.wait_for_timeout(1400)
    ok(f'{tag} Loading screen removed once the menu is ready', pg.locator('#loading').count() == 0)
    mm = pg.locator('#main-menu .mm-btn')
    ok(f'{tag} Main menu: Start, Tutorial, Demo, NASA data & credits, Settings', [x.get_attribute('data-mm') for x in mm.all()] == ['play', 'tutorial', 'demo', 'sources', 'settings'])
    ok(f'{tag} Title has no sideways scrolling', pg.evaluate('() => document.querySelector("#title").scrollWidth <= innerWidth + 1'))
    # settings
    click(pg.locator('[data-mm="settings"]')); pg.wait_for_timeout(400)
    ok(f'{tag} Settings opens with sound, music, volume, quality, tutorial', all(pg.locator(s).count() == 1 for s in ['#set-sfx', '#set-music', '#set-vol', '#set-quality', '#set-tutorial']))
    playing0 = pg.evaluate('() => window.__ja.music ? window.__ja.music.playing : null')
    click(pg.locator('#set-sfx')); pg.wait_for_timeout(200)
    st = pg.evaluate("() => JSON.parse(localStorage.getItem('ja-settings'))")
    ok(f'{tag} Sound-effects switch saves and turns sounds off', st['sfx'] is False and pg.get_attribute('#set-sfx', 'aria-checked') == 'false')
    click(pg.locator('#set-sfx')); pg.wait_for_timeout(200)
    ok(f'{tag} Background music plays after a tap (Web Audio)', pg.evaluate('() => window.__ja.music.playing') is True, f'before tap: {playing0}')
    click(pg.locator('#set-music')); pg.wait_for_timeout(300)
    ok(f'{tag} Music switch stops the music and is saved', pg.evaluate('() => window.__ja.music.playing') is False and pg.evaluate("() => JSON.parse(localStorage.getItem('ja-settings')).music") is False)
    click(pg.locator('#set-music')); pg.wait_for_timeout(300)
    pg.locator('#set-vol').fill('0.6'); pg.wait_for_timeout(150)
    ok(f'{tag} Volume slider saved', abs(pg.evaluate("() => JSON.parse(localStorage.getItem('ja-settings')).musicVol") - 0.6) < 0.01)
    click(pg.locator('#set-quality [data-q="low"]')); pg.wait_for_timeout(150)
    ok(f'{tag} Graphics quality "Low" saved and used', pg.evaluate("() => window.__ja.settings.gfx().name") == 'low')
    click(pg.locator('#set-quality [data-q="auto"]')); pg.wait_for_timeout(150)
    click(pg.locator('#modal .m-btns .btn')); pg.wait_for_timeout(300)
    # credits
    click(pg.locator('[data-mm="sources"]')); pg.wait_for_timeout(400)
    click(pg.locator('#src-tabs [data-tab="credits"]')); pg.wait_for_timeout(300)
    links = pg.eval_on_selector_all('#credits a', 'as => as.map(a => a.href)')
    ok(f'{tag} Credits list the verified science and software links', links == EXPECT_SCI, len(links))
    ok(f'{tag} Credits state links were checked and no NASA endorsement', 'checked on 14 Nov 2026' in pg.inner_text('#credits') and '15 Nov 2026' in pg.inner_text('#credits') and 'not affiliated' in pg.inner_text('#credits'))
    click(pg.locator('#src-tabs [data-tab="nasa"]')); pg.wait_for_timeout(200)
    ok(f'{tag} NASA tab still shows the DONKI status and links', pg.locator('#src-status').count() == 1 and pg.locator('.src-links a[href="https://ccmc.gsfc.nasa.gov/DONKI/api/"]').count() == 1)
    click(pg.locator('#modal .m-btns .btn')); pg.wait_for_timeout(300)
    # tutorial (first launch with empty storage)
    btn = pg.locator('button.launch[data-planet="moon"]'); btn.scroll_into_view_if_needed(); click(btn); pg.wait_for_timeout(250)
    ok(f'{tag} Launch shows the landing curtain', pg.locator('#curtain').count() == 1 and 'Landing on the Moon' in pg.inner_text('#curtain'))
    pg.wait_for_timeout(3000)
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(800)
    ok(f'{tag} Curtain is gone after the scene is ready', pg.locator('#curtain.gone').count() == 1)
    ok(f'{tag} First-time players get the tutorial automatically', pg.locator('#tutorial').get_attribute('data-step') == 'welcome')
    ok(f'{tag} Game is paused during the tour', pg.evaluate('() => window.__ja.engine.speed') == 0)
    seen = []
    for _ in range(14):
        st = pg.evaluate("() => { const t = document.querySelector('#tutorial'); return t ? t.dataset.step : null; }")
        if not st: break
        if not seen or seen[-1] != st: seen.append(st)
        if st == 'gauges': ok(f'{tag} Tour highlights the gauges', pg.locator('.tut-ring').count() == 1)
        if st == 'pick': click(pg.locator('.bcard[data-type="oxygen"]')); pg.wait_for_timeout(700); continue
        if st == 'place':
            x, y = pg.evaluate("() => window.__ja.tileToScreen(9, 4)")
            if mobile: pg.touchscreen.tap(x, y); pg.wait_for_timeout(500); click(pg.locator('#bh-ok'))
            else: pg.mouse.click(x, y)
            pg.wait_for_timeout(800); continue
        if st == 'time': click(pg.locator('#speed button[data-s="1"]')); pg.wait_for_timeout(700); continue
        click(pg.locator('#tut-next')); pg.wait_for_timeout(450)
    ok(f'{tag} Tour steps advance on real actions (pick, place, start clock)', seen == ['welcome', 'gauges', 'camera', 'pick', 'place', 'time', 'goals', 'emerg', 'ready'], ' → '.join(seen))
    ok(f'{tag} Oxygen generator was really placed during the tour', pg.evaluate("() => [...window.__ja.engine.buildings.values()].some(b => b.type === 'oxygen')"))
    ok(f'{tag} Tour finished and remembered', pg.locator('#tutorial').count() == 0 and pg.evaluate("() => JSON.parse(localStorage.getItem('ja-settings')).tutorialDone") is True)
    ok(f'{tag} Crew radiation link hidden while the crew panel is collapsed', pg.locator('#crew.collapsed #crew-learn').count() == 0)
    pg.screenshot(path=ROOT + f'/qa/results/shots/P6Q_{"m" if mobile else "d"}_aftertour.png')
    # replay tutorial from settings in game, then skip
    click(pg.locator('#btn-menu')); pg.wait_for_timeout(300); click(pg.locator('#modal .btn', has_text='Settings')); pg.wait_for_timeout(400)
    click(pg.locator('#set-tutorial')); pg.wait_for_timeout(600)
    ok(f'{tag} "Replay now" restarts the tour in the current mission', pg.locator('#tutorial').count() == 1)
    click(pg.locator('.tut-skip')); pg.wait_for_timeout(300)
    ok(f'{tag} "Skip tour" closes it', pg.locator('#tutorial').count() == 0)
    # report learning section
    pg.evaluate("() => { const e = window.__ja.engine; e.events = []; window.__ja.Modals.clear(); e.t = e.days; e.quizScore = 3; e.quizCount = 4; e.endGame(true); }"); pg.wait_for_timeout(700)
    ok(f'{tag} Report shows crew survival and STEM learning results', pg.locator('#crew-survival').count() == 1 and pg.locator('#learn-results > div').count() == 6 and 'STEM LEARNING RESULTS' in pg.inner_text('#modal').upper())
    lr = pg.inner_text('#learn-results')
    ok(f'{tag} Learning results count quiz, facts, topics and decisions', '3 / 4 correct (75%)' in lr and 'Codex' in lr and 'NASA solar storms' in lr, lr.replace('\n', ' | ')[:160])
    ok(f'{tag} No runtime errors', not errs, errs[:3])
    ctx.close()

def demo(b, mobile):
    tag = '[phone demo]' if mobile else '[desktop demo]'
    vp = {'width': 390, 'height': 844} if mobile else {'width': 1440, 'height': 900}
    ctx, pg, errs = page(b, vp, mobile)
    click = (lambda l: l.tap()) if mobile else (lambda l: l.click())
    pg.goto(URL); pg.wait_for_timeout(1300)
    click(pg.locator('[data-mm="demo"]')); pg.wait_for_timeout(3200)
    ok(f'{tag} Demo opens with its own briefing', 'Hackathon demo mode' in pg.inner_text('#modal h2'))
    click(pg.locator('#modal .m-btns .btn.primary')); pg.wait_for_timeout(1500)
    types = pg.evaluate("() => [...window.__ja.engine.buildings.values()].map(b => b.type)")
    ok(f'{tag} A complete base is pre-built (all 11 building types)', all(t in types for t in ['solar', 'battery', 'reactor', 'oxygen', 'ice', 'recycler', 'greenhouse', 'shield', 'fabricator', 'lab', 'comms']), len(types))
    ok(f'{tag} Base is healthy and running', pg.evaluate("() => { const e = window.__ja.engine; return e.speed > 0 && e.res.o2 > 50 && e.crewActive() === 4 && !e.events.some(x => ['em','spe_warn','duststorm'].includes(x.type)); }"))
    ok(f'{tag} Demo panel shows 7 steps', pg.locator('#demo-panel .dp-step').count() == 7)
    ok(f'{tag} Demo panel does not cover the HUD', not pg.evaluate(OVERLAP), pg.evaluate(OVERLAP))
    pg.screenshot(path=ROOT + f'/qa/results/shots/P6Q_{"m" if mobile else "d"}_demo.png')
    expect = {'tour': None, 'science': 'Life-Support Science', 'dust': 'Dust', 'radiation': 'Radiation alert!', 'sources': 'NASA Data Sources', 'moon': 'Hackathon demo mode'}
    for sid, title in expect.items():
        click(pg.locator('#demo-next')); pg.wait_for_timeout(2200 if sid != 'moon' else 3600)
        h = pg.evaluate("() => { const m = document.querySelector('#modal h2'); return m ? m.innerText : null; }")
        good = (h is None) if title is None else (h is not None and title in h)
        if sid == 'tour': good = good and pg.evaluate('() => window.__ja.controls.autoRotate') is True
        if sid == 'radiation': good = good and pg.locator('#modal .nasa-card').count() == 1
        ok(f'{tag} Step "{sid}" works', good, h)
        if pg.locator('#modal .em-choice').count(): c = pg.locator('#modal .em-choice:not([disabled])').first; c.scroll_into_view_if_needed(); click(c); pg.wait_for_timeout(600)
        while pg.locator('#modal').count(): pg.locator('#modal .m-btns .btn').first.click(); pg.wait_for_timeout(400)
    ok(f'{tag} Moon demo continues at the final step', pg.evaluate('() => window.__ja.engine.planet.id') == 'moon' and 'final report' in pg.inner_text('#demo-next'))
    click(pg.locator('#demo-next')); pg.wait_for_timeout(3500)
    ok(f'{tag} Final step ends the mission with the full report and rank', 'Mission Complete!' in pg.inner_text('#modal h2') and pg.locator('#rank').count() == 1 and pg.locator('#learn-results').count() == 1)
    ok(f'{tag} No runtime errors', not errs, errs[:3])
    ctx.close()

VIEWS = [('1920x1080', 1920, 1080, False), ('1366x768', 1366, 768, False), ('1280x720', 1280, 720, False), ('tablet 768x1024', 768, 1024, True),
         ('phone 412x860', 412, 860, True), ('small phone 360x740', 360, 740, True), ('landscape 860x412', 860, 412, True)]
def layouts(b):
    for name, w, h, touch in VIEWS:
        ctx, pg, errs = page(b, {'width': w, 'height': h}, touch and w < 900)
        pg.goto(URL); pg.wait_for_timeout(1300)
        ok(f'[{name}] Title: no sideways scrolling, menu visible', pg.evaluate('() => document.querySelector("#title").scrollWidth <= innerWidth + 1') and pg.locator('#main-menu').is_visible())
        pg.screenshot(path=ROOT + f'/qa/results/shots/P6L_{name.split()[-1]}_title.png')
        for planet in ['mars', 'moon']:
            pg.evaluate(f'() => window.__ja.start("{planet}")'); pg.wait_for_timeout(2600)
            pg.evaluate('() => { const b = document.querySelector("#modal .m-btns .btn.primary"); b && b.click(); }'); pg.wait_for_timeout(900)
            bad = pg.evaluate(OVERLAP)
            ok(f'[{name}] {planet}: HUD panels do not overlap', not bad, bad)
            pg.evaluate('() => { const e = window.__ja.engine; e.setSpeed(0); Object.assign(e.stats.flags, { noO2: true, noWater: true, leak: true }); e.bump(); }'); pg.wait_for_timeout(700)
            bad3 = pg.evaluate(OVERLAP)
            ok(f'[{name}] {planet}: critical alert pill does not cover panels', pg.locator('#alertbar.show').count() == 1 and not bad3, bad3)
            pg.evaluate('() => { const e = window.__ja.engine; e.startBuild("greenhouse"); e.setGhost([4, 8]); }'); pg.wait_for_timeout(400)
            bad2 = pg.evaluate(OVERLAP)
            ok(f'[{name}] {planet}: build mode does not overlap', not bad2, bad2)
            pg.screenshot(path=ROOT + f'/qa/results/shots/P6L_{name.split()[-1]}_{planet}.png')
            pg.evaluate('() => { const e = window.__ja.engine; e.cancelBuild(); }')
            pg.evaluate('() => window.__ja.toTitle()'); pg.wait_for_timeout(600)
        ok(f'[{name}] No runtime errors', not errs, errs[:3])
        ctx.close()

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=ARGS)
    for a in sys.argv[1:]:
        {'features-desktop': lambda: features(b, False), 'features-phone': lambda: features(b, True), 'demo-desktop': lambda: demo(b, False), 'demo-phone': lambda: demo(b, True), 'layouts': lambda: layouts(b)}[a]()
    b.close()
print(f'\n{sum(R)}/{len(R)} passed')
