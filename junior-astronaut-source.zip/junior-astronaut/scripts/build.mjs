// Production build for Junior Astronaut.
//
// Output (dist/):
//   index.html                         small HTML shell (styles + loading screen), served with no-cache
//   assets/app.<hash>.js               the whole game bundle (React + three.js + game code), cached forever
//   assets/boot.<hash>.js              tiny loading-screen safety net
//
// Also: dist-standalone/junior-astronaut.html — everything inlined into ONE file (works offline, by
// double-click, or as a single-file upload). Kept outside dist/ so the site's strict CSP never applies to it.
//
// The build fails (non-zero exit) on any esbuild error or warning, so a broken build never deploys.
import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { gzipSync, brotliCompressSync, constants as zc } from 'node:zlib';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'dist');
const outStandalone = join(root, 'dist-standalone');

const common = {
  bundle: true, minify: true, write: false, format: 'iife', target: ['es2020'],
  legalComments: 'none', logLevel: 'silent',
};

async function bundle(entry, extra = {}) {
  const r = await build({ ...common, entryPoints: [join(root, entry)], ...extra });
  if (r.warnings.length) {
    for (const w of r.warnings) console.error('warning:', w.text, w.location ? `(${w.location.file}:${w.location.line})` : '');
    throw new Error(`${r.warnings.length} build warning(s) — fix them before deploying`);
  }
  return r.outputFiles[0].text;
}

const hash = (s) => createHash('sha256').update(s).digest('hex').slice(0, 10);
const kb = (n) => (n / 1024).toFixed(0) + ' KB';

try {
  const app = await bundle('src/index.jsx', {
    jsx: 'automatic', loader: { '.js': 'jsx' },
    define: { 'process.env.NODE_ENV': '"production"' },
  });
  const boot = await bundle('src/boot/boot.js');
  const template = readFileSync(join(root, 'src/template.html'), 'utf8');
  if (!template.includes('<!--APP_SCRIPTS-->')) throw new Error('src/template.html is missing the <!--APP_SCRIPTS--> marker');

  rmSync(out, { recursive: true, force: true });
  mkdirSync(join(out, 'assets'), { recursive: true });
  rmSync(outStandalone, { recursive: true, force: true });
  mkdirSync(outStandalone, { recursive: true });

  const appName = `assets/app.${hash(app)}.js`;
  const bootName = `assets/boot.${hash(boot)}.js`;
  writeFileSync(join(out, appName), app);
  writeFileSync(join(out, bootName), boot);

  // Relative paths: works on Vercel, any static host, a sub-folder, or opened straight from disk.
  const html = template.replace('<!--APP_SCRIPTS-->',
    () => `<script defer src="${appName}"></script>\n<script defer src="${bootName}"></script>`);
  writeFileSync(join(out, 'index.html'), html);

  const inline = (js) => `<script>${js.replace(/<\/script/gi, '<\\/script')}</script>`;
  const standalone = template.replace('<!--APP_SCRIPTS-->', () => inline(app) + '\n' + inline(boot));
  writeFileSync(join(outStandalone, 'junior-astronaut.html'), standalone);

  const gz = gzipSync(app, { level: 9 }).length;
  const br = brotliCompressSync(app, { params: { [zc.BROTLI_PARAM_QUALITY]: 11 } }).length;
  console.log('Build OK');
  console.log(`  dist/index.html                        ${kb(html.length)}`);
  console.log(`  dist/${appName}       ${kb(app.length)}  (gzip ${kb(gz)}, brotli ${kb(br)})`);
  console.log(`  dist/${bootName}       ${kb(boot.length)}`);
  console.log(`  dist-standalone/junior-astronaut.html   ${kb(standalone.length)}`);
} catch (e) {
  if (e.errors) for (const err of e.errors) console.error('error:', err.text, err.location ? `(${err.location.file}:${err.location.line})` : '');
  console.error('\nBuild FAILED:', e.message);
  process.exit(1);
}
