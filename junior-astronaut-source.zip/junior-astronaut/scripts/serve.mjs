// Local preview server for the production build (npm run preview).
// Serves dist/ with the SAME headers as vercel.json (including the Content-Security-Policy),
// so what you test locally is what Vercel will serve.
//   PORT=8080 npm run preview      (default port 4173)
import { createServer } from 'node:http';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { dirname, extname, join, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
const port = Number(process.env.PORT) || 4173;
const host = process.env.HOST || '127.0.0.1';

if (!existsSync(join(dist, 'index.html'))) {
  console.error('dist/index.html not found — run "npm run build" first.');
  process.exit(1);
}

const vercel = JSON.parse(readFileSync(join(root, 'vercel.json'), 'utf8'));
// vercel.json "source" patterns used here are simple path-to-regexp strings like "/(.*)" or "/assets/(.*)".
const rules = (vercel.headers || []).map((r) => ({ re: new RegExp('^' + r.source + '$'), headers: r.headers }));

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};

createServer((req, res) => {
  const urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  let file = normalize(join(dist, urlPath === '/' ? 'index.html' : urlPath));
  if (!file.startsWith(dist + sep) && file !== dist) { res.writeHead(403).end('Forbidden'); return; }
  if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
  if (!existsSync(file)) { res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found'); return; }

  const headers = { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream' };
  for (const r of rules) if (r.re.test(urlPath)) for (const h of r.headers) headers[h.key] = h.value;

  let body = readFileSync(file);
  if (/\bgzip\b/.test(req.headers['accept-encoding'] || '') && /html|javascript|css|json|svg/.test(headers['Content-Type'])) {
    body = gzipSync(body); headers['Content-Encoding'] = 'gzip'; headers['Vary'] = 'Accept-Encoding';
  }
  res.writeHead(200, headers).end(body);
}).listen(port, host, () => {
  console.log(`Junior Astronaut preview: http://${host === '0.0.0.0' ? 'localhost' : host}:${port}/  (Ctrl+C to stop)`);
});
